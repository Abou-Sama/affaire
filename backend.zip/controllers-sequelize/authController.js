/**
 * Migration from MongoDB to MySQL/MariaDB
 * Updated Controllers for Sequelize ORM
 */

const { User } = require('../models-sequelize');
const AuthService = require('../services/authService');
const logger = require('../config/logger');

/**
 * Register/Signup new user
 * POST /api/auth/signup
 */
exports.signup = async (req, res, next) => {
    try {
        const { email, name, password } = req.body;

        // Check if user already exists
        const existingUser = await User.findOne({ where: { email } });
        if (existingUser) {
            return res.status(400).json({
                success: false,
                error: 'Email already registered'
            });
        }

        // Create new user
        const user = await User.create({
            email,
            name,
            password,
            role: 'user',
            status: 'active'
        });

        // Generate tokens
        const { accessToken, refreshToken } = await AuthService.generateTokens(user);

        // Set refresh token in HTTP-only cookie
        res.cookie('refreshToken', refreshToken, {
            httpOnly: true,
            secure: process.env.NODE_ENV === 'production',
            sameSite: 'strict',
            maxAge: 7 * 24 * 60 * 60 * 1000
        });

        logger.info(`New user registered: ${email}`);

        res.status(201).json({
            success: true,
            message: 'User registered successfully',
            data: {
                user: user.toJSON(),
                accessToken,
                refreshToken
            }
        });
    } catch (error) {
        next(error);
    }
};

/**
 * Login user
 * POST /api/auth/login
 */
exports.login = async (req, res, next) => {
    try {
        const { email, password } = req.body;

        // Find user
        const user = await User.findOne({ where: { email } });
        if (!user) {
            logger.warn(`Login attempt for non-existent email: ${email}`);
            return res.status(401).json({
                success: false,
                error: 'Invalid email or password'
            });
        }

        // Check if account is locked
        if (user.isAccountLocked()) {
            logger.warn(`Login attempt for locked account: ${email}`);
            return res.status(403).json({
                success: false,
                error: 'Account is locked. Please try again later.'
            });
        }

        // Verify password
        const passwordMatch = await user.comparePassword(password);
        if (!passwordMatch) {
            await user.incrementFailedAttempts();
            logger.warn(`Failed login for: ${email}`);
            return res.status(401).json({
                success: false,
                error: 'Invalid email or password'
            });
        }

        // Reset failed attempts on successful login
        await user.resetFailedAttempts();

        // Generate tokens
        const { accessToken, refreshToken } = await AuthService.generateTokens(user);

        // Set refresh token cookie
        res.cookie('refreshToken', refreshToken, {
            httpOnly: true,
            secure: process.env.NODE_ENV === 'production',
            sameSite: 'strict',
            maxAge: 7 * 24 * 60 * 60 * 1000
        });

        logger.info(`User logged in: ${email}`);

        res.json({
            success: true,
            message: 'Login successful',
            data: {
                user: user.toJSON(),
                accessToken,
                refreshToken
            }
        });
    } catch (error) {
        next(error);
    }
};

/**
 * Logout user
 * POST /api/auth/logout
 */
exports.logout = async (req, res, next) => {
    try {
        res.clearCookie('refreshToken');
        logger.info(`User logged out: ${req.user.email}`);

        res.json({
            success: true,
            message: 'Logged out successfully'
        });
    } catch (error) {
        next(error);
    }
};

/**
 * Refresh access token
 * POST /api/auth/refresh
 */
exports.refreshToken = async (req, res, next) => {
    try {
        const { refreshToken } = req.cookies;

        if (!refreshToken) {
            return res.status(401).json({
                success: false,
                error: 'No refresh token provided'
            });
        }

        // Verify refresh token
        const decoded = await AuthService.verifyToken(refreshToken, 'refresh');
        const user = await User.findByPk(decoded.id);

        if (!user) {
            return res.status(401).json({
                success: false,
                error: 'User not found'
            });
        }

        // Generate new access token
        const { accessToken, refreshToken: newRefreshToken } = await AuthService.generateTokens(user);

        // Set new refresh token cookie
        res.cookie('refreshToken', newRefreshToken, {
            httpOnly: true,
            secure: process.env.NODE_ENV === 'production',
            sameSite: 'strict',
            maxAge: 7 * 24 * 60 * 60 * 1000
        });

        res.json({
            success: true,
            data: { accessToken, refreshToken: newRefreshToken }
        });
    } catch (error) {
        next(error);
    }
};
