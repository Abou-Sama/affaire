/**
 * User Controller - Sequelize Version
 * Migration from MongoDB to MySQL/MariaDB
 */

const { User } = require('../models-sequelize');
const logger = require('../config/logger');
const { Op } = require('sequelize');

/**
 * Get user profile
 * GET /api/users/profile
 */
exports.getProfile = async (req, res, next) => {
    try {
        const user = await User.findByPk(req.user.id);

        if (!user) {
            return res.status(404).json({
                success: false,
                error: 'User not found'
            });
        }

        res.json({
            success: true,
            data: user.toJSON()
        });
    } catch (error) {
        next(error);
    }
};

/**
 * Update user profile
 * PATCH /api/users/profile
 */
exports.updateProfile = async (req, res, next) => {
    try {
        const { name, email } = req.body;
        const user = await User.findByPk(req.user.id);

        if (!user) {
            return res.status(404).json({
                success: false,
                error: 'User not found'
            });
        }

        // Check if email is unique
        if (email && email !== user.email) {
            const existingUser = await User.findOne({ where: { email } });
            if (existingUser) {
                return res.status(400).json({
                    success: false,
                    error: 'Email already in use'
                });
            }
            user.email = email;
        }

        if (name) user.name = name;

        await user.save();
        logger.info(`User profile updated: ${user.email}`);

        res.json({
            success: true,
            message: 'Profile updated successfully',
            data: user.toJSON()
        });
    } catch (error) {
        next(error);
    }
};

/**
 * Change password
 * POST /api/users/change-password
 */
exports.changePassword = async (req, res, next) => {
    try {
        const { currentPassword, newPassword } = req.body;
        const user = await User.findByPk(req.user.id);

        if (!user) {
            return res.status(404).json({
                success: false,
                error: 'User not found'
            });
        }

        // Verify current password
        const isMatch = await user.comparePassword(currentPassword);
        if (!isMatch) {
            return res.status(401).json({
                success: false,
                error: 'Current password is incorrect'
            });
        }

        // Update password
        user.password = newPassword;
        await user.save();
        logger.info(`Password changed for user: ${user.email}`);

        res.json({
            success: true,
            message: 'Password changed successfully'
        });
    } catch (error) {
        next(error);
    }
};

/**
 * Get all users (Admin only)
 * GET /api/users
 */
exports.getAllUsers = async (req, res, next) => {
    try {
        const page = parseInt(req.query.page) || 1;
        const limit = parseInt(req.query.limit) || 10;
        const offset = (page - 1) * limit;

        const { count, rows } = await User.findAndCountAll({
            offset,
            limit,
            order: [['createdAt', 'DESC']]
        });

        res.json({
            success: true,
            data: rows.map(user => user.toJSON()),
            pagination: {
                total: count,
                page,
                pages: Math.ceil(count / limit)
            }
        });
    } catch (error) {
        next(error);
    }
};

/**
 * Delete user (Admin only)
 * DELETE /api/users/:id
 */
exports.deleteUser = async (req, res, next) => {
    try {
        const user = await User.findByPk(req.params.id);

        if (!user) {
            return res.status(404).json({
                success: false,
                error: 'User not found'
            });
        }

        await user.destroy();
        logger.info(`User deleted: ${user.email}`);

        res.json({
            success: true,
            message: 'User deleted successfully'
        });
    } catch (error) {
        next(error);
    }
};

/**
 * Search users (Admin only)
 * GET /api/users/search?q=query
 */
exports.searchUsers = async (req, res, next) => {
    try {
        const { q } = req.query;

        if (!q) {
            return res.status(400).json({
                success: false,
                error: 'Search query is required'
            });
        }

        const users = await User.findAll({
            where: {
                [Op.or]: [
                    { email: { [Op.like]: `%${q}%` } },
                    { name: { [Op.like]: `%${q}%` } }
                ]
            },
            limit: 20
        });

        res.json({
            success: true,
            data: users.map(user => user.toJSON())
        });
    } catch (error) {
        next(error);
    }
};
