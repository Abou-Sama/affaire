const jwt = require('jsonwebtoken');

// JWT secret (use environment variable in production)
const JWT_SECRET = process.env.JWT_SECRET || (process.env.NODE_ENV === 'production' ? undefined : 'your-secret-key-change-in-production');
const JWT_EXPIRY = '1h'; // Token expires in 1 hour (matches authServiceHybrid)

function getJwtSecret() {
    if (!JWT_SECRET) {
        throw new Error('JWT_SECRET is required');
    }

    return JWT_SECRET;
}

/**
 * Generate JWT token for a user
 * @param {Object} user - User object
 * @returns {string} JWT token
 */
function generateToken(user) {
    const payload = {
        id: user.id,
        email: user.email,
        role: user.role || 'user',
        name: user.name
    };

    return jwt.sign(payload, getJwtSecret(), { expiresIn: JWT_EXPIRY });
}

/**
 * Verify JWT token
 * @param {string} token - JWT token
 * @returns {Object|null} Decoded payload or null if invalid
 */
function verifyToken(token) {
    try {
        return jwt.verify(token, getJwtSecret());
    } catch (error) {
        console.error('JWT verification error:', error.message);
        return null;
    }
}

/**
 * Middleware to authenticate JWT token from request headers
 */
function authenticateToken(req, res, next) {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1]; // Bearer TOKEN

    if (!token) {
        console.log('❌ No token provided in Authorization header');
        return res.status(401).json({ error: 'Access token required' });
    }

    const decoded = verifyToken(token);
    if (!decoded) {
        console.log('❌ Token verification failed');
        return res.status(401).json({ error: 'Invalid or expired token' });
    }

    console.log('✅ Token verified for user:', decoded.email, 'Role:', decoded.role);

    req.user = decoded;
    next();
}

/**
 * Middleware to check if user is admin
 */
function requireAdmin(req, res, next) {
    if (!req.user || req.user.role !== 'admin') {
        return res.status(403).json({ error: 'Admin access required' });
    }
    next();
}

module.exports = {
    generateToken,
    verifyToken,
    authenticateToken,
    requireAdmin,
    JWT_SECRET
};
