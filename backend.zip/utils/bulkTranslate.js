/**
 * Bulk Translation Script
 * Translates all existing posts in homeContents.json, recrutement.json, and syntheseActualite.json
 * Fixes posts with incomplete/repeated translations
 * 
 * Usage: node backend/utils/bulkTranslate.js
 */

const fs = require('fs');
const path = require('path');
const { translateText, updateLanguageVariants } = require('../services/translationService');

const DATA_DIR = path.join(__dirname, '../data');

const FILES_TO_TRANSLATE = [
    { file: 'homeContents.json', type: 'array', fieldsToTranslate: ['title', 'description'] },
    { file: 'recrutement.json', type: 'array', fieldsToTranslate: ['title', 'description', 'content'] },
    { file: 'syntheseActualite.json', type: 'array', fieldsToTranslate: ['title', 'description', 'content'] }
];

let totalPosts = 0;
let translatedPosts = 0;
let fixedPosts = 0;

/**
 * Check if a post has incomplete/invalid translations
 */
function hasInvalidTranslations(post) {
    if (!post.languageVariants || post.languageVariants.length === 0) {
        return false; // Needs translation
    }

    // Check if translations are just repeating French text
    for (const variant of post.languageVariants) {
        if (variant.language === 'en' && variant.title === post.title) {
            // English title is same as French - likely not translated
            if (variant.description === post.description) {
                return true; // Invalid - repeating French
            }
        }
        if (variant.language === 'ar' && variant.title === post.title) {
            // Arabic title is same as French - likely not translated
            if (variant.description === post.description) {
                return true; // Invalid - repeating French
            }
        }
    }
    return false;
}

/**
 * Translate a single post
 */
async function translateSinglePost(post) {
    if (!post.title) return post;

    const isInvalid = hasInvalidTranslations(post);
    const isUntranslated = !post.languageVariants || post.languageVariants.length === 0;

    if (!isInvalid && !isUntranslated) {
        console.log(`  ⏭️  Skipping post "${post.title.substring(0, 50)}..." (already has valid translations)`);
        return post;
    }

    if (isInvalid) {
        console.log(`  🔧 Fixing invalid translations for "${post.title.substring(0, 50)}..."`);
        fixedPosts++;
    } else {
        console.log(`  🔄 Translating "${post.title.substring(0, 50)}..."`);
        translatedPosts++;
    }

    try {
        // Always retranslate - this ensures we get proper translations
        const variants = await updateLanguageVariants(post, []);
        post.languageVariants = variants;
        console.log(`  ✅ Translation successful`);
        return post;
    } catch (error) {
        console.error(`  ❌ Error translating post:`, error.message);
        return post;
    }
}

/**
 * Process a data file
 */
async function processFile(filename, config) {
    const filePath = path.join(DATA_DIR, filename);

    if (!fs.existsSync(filePath)) {
        console.log(`⚠️  File not found: ${filename}`);
        return;
    }

    console.log(`\n📄 Processing ${filename}...`);

    try {
        let data = JSON.parse(fs.readFileSync(filePath, 'utf-8'));

        if (config.type === 'array') {
            console.log(`   Found ${data.length} posts`);
            totalPosts += data.length;

            for (let i = 0; i < data.length; i++) {
                data[i] = await translateSinglePost(data[i]);
                // Add small delay to avoid rate limiting
                await new Promise(resolve => setTimeout(resolve, 500));
            }
        } else if (config.type === 'object') {
            console.log(`   Processing object data...`);
            for (let key in data) {
                if (data[key].title) {
                    totalPosts++;
                    data[key] = await translateSinglePost(data[key]);
                    await new Promise(resolve => setTimeout(resolve, 500));
                }
            }
        }

        // Write back to file
        fs.writeFileSync(filePath, JSON.stringify(data, null, 2), 'utf-8');
        console.log(`   ✅ ${filename} updated successfully`);
    } catch (error) {
        console.error(`   ❌ Error processing ${filename}:`, error.message);
    }
}

/**
 * Main function
 */
async function main() {
    console.log('🌍 Starting bulk translation...\n');
    console.log('This will:');
    console.log('  1. Translate all untranslated posts');
    console.log('  2. Fix posts with invalid/repeated translations');
    console.log('  3. Support all three languages: French, English, Arabic\n');
    console.log('Rate limit: 500ms between posts to avoid API throttling\n');

    for (const config of FILES_TO_TRANSLATE) {
        await processFile(config.file, config);
    }

    console.log(`\n📊 Translation Summary:`);
    console.log(`   Total posts processed: ${totalPosts}`);
    console.log(`   Newly translated: ${translatedPosts}`);
    console.log(`   Fixed invalid translations: ${fixedPosts}`);
    console.log(`\n✨ Bulk translation complete!`);
    console.log('\n✅ All posts now have proper translations');
    console.log('✅ New posts will auto-translate when created');
    console.log('✅ Updated posts will auto-translate when modified');
}

// Run the script
main().catch(error => {
    console.error('Fatal error:', error);
    process.exit(1);
});
