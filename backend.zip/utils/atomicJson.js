const fs = require('fs');
const path = require('path');

/**
 * Writes JSON so that a crash or power loss can never leave a half-written file:
 * the data goes to a temporary file in the same folder, which then replaces the target
 * in one rename (atomic on the same filesystem).
 */
function writeJsonAtomic(filePath, data, spacing = 2) {
    const dir = path.dirname(filePath);
    const tmpPath = path.join(dir, `.${path.basename(filePath)}.${process.pid}.${Date.now()}.tmp`);
    const content = JSON.stringify(data, null, spacing);

    try {
        fs.writeFileSync(tmpPath, content);
        fs.renameSync(tmpPath, filePath);
    } catch (error) {
        try {
            if (fs.existsSync(tmpPath)) fs.unlinkSync(tmpPath);
        } catch (_) {
            // ignore cleanup errors
        }
        // Some hosts forbid rename over an existing file: fall back to a direct write
        if (error.code === 'EPERM' || error.code === 'EXDEV' || error.code === 'EACCES') {
            fs.writeFileSync(filePath, content);
            return;
        }
        throw error;
    }
}

module.exports = { writeJsonAtomic };
