const ALLOWED_TAGS = new Set(['p', 'br', 'strong', 'em', 'b', 'i', 'u', 'ul', 'ol', 'li', 'a', 'span', 'div', 'blockquote', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6']);

const sanitizeHtml = (value) => {
  if (typeof value !== 'string') return value;

  let sanitized = value
    .replace(/<script[^>]*>[\s\S]*?<\/script>/gi, '')
    .replace(/<style[^>]*>[\s\S]*?<\/style>/gi, '')
    .replace(/<iframe[^>]*>[\s\S]*?<\/iframe>/gi, '')
    .replace(/<object[^>]*>[\s\S]*?<\/object>/gi, '')
    .replace(/<embed[^>]*>/gi, '')
    .replace(/on\w+\s*=\s*(?:"[^"]*"|'[^']*')/gi, '')
    .replace(/javascript:/gi, '')
    .replace(/data:\s*text\/html/gi, '');

  sanitized = sanitized.replace(/<\s*\/\s*([a-z0-9]+)\s*>/gi, (match, tagName) => {
    const tag = tagName.toLowerCase();
    return ALLOWED_TAGS.has(tag) ? `</${tag}>` : '';
  });

  sanitized = sanitized.replace(/<\s*([a-z0-9]+)([^>]*)>/gi, (match, tagName, attrs) => {
    const tag = tagName.toLowerCase();
    if (!ALLOWED_TAGS.has(tag)) {
      return '';
    }

    const safeAttrs = [];
    const attrMatches = attrs.match(/([a-zA-Z_:.-]+)\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s>]+))/g) || [];

    for (const attr of attrMatches) {
      const matchAttr = attr.match(/([a-zA-Z_:.-]+)\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s>]+))/);
      if (!matchAttr) continue;

      const [, rawName, doubleQuoted, singleQuoted, unquoted] = matchAttr;
      const attrName = rawName.toLowerCase();
      const attrValue = doubleQuoted || singleQuoted || unquoted || '';

      if (!['href', 'title'].includes(attrName)) {
        continue;
      }

      if (attrName === 'href') {
        if (!/^(https?:\/\/|mailto:|tel:|\/|\.\/|\.\.\/)/i.test(attrValue)) {
          continue;
        }
      }

      safeAttrs.push(`${attrName}="${attrValue}"`);
    }

    return `<${tag}${safeAttrs.length ? ` ${safeAttrs.join(' ')}` : ''}>`;
  });

  return sanitized;
};

const sanitizeText = (value) => {
  if (typeof value !== 'string') return value;

  return value
    .replace(/<script[^>]*>[\s\S]*?<\/script>/gi, ' ')
    .replace(/<style[^>]*>[\s\S]*?<\/style>/gi, ' ')
    .replace(/<[^>]*>/g, ' ')
    .replace(/javascript:/gi, '')
    .replace(/[<>]/g, ' ')
    .replace(/\s+/g, ' ')
    .replace(/\s+([!?.,:;])/g, '$1')
    .trim();
};

const sanitizeHtmlContent = (value) => {
  if (typeof value !== 'string') return value;
  return sanitizeHtml(value);
};

module.exports = {
  sanitizeText,
  sanitizeHtmlContent
};
