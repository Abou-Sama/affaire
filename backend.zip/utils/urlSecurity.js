const SAFE_LINK_PROTOCOLS = new Set(['http:', 'https:', 'mailto:', 'tel:']);
const SAFE_MEDIA_PROTOCOLS = new Set(['http:', 'https:']);
const YOUTUBE_HOSTS = new Set([
    'youtube.com',
    'www.youtube.com',
    'm.youtube.com',
    'youtube-nocookie.com',
    'www.youtube-nocookie.com',
    'youtu.be'
]);

const normalizeHost = (host) => String(host || '').toLowerCase().replace(/^www\./, '');

const isSafeRelativeUrl = (value) => {
    const raw = String(value || '').trim();
    return raw.startsWith('/') && !raw.startsWith('//') && !raw.includes('\\');
};

const normalizeSafeUrl = (value, { protocols = SAFE_LINK_PROTOCOLS, allowRelative = true } = {}) => {
    const raw = String(value || '').trim();
    if (!raw) return '';
    if (allowRelative && isSafeRelativeUrl(raw)) return raw;

    try {
        const parsed = new URL(raw);
        return protocols.has(parsed.protocol) ? parsed.toString() : '';
    } catch {
        return '';
    }
};

const normalizeImageUrl = (value) => normalizeSafeUrl(value, {
    protocols: SAFE_MEDIA_PROTOCOLS,
    allowRelative: true
});

const normalizeYouTubeEmbedUrl = (value) => {
    const raw = String(value || '').trim();
    if (!raw) return '';

    try {
        const parsed = new URL(raw);
        const normalizedHost = normalizeHost(parsed.hostname);

        if (!YOUTUBE_HOSTS.has(normalizedHost) && !YOUTUBE_HOSTS.has(parsed.hostname.toLowerCase())) {
            return '';
        }

        let videoId = '';
        if (normalizedHost === 'youtu.be') {
            videoId = parsed.pathname.split('/').filter(Boolean)[0] || '';
        } else if (parsed.pathname.startsWith('/embed/')) {
            videoId = parsed.pathname.split('/').filter(Boolean)[1] || '';
        } else if (parsed.pathname === '/watch') {
            videoId = parsed.searchParams.get('v') || '';
        } else if (parsed.pathname.startsWith('/shorts/')) {
            videoId = parsed.pathname.split('/').filter(Boolean)[1] || '';
        }

        if (!/^[A-Za-z0-9_-]{6,20}$/.test(videoId)) {
            return '';
        }

        return `https://www.youtube-nocookie.com/embed/${videoId}`;
    } catch {
        return '';
    }
};

module.exports = {
    normalizeSafeUrl,
    normalizeImageUrl,
    normalizeYouTubeEmbedUrl
};
