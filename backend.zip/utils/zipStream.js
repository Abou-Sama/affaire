/**
 * Minimal streaming ZIP writer for backups.
 *
 * Files are written "stored" (no compression): uploads are JPG/PNG/PDF/MP4, which are
 * already compressed, so deflating them only burned CPU and blocked the server.
 * Because nothing is compressed, the exact archive size is known before the first byte,
 * so the response can carry a Content-Length (the browser shows real progress) and the
 * download starts immediately instead of waiting for the whole archive to be built.
 */
const fs = require('fs');
const zlib = require('zlib');

const UINT32_MAX = 0xFFFFFFFF;
const UINT16_MAX = 0xFFFF;
const FLAG_DATA_DESCRIPTOR = 0x0008; // CRC/sizes follow the data (CRC is computed while streaming)
const FLAG_UTF8 = 0x0800;
const METHOD_STORED = 0;
const METHOD_DEFLATE = 8;

function dosDateTime(date) {
    const year = Math.max(date.getFullYear(), 1980);
    return {
        time: (date.getHours() << 11) | (date.getMinutes() << 5) | Math.floor(date.getSeconds() / 2),
        date: ((year - 1980) << 9) | ((date.getMonth() + 1) << 5) | date.getDate()
    };
}

/**
 * Describe a file on disk. Its size must not change until the archive is written.
 */
function fileEntry(name, filePath, size, mtime = new Date()) {
    return { name, filePath, size, compressedSize: size, method: METHOD_STORED, mtime, streamed: true };
}

/**
 * Describe an in-memory buffer (deflated here, since it is small text such as JSON).
 */
function bufferEntry(name, buffer, mtime = new Date()) {
    const compressed = zlib.deflateRawSync(buffer);
    return {
        name, data: compressed, size: buffer.length, compressedSize: compressed.length,
        method: METHOD_DEFLATE, crc: zlib.crc32(buffer), mtime, streamed: false
    };
}

/**
 * Exact byte size of the archive for the given entries, or throws when the archive
 * would need ZIP64 (over 4 GB or 65535 entries).
 */
function archiveSize(entries) {
    if (entries.length > UINT16_MAX) throw new Error('Too many files for one archive');
    let total = 22; // end of central directory
    for (const entry of entries) {
        const nameLength = Buffer.byteLength(entry.name);
        if (entry.size > UINT32_MAX || entry.compressedSize > UINT32_MAX) throw new Error('File too large for the archive');
        total += 30 + nameLength + entry.compressedSize + (entry.streamed ? 16 : 0); // local header + data (+ descriptor)
        total += 46 + nameLength; // central directory record
    }
    if (total > UINT32_MAX) throw new Error('Archive larger than 4 GB');
    return total;
}

function localHeader(entry, nameBuffer) {
    const { time, date } = dosDateTime(entry.mtime);
    const header = Buffer.alloc(30);
    header.writeUInt32LE(0x04034b50, 0);
    header.writeUInt16LE(20, 4);
    header.writeUInt16LE(FLAG_UTF8 | (entry.streamed ? FLAG_DATA_DESCRIPTOR : 0), 6);
    header.writeUInt16LE(entry.method, 8);
    header.writeUInt16LE(time, 10);
    header.writeUInt16LE(date, 12);
    header.writeUInt32LE(entry.streamed ? 0 : entry.crc, 14);
    header.writeUInt32LE(entry.streamed ? 0 : entry.compressedSize, 18);
    header.writeUInt32LE(entry.streamed ? 0 : entry.size, 22);
    header.writeUInt16LE(nameBuffer.length, 26);
    header.writeUInt16LE(0, 28);
    return Buffer.concat([header, nameBuffer]);
}

function centralRecord(entry, nameBuffer, offset) {
    const { time, date } = dosDateTime(entry.mtime);
    const record = Buffer.alloc(46);
    record.writeUInt32LE(0x02014b50, 0);
    record.writeUInt16LE(20, 4);
    record.writeUInt16LE(20, 6);
    record.writeUInt16LE(FLAG_UTF8 | (entry.streamed ? FLAG_DATA_DESCRIPTOR : 0), 8);
    record.writeUInt16LE(entry.method, 10);
    record.writeUInt16LE(time, 12);
    record.writeUInt16LE(date, 14);
    record.writeUInt32LE(entry.crc >>> 0, 16);
    record.writeUInt32LE(entry.compressedSize, 20);
    record.writeUInt32LE(entry.size, 24);
    record.writeUInt16LE(nameBuffer.length, 28);
    record.writeUInt32LE(offset, 42);
    return Buffer.concat([record, nameBuffer]);
}

// Write respecting backpressure, so a slow client never makes the server buffer the whole file
function write(output, chunk) {
    if (output.destroyed) return Promise.reject(new Error('Client disconnected'));
    if (output.write(chunk)) return Promise.resolve();
    return new Promise((resolve, reject) => {
        const cleanup = () => { output.off('drain', onDrain); output.off('close', onClose); };
        const onDrain = () => { cleanup(); resolve(); };
        const onClose = () => { cleanup(); reject(new Error('Client disconnected')); };
        output.on('drain', onDrain);
        output.on('close', onClose);
    });
}

/**
 * Stream the archive to `output` (an HTTP response). Resolves when every byte is written.
 */
async function writeZip(output, entries) {
    let offset = 0;
    const central = [];

    for (const entry of entries) {
        const nameBuffer = Buffer.from(entry.name, 'utf8');
        const entryOffset = offset;
        const header = localHeader(entry, nameBuffer);
        await write(output, header);
        offset += header.length;

        if (entry.streamed) {
            let crc = 0;
            let written = 0;
            for await (const chunk of fs.createReadStream(entry.filePath, { highWaterMark: 1024 * 1024 })) {
                crc = zlib.crc32(chunk, crc);
                written += chunk.length;
                await write(output, chunk);
            }
            if (written !== entry.size) throw new Error(`File changed while exporting: ${entry.name}`);
            entry.crc = crc;

            const descriptor = Buffer.alloc(16);
            descriptor.writeUInt32LE(0x08074b50, 0);
            descriptor.writeUInt32LE(crc >>> 0, 4);
            descriptor.writeUInt32LE(entry.size, 8);
            descriptor.writeUInt32LE(entry.size, 12);
            await write(output, descriptor);
            offset += entry.size + descriptor.length;
        } else {
            await write(output, entry.data);
            offset += entry.data.length;
        }
        central.push(centralRecord(entry, nameBuffer, entryOffset));
    }

    const centralDirectory = Buffer.concat(central);
    const end = Buffer.alloc(22);
    end.writeUInt32LE(0x06054b50, 0);
    end.writeUInt16LE(entries.length, 8);
    end.writeUInt16LE(entries.length, 10);
    end.writeUInt32LE(centralDirectory.length, 12);
    end.writeUInt32LE(offset, 16);
    await write(output, Buffer.concat([centralDirectory, end]));
}

module.exports = { fileEntry, bufferEntry, archiveSize, writeZip };
