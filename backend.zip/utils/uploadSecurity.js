const crypto = require('crypto');
const path = require('path');

const IMAGE_MIME_EXTENSIONS = {
    'image/jpeg': ['.jpg', '.jpeg'],
    'image/png': ['.png'],
    'image/webp': ['.webp'],
    'image/gif': ['.gif']
};

const DOCUMENT_MIME_EXTENSIONS = {
    'application/pdf': ['.pdf']
};

const VIDEO_MIME_EXTENSIONS = {
    'video/mp4': ['.mp4'],
    'video/webm': ['.webm'],
    'video/quicktime': ['.mov']
};

const DANGEROUS_EXTENSIONS = new Set([
    '.asp',
    '.aspx',
    '.bat',
    '.cgi',
    '.cmd',
    '.com',
    '.ejs',
    '.exe',
    '.html',
    '.htm',
    '.js',
    '.jsp',
    '.mjs',
    '.phtml',
    '.php',
    '.pl',
    '.ps1',
    '.py',
    '.sh',
    '.svg',
    '.ts',
    '.tsx',
    '.jar',
    '.zip',
    '.rar',
    '.7z',
    '.gz',
    '.tar',
    '.xml',
    '.json',
    '.csv'
]);

const DANGEROUS_FILENAME_PATTERNS = [/\.\.(?:\.|[\/\\])/u, /[<>:"|?*]/u, /\s{2,}/u, /(^|\.)\.(?!\w)/u];

const allowedExtensionsFor = (groups) => {
    const map = {};
    groups.forEach((group) => Object.assign(map, group));
    return map;
};

const sanitizeBaseName = (value) => {
    const parsed = path.parse(String(value || 'upload'));
    const baseName = parsed.name
        .normalize('NFKD')
        .replace(/[^\w.-]+/g, '-')
        .replace(/-+/g, '-')
        .replace(/^-|-$/g, '')
        .slice(0, 80) || 'upload';

    if (DANGEROUS_FILENAME_PATTERNS.some((pattern) => pattern.test(baseName))) {
        return 'upload';
    }

    return baseName;
};

const generateSafeFilename = (originalName) => {
    const ext = path.extname(String(originalName || '')).toLowerCase();
    const baseName = sanitizeBaseName(originalName);
    return `${Date.now()}-${crypto.randomBytes(8).toString('hex')}-${baseName}${ext}`;
};

const createFileFilter = ({ groups, label }) => {
    const allowed = allowedExtensionsFor(groups);
    const readableLabel = label || 'allowed files';

    return (req, file, cb) => {
        const originalName = String(file.originalname || '');
        const ext = path.extname(originalName).toLowerCase();
        const allowedExtensions = allowed[file.mimetype] || [];

        // The original name is never used on disk (generateSafeFilename renames every upload),
        // so only the type is checked here: rejecting names with accents, colons or double
        // spaces refused legitimate documents like "Avis de recrutement à pourvoir.pdf".
        if (DANGEROUS_EXTENSIONS.has(ext)) {
            return cb(new Error(`File type not allowed. Upload only ${readableLabel}.`), false);
        }

        if (!allowedExtensions.includes(ext)) {
            return cb(new Error(`Invalid file type. Upload only ${readableLabel}.`), false);
        }

        return cb(null, true);
    };
};

const blockDangerousUploads = (req, res, next) => {
    const requestPath = String(req.path || '');
    const ext = path.extname(requestPath).toLowerCase();
    const basename = path.basename(requestPath);

    if (DANGEROUS_EXTENSIONS.has(ext) || DANGEROUS_FILENAME_PATTERNS.some((pattern) => pattern.test(requestPath) || pattern.test(basename))) {
        return res.status(403).type('text/plain').send('Blocked uploaded file type');
    }

    next();
};

const uploadedStaticOptions = {
    dotfiles: 'deny',
    index: false,
    setHeaders: (res, filePath) => {
        const ext = path.extname(filePath).toLowerCase();
        res.setHeader('X-Content-Type-Options', 'nosniff');
        res.setHeader('Cross-Origin-Resource-Policy', 'same-origin');
        res.setHeader('Content-Security-Policy', "default-src 'none'; style-src 'unsafe-inline'; sandbox");
        // Uploads get a unique timestamp+random name, so a replaced image always has a new URL:
        // safe for browsers to keep them instead of re-downloading on every visit
        res.setHeader('Cache-Control', 'public, max-age=2592000');

        if (!['.jpg', '.jpeg', '.png', '.webp', '.gif', '.pdf', '.mp4', '.webm', '.mov'].includes(ext)) {
            res.setHeader('Content-Disposition', 'attachment');
            res.setHeader('Content-Type', 'application/octet-stream');
        }
    }
};

module.exports = {
    IMAGE_MIME_EXTENSIONS,
    DOCUMENT_MIME_EXTENSIONS,
    VIDEO_MIME_EXTENSIONS,
    createFileFilter,
    generateSafeFilename,
    blockDangerousUploads,
    uploadedStaticOptions
};
