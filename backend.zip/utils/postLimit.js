/**
 * Post cap shared by "Accueil" and "Avis de recrutement": at most `limit` posts are kept.
 * When a new post goes over the cap, the oldest posts are removed, "oldest" meaning the same
 * order the public site uses (publication date, then creation time; see src/utils/dateUtils.ts).
 * The post that was just added is never the one removed.
 */

// Same parsing as the frontend's parsePostDate (accepts "dd/mm/yyyy" and ISO dates)
function parsePostDate(value) {
    const trimmed = String(value || '').trim();
    if (!trimmed) return 0;
    const frenchDate = trimmed.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
    if (frenchDate) {
        const [, day, month, year] = frenchDate;
        return new Date(Number(year), Number(month) - 1, Number(day)).getTime();
    }
    const timestamp = new Date(trimmed).getTime();
    return Number.isNaN(timestamp) ? 0 : timestamp;
}

// Same fallback chain as the frontend's getPostOrderTimestamp
function creationTime(post) {
    const createdAt = parsePostDate(post.createdAt);
    if (createdAt) return createdAt;
    const updatedAt = parsePostDate(post.updatedAt);
    if (updatedAt) return updatedAt;
    const numericId = Number(post.id);
    return Number.isFinite(numericId) ? numericId : 0;
}

// Oldest first
function compareOldestFirst(a, b) {
    const dateDiff = parsePostDate(a.publishDate || a.publish_date) - parsePostDate(b.publishDate || b.publish_date);
    if (dateDiff !== 0) return dateDiff;
    return creationTime(a) - creationTime(b);
}

/**
 * @param {Array} posts      every post, including the one just added
 * @param {number} limit     maximum number of posts to keep
 * @param {string} newPostId id of the post just added (never removed)
 * @returns {{ kept: Array, removed: Array }}
 */
function enforcePostLimit(posts, limit, newPostId) {
    const overflow = posts.length - limit;
    if (overflow <= 0) return { kept: posts, removed: [] };

    const removed = posts
        .filter(post => String(post.id) !== String(newPostId))
        .sort(compareOldestFirst)
        .slice(0, overflow);
    const removedIds = new Set(removed.map(post => String(post.id)));
    return { kept: posts.filter(post => !removedIds.has(String(post.id))), removed };
}

module.exports = { enforcePostLimit };
