const express = require('express');
const { writeJsonAtomic } = require('../utils/atomicJson');
const fs = require('fs');
const fsPromises = require('fs').promises;
const path = require('path');
const multer = require('multer');
const router = express.Router();
const { authenticateToken, requirePermission } = require('../middlewares/auth.unified');
const { updateLanguageVariants } = require('../services/translationService');
const { mongoSanitizeConfig, xssConfig } = require('../config/security');
const { sanitizeText, sanitizeHtmlContent } = require('../utils/sanitizeContent');
const {
    IMAGE_MIME_EXTENSIONS,
    createFileFilter,
    generateSafeFilename
} = require('../utils/uploadSecurity');
const {
    normalizeImageUrl,
    normalizeYouTubeEmbedUrl
} = require('../utils/urlSecurity');

console.log('[SyntheseActualite] Routes file loaded');

const DATA_FILE = path.join(__dirname, '../data/syntheseActualite.json');

// Configure multer for synthese uploads
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        const uploadDir = path.join(__dirname, '../uploads/synthese');
        if (!fs.existsSync(uploadDir)) {
            fs.mkdirSync(uploadDir, { recursive: true });
        }
        cb(null, uploadDir);
    },
    filename: (req, file, cb) => {
        cb(null, generateSafeFilename(file.originalname));
    }
});

const upload = multer({
    defParamCharset: 'utf8',
    storage,
    limits: {
        fileSize: 10 * 1024 * 1024,
        fieldSize: 50 * 1024 * 1024,
        files: 20
    },
    fileFilter: createFileFilter({
        groups: [IMAGE_MIME_EXTENSIONS],
        label: 'JPG, PNG, WebP, or GIF images'
    })
});

const SYNTHESE_LIMIT = 40;
const UPLOADS_ROOT = path.resolve(__dirname, '..', 'uploads');

// Upload URLs a post points to (images, plus content when it is a file)
function getUploadedUrls(post) {
    const urls = new Set(Array.isArray(post?.images) ? post.images : []);
    if (typeof post?.content === 'string') urls.add(post.content);
    return [...urls].filter(url => typeof url === 'string'
        && path.resolve(__dirname, '..', '.' + url).startsWith(UPLOADS_ROOT + path.sep));
}

async function deleteSyntheseFiles(post) {
    if (post.images && Array.isArray(post.images)) {
        for (const imageUrl of post.images) {
            if (getUploadedUrls({ images: [imageUrl] }).length > 0) {
                try {
                    const filePath = path.join(__dirname, '..', imageUrl);
                    if (fs.existsSync(filePath)) {
                        await fsPromises.unlink(filePath);
                        console.log(`[SyntheseActualite] ✓ Deleted file: ${imageUrl}`);
                    }
                } catch (err) {
                    console.warn(`[SyntheseActualite] Could not delete file: ${imageUrl}`, err.message);
                }
            }
        }
    } else if (getUploadedUrls({ content: post.content }).length > 0) {
        try {
            const filePath = path.join(__dirname, '..', post.content);
            if (fs.existsSync(filePath)) {
                await fsPromises.unlink(filePath);
                console.log(`[SyntheseActualite] ✓ Deleted file: ${post.content}`);
            }
        } catch (err) {
            console.warn(`[SyntheseActualite] Could not delete file: ${post.content}`, err.message);
        }
    }
}

// Add logging middleware for all requests to this router
router.use((req, res, next) => {
    console.log('[SyntheseActualite Router] Incoming request:', req.method, req.path, req.url);
    next();
});

// Get all synthese posts
router.get('/', async (req, res) => {
    console.log('[SyntheseActualite] GET request handler called');
    try {
        const data = await fsPromises.readFile(DATA_FILE, 'utf-8');
        let posts = JSON.parse(data || '[]');
        // Sort: manual order first (if set), then newest publishDate
        posts.sort((a, b) => {
            if (a.order !== undefined && b.order !== undefined) return a.order - b.order;
            if (a.order !== undefined) return -1;
            if (b.order !== undefined) return 1;
            return new Date(b.publishDate) - new Date(a.publishDate);
        });
        res.json(posts);
    } catch (error) {
        console.error('Error reading synthese posts:', error);
        res.json([]);
    }
});

router.post('/', authenticateToken, requirePermission('edit_news_content'), upload.array('file'), mongoSanitizeConfig(), xssConfig(), async (req, res) => {
    console.log('[SyntheseActualite] POST request received');
    console.log('[SyntheseActualite] Body keys:', Object.keys(req.body || {}));
    try {
        const { title, content, description, type, publishDate, active } = req.body;

        if (!title) {
            return res.status(400).json({ error: 'Title is required' });
        }

        const data = await fsPromises.readFile(DATA_FILE, 'utf-8');
        let posts = JSON.parse(data || '[]');

        let contentUrl = content || '';
        let imagesArray = undefined;

        // Handle multiple file uploads
        if (req.files && req.files.length > 0) {
            const imageUrls = req.files.map(file => `/uploads/synthese/${file.filename}`);
            imagesArray = imageUrls;
            // For backward compatibility, set content to first image
            contentUrl = imageUrls[0];
        }

        if (type === 'video') {
            contentUrl = normalizeYouTubeEmbedUrl(contentUrl);
            if (!contentUrl) {
                return res.status(400).json({ error: 'Invalid video URL. Only YouTube video URLs are allowed.' });
            }
        } else if ((type === 'image' || type === 'poster') && contentUrl) {
            contentUrl = normalizeImageUrl(contentUrl);
        }

        if (Array.isArray(imagesArray)) {
            imagesArray = imagesArray.map((image) => normalizeImageUrl(image)).filter(Boolean);
        }

        const newPost = {
            id: Date.now().toString(),
            type: sanitizeText(type || 'text'),
            title: sanitizeText(title || ''),
            description: sanitizeHtmlContent(description || ''),
            content: sanitizeHtmlContent(contentUrl),
            ...(imagesArray && { images: imagesArray }),
            publishDate: publishDate || new Date().toISOString().split('T')[0],
            active: active === 'true' || active === true,
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString()
        };

        // Automatically translate the post
        try {
            const variants = await updateLanguageVariants(newPost, []);
            newPost.languageVariants = variants;
            console.log('✅ Post automatically translated to all languages');
        } catch (error) {
            console.warn('⚠️  Auto-translation failed, but post will be created:', error.message);
            newPost.languageVariants = [];
        }

        posts.unshift(newPost);

        // Enforce the cap: once over the limit, drop the oldest post(s) and
        // their images instead of letting the list grow unbounded.
        if (posts.length > SYNTHESE_LIMIT) {
            const sorted = [...posts].sort((a, b) => new Date(b.publishDate) - new Date(a.publishDate));
            const toRemove = sorted.slice(SYNTHESE_LIMIT);
            const removeIds = new Set(toRemove.map(p => p.id));
            for (const oldPost of toRemove) {
                await deleteSyntheseFiles(oldPost);
            }
            posts = posts.filter(p => !removeIds.has(p.id));
        }

        writeJsonAtomic(DATA_FILE, posts);

        res.status(201).json(newPost);
    } catch (error) {
        console.error('Error creating synthese post:', error);
        res.status(500).json({ error: 'Failed to create post' });
    }
});

// Update synthese post
router.put('/:id', authenticateToken, requirePermission('edit_news_content'), upload.array('file'), mongoSanitizeConfig(), xssConfig(), async (req, res) => {
    try {
        const { title, content, description, type, publishDate, active } = req.body;
        const { id } = req.params;

        const data = await fsPromises.readFile(DATA_FILE, 'utf-8');
        const posts = JSON.parse(data || '[]');

        const postIndex = posts.findIndex(p => p.id === id);
        if (postIndex === -1) {
            return res.status(404).json({ error: 'Post not found' });
        }

        let contentUrl = posts[postIndex].content;
        let imagesArray = posts[postIndex].images;

        // Handle multiple file uploads
        if (req.files && req.files.length > 0) {
            const imageUrls = req.files.map(file => `/uploads/synthese/${file.filename}`);
            imagesArray = imageUrls;
            // For backward compatibility, set content to first image
            contentUrl = imageUrls[0];
        } else if (content) {
            contentUrl = content;
        }

        const nextType = type || posts[postIndex].type;
        if (nextType === 'video') {
            contentUrl = normalizeYouTubeEmbedUrl(contentUrl);
            if (!contentUrl) {
                return res.status(400).json({ error: 'Invalid video URL. Only YouTube video URLs are allowed.' });
            }
        } else if ((nextType === 'image' || nextType === 'poster') && contentUrl) {
            contentUrl = normalizeImageUrl(contentUrl);
        }

        if (Array.isArray(imagesArray)) {
            imagesArray = imagesArray.map((image) => normalizeImageUrl(image)).filter(Boolean);
        }

        const updatedPost = {
            ...posts[postIndex],
            title: title || posts[postIndex].title,
            content: contentUrl,
            description: description !== undefined ? description : posts[postIndex].description,
            type: type || posts[postIndex].type,
            publishDate: publishDate || posts[postIndex].publishDate,
            active: active !== undefined ? (active === 'true' || active === true) : posts[postIndex].active,
            updatedAt: new Date().toISOString()
        };

        // Only add images property if it exists
        if (imagesArray) {
            updatedPost.images = imagesArray;
        }

        // Re-translate if title, description, or text content changed
        const titleChanged = title !== undefined && title !== posts[postIndex].title;
        const descriptionChanged = description !== undefined && description !== posts[postIndex].description;
        const contentChanged = content !== undefined && content !== posts[postIndex].content;

        if (titleChanged || descriptionChanged || contentChanged) {
            try {
                const variants = await updateLanguageVariants(updatedPost, posts[postIndex].languageVariants || []);
                updatedPost.languageVariants = variants;
                console.log('✅ Post translations updated');
            } catch (error) {
                console.warn('⚠️  Auto-translation update failed:', error.message);
            }
        }

        const previousUploads = getUploadedUrls(posts[postIndex]);
        posts[postIndex] = updatedPost;
        writeJsonAtomic(DATA_FILE, posts);

        // Replaced images are no longer referenced: remove them from disk
        const keptUploads = new Set(getUploadedUrls(updatedPost));
        const replacedUploads = previousUploads.filter(url => !keptUploads.has(url));
        if (replacedUploads.length > 0) {
            await deleteSyntheseFiles({ images: replacedUploads });
        }

        res.json(posts[postIndex]);
    } catch (error) {
        console.error('Error updating synthese post:', error);
        res.status(500).json({ error: 'Failed to update post' });
    }
});

// Delete synthese post
router.delete('/:id', authenticateToken, requirePermission('edit_news_content'), async (req, res) => {
    try {
        const { id } = req.params;
        const data = await fsPromises.readFile(DATA_FILE, 'utf-8');
        const posts = JSON.parse(data || '[]');

        const postToDelete = posts.find(p => p.id === id);
        if (!postToDelete) {
            return res.status(404).json({ error: 'Post not found' });
        }

        // Delete all associated image files
        await deleteSyntheseFiles(postToDelete);

        const filteredPosts = posts.filter(p => p.id !== id);
        await fsPromises.writeFile(DATA_FILE, JSON.stringify(filteredPosts, null, 2));

        res.json({ success: true });
    } catch (error) {
        console.error('Error deleting synthese post:', error);
        res.status(500).json({ error: 'Failed to delete post' });
    }
});

module.exports = router;
