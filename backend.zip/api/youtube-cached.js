const express = require('express');
const router = express.Router();
const fs = require('fs');
const path = require('path');
const { XMLParser } = require('fast-xml-parser');

/**
 * YouTube Videos Route with Caching
 * Falls back to cached data if network fails
 */

const CACHE_FILE = path.join(__dirname, '../data/youtubeCache.json');
const CACHE_DURATION = 24 * 60 * 60 * 1000; // 24 hours

// Load cached videos from file
function getCachedVideos() {
    try {
        if (fs.existsSync(CACHE_FILE)) {
            const data = JSON.parse(fs.readFileSync(CACHE_FILE, 'utf8'));
            if (data.timestamp && Date.now() - data.timestamp < CACHE_DURATION) {
                console.log('[YouTube] ✅ Returning cached videos');
                return { videos: data.videos, source: 'cache', cached: true };
            }
        }
    } catch (err) {
        console.error('[YouTube] Error reading cache:', err.message);
    }
    return null;
}

// Save videos to cache file
function cacheVideos(videos) {
    try {
        const data = { videos, timestamp: Date.now() };
        fs.writeFileSync(CACHE_FILE, JSON.stringify(data, null, 2));
        console.log('[YouTube] 💾 Videos cached to file');
    } catch (err) {
        console.error('[YouTube] Error caching videos:', err.message);
    }
}

// Try to fetch fresh data from YouTube
async function fetchFreshVideos(channel = 'TchadDiplomatie') {
    try {
        console.log(`[YouTube API] Fetching fresh videos for channel: ${channel}`);

        // Step 1: Get channel page to find channel ID
        const channelPageUrl = `https://www.youtube.com/@${channel}`;
        console.log(`[YouTube API] Step 1: Fetching channel page...`);

        const channelPageResp = await fetch(channelPageUrl, {
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
            },
            timeout: 10000
        });

        if (!channelPageResp.ok) {
            console.log(`[YouTube API] ❌ Channel fetch failed with status ${channelPageResp.status}`);
            return null;
        }

        const channelHtml = await channelPageResp.text();
        const channelIdMatch = channelHtml.match(/\"externalId\":\"(UC[^\"]+)\"/);
        if (!channelIdMatch || !channelIdMatch[1]) {
            console.log(`[YouTube API] ❌ Could not extract channel ID from HTML`);
            return null;
        }
        const channelId = channelIdMatch[1];
        console.log(`[YouTube API] ✅ Found channel ID: ${channelId}`);

        // Step 2: Fetch RSS feed
        const rssUrl = `https://www.youtube.com/feeds/videos.xml?channel_id=${channelId}`;
        console.log(`[YouTube API] Step 2: Fetching RSS feed...`);

        const rssResp = await fetch(rssUrl, {
            headers: {
                'User-Agent': 'Mozilla/5.0'
            },
            timeout: 10000
        });

        if (!rssResp.ok) {
            console.log(`[YouTube API] ❌ RSS fetch failed with status ${rssResp.status}`);
            return null;
        }
        const rssText = await rssResp.text();
        console.log(`[YouTube API] ✅ RSS feed fetched (${rssText.length} chars)`);

        // Step 3: Parse XML and map to JSON
        const parser = new XMLParser({ ignoreAttributes: false, attributeNamePrefix: '@_' });
        const xmlData = parser.parse(rssText);
        const feed = xmlData?.feed;
        if (!feed) {
            console.log(`[YouTube API] ❌ Invalid RSS feed format`);
            return null;
        }

        const entries = Array.isArray(feed.entry) ? feed.entry : (feed.entry ? [feed.entry] : []);
        console.log(`[YouTube API] ✅ Found ${entries.length} entries in RSS feed`);

        const videos = entries.slice(0, 12).map((entry) => {
            const videoId = (entry.id || '').toString().split('yt:video:')[1] || '';

            let videoLink = `https://www.youtube.com/watch?v=${videoId}`;
            if (entry.link) {
                if (Array.isArray(entry.link)) {
                    const alternate = entry.link.find((l) => l['@_rel'] === 'alternate');
                    if (alternate && alternate['@_href']) videoLink = alternate['@_href'];
                    else if (entry.link[0] && entry.link[0]['@_href']) videoLink = entry.link[0]['@_href'];
                } else if (typeof entry.link === 'object' && entry.link['@_href']) {
                    videoLink = entry.link['@_href'];
                }
            }

            const thumbnail = entry['media:group']?.['media:thumbnail']?.['@_url'] ||
                `https://i.ytimg.com/vi/${videoId}/sddefault.jpg`;

            return {
                id: videoId,
                title: entry['media:group']?.['media:title'] || entry.title || 'Untitled',
                description: entry['media:group']?.['media:description'] || '',
                link: videoLink,
                thumbnail,
                publishedAt: entry.published,
                channelName: entry.author?.name || feed.title || channel,
            };
        });

        return videos;
    } catch (error) {
        console.error(`[YouTube API] Error fetching fresh data:`, error.message);
        return null;
    }
}

router.get('/', async (req, res) => {
    try {
        const channel = req.query.channel || 'TchadDiplomatie';

        // Try to fetch fresh data
        const freshVideos = await fetchFreshVideos(channel);

        if (freshVideos && freshVideos.length > 0) {
            // Cache the fresh data
            cacheVideos(freshVideos);
            return res.json({
                success: true,
                videos: freshVideos,
                source: 'live',
                channelName: channel
            });
        }

        // If fresh fetch failed, try cache
        console.log('[YouTube] Fresh fetch failed, trying cache...');
        const cached = getCachedVideos();
        if (cached) {
            return res.json({
                success: true,
                videos: cached.videos,
                source: 'cache',
                channelName: channel,
                message: 'Served from cache due to network error'
            });
        }

        // No cache available and network failed
        return res.status(503).json({
            success: false,
            error: 'YouTube service temporarily unavailable',
            videos: [],
            channelName: channel,
            source: 'error',
            message: 'Unable to fetch YouTube videos. Please try again later.'
        });

    } catch (error) {
        console.error('[YouTube] Unexpected error:', error);

        // Try to fall back to cache on any error
        const cached = getCachedVideos();
        if (cached) {
            return res.json({
                success: true,
                videos: cached.videos,
                source: 'cache',
                message: 'Served from cache due to error'
            });
        }

        res.status(500).json({
            success: false,
            error: error.message || 'Internal server error',
            videos: []
        });
    }
});

module.exports = router;