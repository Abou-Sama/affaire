const express = require('express');
const fs = require('fs');
const fsPromises = require('fs').promises;
const path = require('path');
const router = express.Router();
const { updateLanguageVariants } = require('../services/translationService');
const { sanitizeText, sanitizeHtmlContent } = require('../utils/sanitizeContent');

console.log('[PageContent] Routes file loaded');

const DATA_FILE = path.join(__dirname, '../data/pageContent.json');

// Ensure data file exists
async function ensureDataFile() {
    try {
        await fsPromises.access(DATA_FILE);
    } catch {
        await fsPromises.writeFile(DATA_FILE, JSON.stringify({}), 'utf-8');
    }
}

// Get all page content
router.get('/', async (req, res) => {
    console.log('[PageContent] GET all');
    try {
        await ensureDataFile();
        const data = await fsPromises.readFile(DATA_FILE, 'utf-8');
        const content = JSON.parse(data || '{}');
        res.json(content);
    } catch (error) {
        console.error('[PageContent] Error reading:', error);
        res.json({});
    }
});

// Get content for a specific page
router.get('/:pageName', async (req, res) => {
    const { pageName } = req.params;
    console.log('[PageContent] GET page:', pageName);
    try {
        await ensureDataFile();
        const data = await fsPromises.readFile(DATA_FILE, 'utf-8');
        const allContent = JSON.parse(data || '{}');
        const pageContent = allContent[pageName] || {};
        res.json(pageContent);
    } catch (error) {
        console.error('[PageContent] Error reading page:', error);
        res.json({});
    }
});

// Save/Update content for a specific page and element
router.post('/:pageName/:elementId', async (req, res) => {
    const { pageName, elementId } = req.params;
    const { title, content, description, type } = req.body;

    console.log('[PageContent] POST page:', pageName, 'element:', elementId);

    try {
        await ensureDataFile();
        const data = await fsPromises.readFile(DATA_FILE, 'utf-8');
        const allContent = JSON.parse(data || '{}');

        if (!allContent[pageName]) {
            allContent[pageName] = {};
        }

        // Create the element with translations
        const element = {
            title: sanitizeText(title || ''),
            content: sanitizeHtmlContent(content || ''),
            description: sanitizeHtmlContent(description || ''),
            type: sanitizeText(type || 'text'),
            updatedAt: new Date().toISOString()
        };

        // Auto-translate the content to English and Arabic
        try {
            const variants = await updateLanguageVariants(element, []);
            element.languageVariants = variants;
            console.log('✅ Page content automatically translated to all languages');
        } catch (error) {
            console.warn('⚠️  Auto-translation failed, but content will be created:', error.message);
            element.languageVariants = [];
        }

        allContent[pageName][elementId] = element;

        await fsPromises.writeFile(DATA_FILE, JSON.stringify(allContent, null, 2), 'utf-8');
        res.json({ success: true, data: allContent[pageName][elementId] });
    } catch (error) {
        console.error('[PageContent] Error saving:', error);
        res.status(500).json({ error: error.message });
    }
});

// Delete content element
router.delete('/:pageName/:elementId', async (req, res) => {
    const { pageName, elementId } = req.params;

    console.log('[PageContent] DELETE page:', pageName, 'element:', elementId);

    try {
        await ensureDataFile();
        const data = await fsPromises.readFile(DATA_FILE, 'utf-8');
        const allContent = JSON.parse(data || '{}');

        if (allContent[pageName] && allContent[pageName][elementId]) {
            delete allContent[pageName][elementId];
            await fsPromises.writeFile(DATA_FILE, JSON.stringify(allContent, null, 2), 'utf-8');
            res.json({ success: true });
        } else {
            res.status(404).json({ error: 'Element not found' });
        }
    } catch (error) {
        console.error('[PageContent] Error deleting:', error);
        res.status(500).json({ error: error.message });
    }
});

// Bulk save all page content
router.post('/:pageName/bulk', async (req, res) => {
    const { pageName } = req.params;
    const elements = req.body;

    console.log('[PageContent] POST bulk page:', pageName);

    try {
        await ensureDataFile();
        const data = await fsPromises.readFile(DATA_FILE, 'utf-8');
        const allContent = JSON.parse(data || '{}');

        allContent[pageName] = {};
        for (const [elementId, element] of Object.entries(elements)) {
            let elementToSave = {
                ...element,
                updatedAt: new Date().toISOString()
            };

            // Auto-translate each element
            try {
                const variants = await updateLanguageVariants(
                    elementToSave,
                    element.languageVariants || []
                );
                elementToSave.languageVariants = variants;
                console.log(`[PageContent] ✅ Bulk element ${elementId} auto-translated`);
            } catch (error) {
                console.warn(`[PageContent] ⚠️  Bulk element ${elementId} auto-translation failed:`, error.message);
                // Continue anyway - translation failure shouldn't prevent save
                elementToSave.languageVariants = element.languageVariants || [];
            }

            allContent[pageName][elementId] = elementToSave;
        }

        await fsPromises.writeFile(DATA_FILE, JSON.stringify(allContent, null, 2), 'utf-8');
        res.json({ success: true, data: allContent[pageName] });
    } catch (error) {
        console.error('[PageContent] Error bulk saving:', error);
        res.status(500).json({ error: error.message });
    }
});

module.exports = router;
