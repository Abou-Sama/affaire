const express = require('express');
const { writeJsonAtomic } = require('../utils/atomicJson');
const fs = require('fs').promises;
const path = require('path');
const multer = require('multer');
const router = express.Router();
const { authenticateToken, requirePermission } = require('../middlewares/auth.unified');
const { updateLanguageVariants } = require('../services/translationService');
const { mongoSanitizeConfig, xssConfig } = require('../config/security');
const { sanitizeText, sanitizeHtmlContent } = require('../utils/sanitizeContent');
const {
    IMAGE_MIME_EXTENSIONS,
    DOCUMENT_MIME_EXTENSIONS,
    createFileFilter,
    generateSafeFilename
} = require('../utils/uploadSecurity');
const { enforcePostLimit } = require('../utils/postLimit');

const DATA_FILE = path.join(__dirname, '../data/recrutement.json');
const UPLOADS_DIR = path.join(__dirname, '../uploads/recrutement');

// Ensure uploads directory exists
const ensureUploadsDir = async () => {
    try {
        await fs.mkdir(UPLOADS_DIR, { recursive: true });
    } catch (error) {
        console.error('Error creating uploads directory:', error);
    }
};

ensureUploadsDir();

// Configure multer for recruitment uploads
const storage = multer.diskStorage({
    destination: async (req, file, cb) => {
        await ensureUploadsDir();
        cb(null, UPLOADS_DIR);
    },
    filename: (req, file, cb) => {
        cb(null, generateSafeFilename(file.originalname));
    }
});

const upload = multer({
    defParamCharset: 'utf8',
    storage,
    limits: {
        fileSize: 20 * 1024 * 1024,
        fieldSize: 50 * 1024 * 1024,
        files: 20
    },
    fileFilter: createFileFilter({
        groups: [IMAGE_MIME_EXTENSIONS, DOCUMENT_MIME_EXTENSIONS],
        label: 'images or PDF documents'
    })
});

// Reply with a readable JSON error when an upload is refused, instead of a bare 500
const uploadFiles = (req, res, next) => upload.array('file')(req, res, (err) => {
    if (!err) return next();
    const messages = {
        LIMIT_FILE_SIZE: 'Fichier trop volumineux (20 Mo maximum).',
        LIMIT_FILE_COUNT: 'Trop de fichiers (20 maximum).'
    };
    return res.status(400).json({ success: false, error: messages[err.code] || err.message });
});

// Initialize data file if it doesn't exist
const initializeDataFile = async () => {
    try {
        await fs.access(DATA_FILE);
    } catch (error) {
        await fs.writeFile(DATA_FILE, JSON.stringify([], null, 2));
    }
};

initializeDataFile();

const RECRUTEMENT_LIMIT = 40;
const UPLOADS_ROOT = path.resolve(__dirname, '..', 'uploads');

// Only files inside backend/uploads may ever be deleted
const isUploadedFile = (url) => typeof url === 'string'
    && path.resolve(__dirname, '..', '.' + url).startsWith(UPLOADS_ROOT + path.sep);

async function deleteRecrutementFiles(post) {
    if (post.files && post.files.length > 0) {
        for (const file of post.files) {
            if (!isUploadedFile(file.url)) continue;
            try {
                const filePath = path.join(__dirname, '..', file.url);
                await fs.unlink(filePath);
                console.log(`[Recrutement] ✓ Deleted file: ${file.url}`);
            } catch (err) {
                console.warn(`[Recrutement] Could not delete file: ${file.url}`, err.message);
            }
        }
    }
}

// DEBUGGING MIDDLEWARE - Log all requests to this router
router.use((req, res, next) => {
    console.log(`\n[RECRUTEMENT ROUTER] Incoming: ${req.method} ${req.path} ${req.url}`);
    next();
});

// Get all recruitment posts (with optional active filter)
router.get('/', async (req, res) => {
    try {
        const data = await fs.readFile(DATA_FILE, 'utf-8');
        let posts = JSON.parse(data || '[]');

        // Filter by active status if query parameter is provided
        if (req.query.active === 'true') {
            posts = posts.filter(p => p.active === true);
        }

        // Sort by date descending
        posts.sort((a, b) => new Date(b.publishDate) - new Date(a.publishDate));

        res.json(posts);
    } catch (error) {
        console.error('Error reading recruitment posts:', error);
        res.json([]);
    }
});

// Create new recruitment post with multiple file uploads
router.post('/', authenticateToken, requirePermission('manage_recrutement'), uploadFiles, mongoSanitizeConfig(), xssConfig(), async (req, res) => {
    try {
        console.log('[Recrutement POST] Handler called');
        const { title, category, description, content, publishDate, active } = req.body;

        if (!category) {
            return res.status(400).json({ error: 'Category is required' });
        }

        const data = await fs.readFile(DATA_FILE, 'utf-8');
        let posts = JSON.parse(data || '[]');

        // Process uploaded files
        const files = [];
        if (req.files && req.files.length > 0) {
            req.files.forEach(file => {
                files.push({
                    filename: file.originalname,
                    url: `/uploads/recrutement/${file.filename}`,
                    type: file.mimetype.includes('image') ? 'image' : 'document'
                });
            });
        }

        const newPost = {
            id: Date.now().toString(),
            category: sanitizeText(category || ''),
            title: sanitizeText(title || ''),
            description: sanitizeHtmlContent(description || ''),
            content: sanitizeHtmlContent(content || ''),
            files: files.length > 0 ? files : undefined,
            publishDate: publishDate || new Date().toISOString().split('T')[0],
            active: active !== false, // default to true
            createdAt: new Date().toISOString()
        };

        // Automatically translate the post
        try {
            const variants = await updateLanguageVariants(newPost, []);
            newPost.languageVariants = variants;
            console.log('✅ Post automatically translated to all languages');
        } catch (error) {
            console.warn('⚠️  Auto-translation failed, but post will be created:', error.message);
            // Continue anyway - translation failure shouldn't prevent post creation
            newPost.languageVariants = [];
        }

        posts.push(newPost);

        // Cap at RECRUTEMENT_LIMIT posts: adding one more removes the oldest (and its files).
        // The new post is never the one removed, even if it was given an older publication date.
        const { kept, removed } = enforcePostLimit(posts, RECRUTEMENT_LIMIT, newPost.id);
        posts = kept;

        writeJsonAtomic(DATA_FILE, posts);
        for (const oldPost of removed) {
            await deleteRecrutementFiles(oldPost);
        }

        return res.status(201).json({
            success: true,
            message: 'Post created successfully with automatic translations',
            data: newPost,
            removedOldPosts: removed.length
        });
    } catch (error) {
        console.error('[Recrutement POST] Error:', error);
        return res.status(500).json({
            success: false,
            error: 'Error creating post',
            details: error.message
        });
    }
});

// Get single recruitment post
router.get('/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const data = await fs.readFile(DATA_FILE, 'utf-8');
        const posts = JSON.parse(data || '[]');

        const post = posts.find(p => p.id === id);
        if (!post) {
            return res.status(404).json({ error: 'Post not found' });
        }

        res.json(post);
    } catch (error) {
        console.error('Error reading post:', error);
        res.status(500).json({ error: 'Failed to read post' });
    }
});

router.put('/:id', authenticateToken, requirePermission('manage_recrutement'), uploadFiles, mongoSanitizeConfig(), xssConfig(), async (req, res) => {
    try {
        const { title, category, description, content, publishDate, active } = req.body;
        const { id } = req.params;

        const data = await fs.readFile(DATA_FILE, 'utf-8');
        const posts = JSON.parse(data || '[]');

        const postIndex = posts.findIndex(p => p.id === id);
        if (postIndex === -1) {
            return res.status(404).json({ error: 'Post not found' });
        }

        // Store old values for comparison
        const oldPost = posts[postIndex];
        const oldTitle = oldPost.title;
        const oldDescription = oldPost.description;
        const oldContent = oldPost.content;

        // Process newly uploaded files
        let files = oldPost.files || [];
        if (req.files && req.files.length > 0) {
            const newFiles = [];
            req.files.forEach(file => {
                newFiles.push({
                    filename: file.originalname,
                    url: `/uploads/recrutement/${file.filename}`,
                    type: file.mimetype.includes('image') ? 'image' : 'document'
                });
            });
            files = newFiles;
        }

        posts[postIndex] = {
            ...oldPost,
            title: title !== undefined ? title : oldTitle,
            category: category !== undefined ? category : oldPost.category,
            description: description !== undefined ? description : oldDescription,
            content: content !== undefined ? content : oldPost.content,
            publishDate: publishDate !== undefined ? publishDate : oldPost.publishDate,
            active: active !== undefined ? (active === 'true' || active === true) : oldPost.active,
            files: files.length > 0 ? files : undefined,
            updatedAt: new Date().toISOString()
        };

        // Re-translate if title, description, or content changed
        const titleChanged = title !== undefined && title !== oldTitle;
        const descriptionChanged = description !== undefined && description !== oldDescription;
        const contentChanged = content !== undefined && content !== oldContent;

        if (titleChanged || descriptionChanged || contentChanged) {
            try {
                const variants = await updateLanguageVariants(posts[postIndex], oldPost.languageVariants || []);
                posts[postIndex].languageVariants = variants;
                console.log('✅ Post translations updated');
            } catch (error) {
                console.warn('⚠️  Auto-translation update failed:', error.message);
            }
        }

        writeJsonAtomic(DATA_FILE, posts);

        // Replaced files are no longer referenced: remove them from disk
        const keptUrls = new Set((posts[postIndex].files || []).map(file => file.url));
        const replacedFiles = (oldPost.files || []).filter(file => isUploadedFile(file.url) && !keptUrls.has(file.url));
        if (replacedFiles.length > 0) {
            await deleteRecrutementFiles({ files: replacedFiles });
        }

        res.json(posts[postIndex]);
    } catch (error) {
        console.error('Error updating post:', error);
        res.status(500).json({ error: 'Failed to update post' });
    }
});

router.delete('/:id', authenticateToken, requirePermission('manage_recrutement'), async (req, res) => {
    try {
        const { id } = req.params;
        console.log(`[Recrutement DELETE] Attempting to delete post with ID: ${id}`);
        console.log(`[Recrutement DELETE] Full URL: ${req.originalUrl}`);

        const data = await fs.readFile(DATA_FILE, 'utf-8');
        let posts = JSON.parse(data || '[]');

        const postIndex = posts.findIndex(p => p.id === id);
        if (postIndex === -1) {
            console.error(`[Recrutement DELETE] Post not found. ID: ${id}`);
            console.error(`[Recrutement DELETE] Available IDs: ${posts.map(p => p.id).join(', ')}`);
            return res.status(404).json({ error: 'Post not found' });
        }

        console.log(`[Recrutement DELETE] ✓ Found post at index ${postIndex}`);

        // Delete associated files
        const post = posts[postIndex];
        await deleteRecrutementFiles(post);

        posts.splice(postIndex, 1);
        writeJsonAtomic(DATA_FILE, posts);

        console.log(`[Recrutement DELETE] ✓ Post deleted successfully`);
        res.json({ success: true, message: 'Post deleted successfully' });
    } catch (error) {
        console.error('[Recrutement DELETE] Error:', error);
        res.status(500).json({ error: 'Failed to delete post', details: error.message });
    }
});

/**
 * Share recruitment post
 * GET /api/recrutement-posts/:id/share
 * Returns shareable link and metadata for social sharing
 */
router.get('/:id/share', async (req, res) => {
    try {
        const { id } = req.params;

        const data = await fs.readFile(DATA_FILE, 'utf-8');
        const posts = JSON.parse(data || '[]');

        const post = posts.find(p => p.id === id);
        if (!post) {
            return res.status(404).json({
                success: false,
                error: 'Post not found'
            });
        }

        // Construct frontend URL (works for both localhost and Hostinger)
        // Takes first URL from comma-separated list in FRONTEND_URL
        const urls = (process.env.FRONTEND_URL || 'https://diplomatie.td').split(',');
        const baseUrl = urls[0].trim();
        const shareLink = `${baseUrl}#recrutement-post?id=${id}`;

        // Create share text
        const shareText = `${post.title} - ${post.category}`;
        const shareDescription = post.description || 'Offre de recrutement international';

        res.json({
            success: true,
            data: {
                id: post.id,
                title: post.title,
                category: post.category,
                description: shareDescription,
                shareLink,
                socialLinks: {
                    facebook: `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(shareLink)}&quote=${encodeURIComponent(shareText)}`,
                    twitter: `https://twitter.com/intent/tweet?text=${encodeURIComponent(shareText)}&url=${encodeURIComponent(shareLink)}&hashtags=recrutement,ministere`,
                    whatsapp: `https://api.whatsapp.com/send?text=${encodeURIComponent(shareText + ' ' + shareLink)}`,
                    email: `mailto:?subject=${encodeURIComponent(shareText)}&body=${encodeURIComponent(shareDescription + '\n\n' + shareLink)}`,
                    linkedin: `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(shareLink)}`
                }
            }
        });
    } catch (error) {
        console.error('Error generating share link:', error);
        res.status(500).json({
            success: false,
            error: 'Failed to generate share link'
        });
    }
});

module.exports = router;
