/**
 * Translation endpoint for post title, description, and long text content.
 * Uses MyMemory in chunks so long posts are not silently saved untranslated.
 */

const fetch = (...args) => import('node-fetch').then(({ default: fetch }) => fetch(...args));

const MAX_CHUNK_SIZE = 450;
const CACHE_DURATION = 24 * 60 * 60 * 1000;
const cache = new Map();

function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

function splitParagraphIntoChunks(text, maxSize = MAX_CHUNK_SIZE) {
    const normalized = String(text || '').trim();
    if (!normalized) return [];

    const chunks = [];
    const pushSizedText = (value) => {
        const textValue = String(value || '').trim();
        if (!textValue) return;

        for (let i = 0; i < textValue.length; i += maxSize) {
            chunks.push(textValue.slice(i, i + maxSize));
        }
    };

    if (normalized.length <= maxSize) {
        chunks.push(normalized);
        return chunks;
    }

    const sentences = normalized
        .split(/(?<=[.!?;:])\s+/)
        .filter(Boolean);

    let current = '';
    const pushCurrent = () => {
        pushSizedText(current);
        current = '';
    };

    for (const sentence of sentences) {
        if (sentence.length > maxSize) {
            pushCurrent();
            const words = sentence.split(/\s+/);
            for (const word of words) {
                if (word.length > maxSize) {
                    pushCurrent();
                    pushSizedText(word);
                    continue;
                }

                if ((current + ' ' + word).trim().length > maxSize) {
                    pushCurrent();
                }
                current = `${current} ${word}`.trim();
            }
            continue;
        }

        if ((current + ' ' + sentence).trim().length > maxSize) {
            pushCurrent();
        }
        current = `${current} ${sentence}`.trim();
    }

    pushCurrent();
    return chunks;
}

function splitLongText(text, maxSize = MAX_CHUNK_SIZE) {
    const normalized = String(text || '').trim();
    if (!normalized) return [];

    return normalized
        .split(/\n{2,}/)
        .map(paragraph => splitParagraphIntoChunks(paragraph, maxSize))
        .filter(chunks => chunks.length > 0);
}

async function translateChunk(text, sourceLanguage, targetLanguage, retries = 3) {
    const cacheKey = `${sourceLanguage}|${targetLanguage}|${text}`;
    const cached = cache.get(cacheKey);
    if (cached && Date.now() - cached.timestamp < CACHE_DURATION) {
        return cached.value;
    }

    for (let attempt = 1; attempt <= retries; attempt += 1) {
        try {
            const url = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=${sourceLanguage}&tl=${targetLanguage}&dt=t&q=${encodeURIComponent(text)}`;
            const controller = new AbortController();
            const timeout = setTimeout(() => controller.abort(), 20000);

            const response = await fetch(url, {
                method: 'GET',
                headers: { Accept: 'application/json' },
                signal: controller.signal
            });
            clearTimeout(timeout);

            const data = await response.json();
            const translated = Array.isArray(data?.[0])
                ? data[0].map(part => part?.[0] || '').join('')
                : '';

            if (response.ok && translated) {
                cache.set(cacheKey, { value: translated, timestamp: Date.now() });
                return translated;
            }

            console.warn(`[TRANSLATE] Google ${targetLanguage} chunk attempt ${attempt} failed: HTTP ${response.status}`);
        } catch (error) {
            console.warn(`[TRANSLATE] Google ${targetLanguage} chunk attempt ${attempt} failed: ${error.message}`);
        }

        try {
            const url = `https://api.mymemory.translated.net/get?q=${encodeURIComponent(text)}&langpair=${sourceLanguage}|${targetLanguage}`;
            const response = await fetch(url, {
                method: 'GET',
                headers: { Accept: 'application/json' }
            });
            const data = await response.json();
            const translated = data?.responseData?.translatedText;

            if (response.ok && data.responseStatus === 200 && translated) {
                cache.set(cacheKey, { value: translated, timestamp: Date.now() });
                return translated;
            }

            const message = data?.responseData?.error || data?.responseDetails || `HTTP ${response.status}`;
            console.warn(`[TRANSLATE] MyMemory ${targetLanguage} chunk attempt ${attempt} failed: ${message}`);
        } catch (error) {
            console.warn(`[TRANSLATE] MyMemory ${targetLanguage} chunk attempt ${attempt} failed: ${error.message}`);
        }

        if (attempt < retries) {
            await sleep(attempt * 1000);
        }
    }

    throw new Error(`Unable to translate text to ${targetLanguage}`);
}

async function translateUnlimited(text, sourceLanguage, targetLanguage) {
    const source = String(text || '');
    if (!source.trim()) return '';
    if (sourceLanguage === targetLanguage) return source;

    const paragraphs = splitLongText(source);
    const translatedParagraphs = [];

    for (const paragraphChunks of paragraphs) {
        const translatedChunks = [];

        for (const chunk of paragraphChunks) {
            translatedChunks.push(await translateChunk(chunk, sourceLanguage, targetLanguage));
            await sleep(250);
        }

        translatedParagraphs.push(
            translatedChunks
                .map(chunk => String(chunk || '').trim())
                .filter(Boolean)
                .join(' ')
        );
    }

    return translatedParagraphs.join('\n\n');
}

function sameText(a, b) {
    return String(a || '').trim().toLowerCase() === String(b || '').trim().toLowerCase();
}

function validateTranslated(targetLanguage, original, translated) {
    const originalValues = [original.title, original.description, original.content].filter(v => String(v || '').trim());
    const translatedValues = [translated.title, translated.description, translated.content].filter(v => String(v || '').trim());

    if (originalValues.length === 0) return;
    if (translatedValues.length === 0) {
        throw new Error(`No translated text returned for ${targetLanguage}`);
    }

    const allSame = originalValues.every((value, index) => sameText(value, translatedValues[index]));
    if (allSame) {
        throw new Error(`Translation service returned the original text for ${targetLanguage}`);
    }
}

module.exports = function setupTranslateRoute(app) {
    app.post('/api/translate', async (req, res) => {
        console.log('\n[TRANSLATE] POST /api/translate called');

        try {
            let { title = '', description = '', content = '', sourceLanguage = 'fr' } = req.body || {};
            title = String(title || '');
            description = String(description || '');
            content = String(content || '');
            sourceLanguage = String(sourceLanguage || 'fr');

            if (!title.trim() && !description.trim() && !content.trim()) {
                return res.status(400).json({ error: 'Title, description, or content required' });
            }

            const original = { title, description, content };

            const en = {
                title: await translateUnlimited(title, sourceLanguage, 'en'),
                description: await translateUnlimited(description, sourceLanguage, 'en'),
                content: await translateUnlimited(content, sourceLanguage, 'en')
            };

            const ar = {
                title: await translateUnlimited(title, sourceLanguage, 'ar'),
                description: await translateUnlimited(description, sourceLanguage, 'ar'),
                content: await translateUnlimited(content, sourceLanguage, 'ar')
            };

            validateTranslated('en', original, en);
            validateTranslated('ar', original, ar);

            res.json({ en, ar });
        } catch (error) {
            console.error('[TRANSLATE] Error:', error.message);
            res.status(502).json({ error: error.message });
        }
    });

    console.log('[TRANSLATE] Translation endpoint registered at /api/translate');
};

// Reused by other routes (e.g. minister pages auto-translation)
module.exports.translateUnlimited = translateUnlimited;
