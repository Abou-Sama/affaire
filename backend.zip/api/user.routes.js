const express = require('express');
const router = express.Router();
const userController = require('../controllers/userController');
const { authenticateToken, requireAdmin } = require('../middlewares/auth.middleware');
const { apiRateLimiter } = require('../config/security');
const { User } = require('../models-sequelize');
const logger = require('../config/logger');
const {
    validateAdminUserCreation,
    validateObjectId,
    sanitizeInput
} = require('../middlewares/validation.middleware');

/**
 * User Management Routes (Admin only)
 * @route /api/users
 */

// All user routes require authentication and admin role
router.use(authenticateToken, requireAdmin, apiRateLimiter);

router.get('/', userController.getAllUsers);
router.get('/stats', userController.getUserStats);
router.get('/:id', validateObjectId, userController.getUserById);
router.post('/', sanitizeInput, validateAdminUserCreation, userController.createUser);
router.put('/:id', validateObjectId, sanitizeInput, userController.updateUser);
router.delete('/:id', validateObjectId, userController.deleteUser);

/**
 * Admin reset user password
 * POST /api/users/:id/reset-password
 */
router.post('/:id/reset-password', validateObjectId, sanitizeInput, async (req, res, next) => {
    try {
        const { newPassword } = req.body;
        const { id } = req.params;

        if (!newPassword) {
            return res.status(400).json({
                success: false,
                error: 'New password is required'
            });
        }

        if (newPassword.length < 8) {
            return res.status(400).json({
                success: false,
                error: 'Password must be at least 8 characters'
            });
        }

        const user = await User.findByPk(id);
        if (!user) {
            return res.status(404).json({
                success: false,
                error: 'User not found'
            });
        }

        // Update password (will be hashed by Sequelize beforeUpdate hook)
        user.password = newPassword;
        await user.save();

        logger.info(`Password reset for user: ${user.username} by admin: ${req.user.username}`);

        res.json({
            success: true,
            message: `Password reset successfully for user ${user.username}`,
            data: {
                userId: user.id,
                username: user.username,
                message: `${user.username} can now login with the new password`
            }
        });
    } catch (error) {
        logger.error('Password reset error:', error);
        next(error);
    }
});

module.exports = router;
