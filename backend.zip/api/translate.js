/**
 * Simple Translation Endpoint
 * Single endpoint for translating text to EN and AR
 * No complex logic, just direct MyMemory API calls
 */

const express = require('express');
const router = express.Router();
const fetch = require('node-fetch');

// Simple in-memory cache for translations (optional, very basic)
const translationCache = new Map();

/**
 * Translate a single piece of text via MyMemory
 * @param {string} text - Text to translate
 * @param {string} sourceLang - Source language (e.g., 'fr')
 * @param {string} targetLang - Target language (e.g., 'en', 'ar')
 * @returns {Promise<string>} Translated text or original if error
 */
async function translateText(text, sourceLang, targetLang) {
    if (!text || !text.trim()) {
        return text;
    }

    const cacheKey = `${text}|${sourceLang}|${targetLang}`;

    // Check cache
    if (translationCache.has(cacheKey)) {
        console.log(`[Translate] ♻️ Cache hit for ${targetLang}`);
        return translationCache.get(cacheKey);
    }

    try {
        const encodedText = encodeURIComponent(text);
        const url = `https://api.mymemory.translated.net/get?q=${encodedText}&langpair=${sourceLang}|${targetLang}`;

        console.log(`[Translate] 🌍 Calling MyMemory API for ${targetLang}...`);
        console.log(`[Translate] URL: ${url.substring(0, 100)}...`);

        const response = await fetch(url);

        if (!response.ok) {
            console.warn(`[Translate] ⚠️ HTTP ${response.status} from MyMemory`);
            return text; // Return original on error
        }

        const data = await response.json();
        console.log(`[Translate] MyMemory response:`, data.responseStatus, data.responseData?.translatedText?.substring(0, 50));

        if (data.responseStatus === 200 && data.responseData?.translatedText) {
            const translated = data.responseData.translatedText;

            // Cache it
            translationCache.set(cacheKey, translated);

            console.log(`[Translate] ✅ Successfully translated to ${targetLang}`);
            return translated;
        }

        console.warn(`[Translate] ⚠️ Invalid response for ${targetLang}: status=${data.responseStatus}`);
        return text;
    } catch (error) {
        console.error(`[Translate] ❌ Error translating to ${targetLang}:`, error.message);
        return text; // Return original on error
    }
}

/**
 * POST /api/translate
 * Translate title and description to EN and AR
 * 
 * Request body:
 * {
 *   "title": "French title",
 *   "description": "French description",
 *   "sourceLanguage": "fr"  // optional
 * }
 * 
 * Response:
 * {
 *   "en": { "title": "...", "description": "..." },
 *   "ar": { "title": "...", "description": "..." }
 * }
 */
router.post('/', async (req, res) => {
    console.log(`\n🔴 [Translate API] POST handler CALLED`);
    try {
        const { title, description, sourceLanguage = 'fr' } = req.body;

        console.log(`[Translate API] 📥 Received request:`);
        console.log(`   Title: "${title?.substring(0, 50)}${title?.length > 50 ? '...' : ''}"`);
        console.log(`   Description: "${description?.substring(0, 50)}${description?.length > 50 ? '...' : ''}"`);
        console.log(`   Source language: ${sourceLanguage}`);

        if (!title && !description) {
            return res.status(400).json({
                error: 'Title or description is required'
            });
        }

        console.log(`[Translate API] 🌐 Starting translation...`);

        // Translate title
        console.log(`[Translate API] Translating title...`);
        const titleEn = await translateText(title || '', sourceLanguage, 'en');
        const titleAr = await translateText(title || '', sourceLanguage, 'ar');

        // Small delay to avoid rate limiting
        await new Promise(resolve => setTimeout(resolve, 1000));

        // Translate description
        console.log(`[Translate API] Translating description...`);
        const descriptionEn = await translateText(description || '', sourceLanguage, 'en');
        const descriptionAr = await translateText(description || '', sourceLanguage, 'ar');

        const result = {
            en: {
                title: titleEn,
                description: descriptionEn
            },
            ar: {
                title: titleAr,
                description: descriptionAr
            }
        };

        console.log(`[Translate API] ✅ Translation complete`);
        console.log(`   EN Title: "${titleEn.substring(0, 50)}..."`);
        console.log(`   AR Title: "${titleAr.substring(0, 50)}..."`);
        res.json(result);

    } catch (error) {
        console.error('[Translate API] ❌ Error:', error);
        res.status(500).json({
            error: 'Translation failed',
            details: error.message
        });
    }
});

/**
 * GET /api/translate/stats
 * Get cache statistics
 */
router.get('/stats', (req, res) => {
    res.json({
        cacheSize: translationCache.size,
        service: 'SimpleTranslate',
        status: 'operational'
    });
});

module.exports = router;
