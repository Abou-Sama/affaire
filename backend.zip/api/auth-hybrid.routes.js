/**
 * Hybrid Authentication Routes
 * Works with both database and JSON
 * Perfect for Hostinger deployment
 */

const express = require('express');
const router = express.Router();
const authControllerHybrid = require('../controllers/authControllerHybrid');
const { authenticateToken, requireAdmin } = require('../middlewares/authMiddlewareHybrid');
const { authRateLimiter } = require('../config/security');
const { sanitizeInput, validateLogin, validateSignup } = require('../middlewares/validation.middleware');

/**
 * Public Routes (with rate limiting)
 */
router.post('/login', authRateLimiter, sanitizeInput, validateLogin, authControllerHybrid.login);
router.post('/signup', authRateLimiter, (req, res) => {
    res.status(403).json({
        success: false,
        error: 'User registration is disabled. Only administrators can create users.'
    });
});
router.post('/refresh', authRateLimiter, authControllerHybrid.refreshToken);
router.post('/reset-password', authRateLimiter, authControllerHybrid.resetPassword);

/**
 * Protected Routes (require authentication)
 */
router.use(authenticateToken);

router.get('/profile', authControllerHybrid.getProfile);
router.put('/profile', sanitizeInput, authControllerHybrid.updateProfile);
router.post('/change-password', sanitizeInput, authControllerHybrid.changePassword);
router.post('/logout', authControllerHybrid.logout);

module.exports = router;
