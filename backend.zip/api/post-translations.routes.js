const express = require('express');
const fs = require('fs').promises;
const path = require('path');
const router = express.Router();
const { authenticateToken, hasUserPermission } = require('../middlewares/auth.unified');

// Data files for different post types
const DATA_FILES = {
    recrutement: path.join(__dirname, '../data/recrutement.json'),
    synthese: path.join(__dirname, '../data/syntheseActualite.json'),
    'home-content': path.join(__dirname, '../data/homeContents.json'),
    'page-content': path.join(__dirname, '../data/pageContent.json')
};

const POST_TYPE_PERMISSIONS = {
    recrutement: 'manage_recrutement',
    synthese: 'edit_news_content',
    'home-content': 'edit_home_content',
    'page-content': 'edit_all_text'
};

function requirePostTypePermission(req, res, next) {
    const permission = POST_TYPE_PERMISSIONS[req.params.postType] || POST_TYPE_PERMISSIONS['home-content'];

    if (!req.user) {
        return res.status(401).json({ error: 'Not authenticated' });
    }

    if (!hasUserPermission(req.user, permission)) {
        return res.status(403).json({ error: `Permission required: ${permission}` });
    }

    next();
}

/**
 * GET /api/post-translations/stats
 * Get translation statistics for all posts
 */
router.get('/stats/all', async (req, res) => {
    try {
        const stats = {};

        for (const [type, dataFile] of Object.entries(DATA_FILES)) {
            const data = await fs.readFile(dataFile, 'utf-8');
            const parsed = JSON.parse(data || '[]');
            // pageContent.json is a keyed object, not a list of posts
            const posts = Array.isArray(parsed) ? parsed : Object.values(parsed || {});

            stats[type] = {
                total: posts.length,
                fullyTranslated: posts.filter(p =>
                    p.languageVariants && p.languageVariants.length >= 2
                ).length,
                partiallyTranslated: posts.filter(p =>
                    p.languageVariants && p.languageVariants.length === 1
                ).length,
                notTranslated: posts.filter(p =>
                    !p.languageVariants || p.languageVariants.length === 0
                ).length
            };
        }

        res.json(stats);
    } catch (error) {
        console.error('Error fetching translation stats:', error);
        res.status(500).json({ error: 'Failed to fetch statistics' });
    }
});

/**
 * GET /api/post-translations/:postType/:postId
 * Get translation variants for a specific post
 */
router.get('/:postType/:postId', async (req, res) => {
    try {
        const { postType, postId } = req.params;
        const dataFile = DATA_FILES[postType];

        if (!dataFile) {
            return res.status(400).json({ error: 'Invalid post type' });
        }

        const data = await fs.readFile(dataFile, 'utf-8');
        const posts = JSON.parse(data || '[]');
        const post = posts.find(p => p.id === postId);

        if (!post) {
            return res.status(404).json({ error: 'Post not found' });
        }

        res.json({
            id: post.id,
            title: post.title,
            description: post.description || '',
            content: post.content || '',
            languageVariants: post.languageVariants || []
        });
    } catch (error) {
        console.error('Error fetching translation:', error);
        res.status(500).json({ error: 'Failed to fetch translation' });
    }
});

/**
 * POST /api/post-translations/:postType/:postId
 * Add or update a language variant for a post
 */
router.post('/:postType/:postId', authenticateToken, requirePostTypePermission, async (req, res) => {
    try {
        const { postType, postId } = req.params;
        const { language, title, description, content } = req.body;

        if (!['fr', 'en', 'ar'].includes(language)) {
            return res.status(400).json({ error: 'Invalid language code' });
        }

        const dataFile = DATA_FILES[postType];
        if (!dataFile) {
            return res.status(400).json({ error: 'Invalid post type' });
        }

        const data = await fs.readFile(dataFile, 'utf-8');
        let posts = JSON.parse(data || '[]');

        const postIndex = posts.findIndex(p => p.id === postId);
        if (postIndex === -1) {
            return res.status(404).json({ error: 'Post not found' });
        }

        const post = posts[postIndex];

        // Initialize languageVariants array if it doesn't exist
        if (!post.languageVariants) {
            post.languageVariants = [];
        }

        // Find or create variant for this language
        const variantIndex = post.languageVariants.findIndex(v => v.language === language);
        if (variantIndex >= 0) {
            // Update existing variant
            post.languageVariants[variantIndex] = {
                language,
                title: title || post.languageVariants[variantIndex].title,
                description: description || post.languageVariants[variantIndex].description,
                ...(content && { content })
            };
        } else {
            // Add new variant
            post.languageVariants.push({
                language,
                title,
                description,
                ...(content && { content })
            });
        }

        posts[postIndex] = post;
        await fs.writeFile(dataFile, JSON.stringify(posts, null, 2));

        res.json({
            message: 'Translation saved successfully',
            post: post
        });
    } catch (error) {
        console.error('Error saving translation:', error);
        res.status(500).json({ error: 'Failed to save translation' });
    }
});

/**
 * GET /api/post-translations/:postType/:postId/missing-languages
 * Get list of languages that don't have translations for this post
 */
router.get('/:postType/:postId/missing-languages', async (req, res) => {
    try {
        const { postType, postId } = req.params;
        const dataFile = DATA_FILES[postType];

        if (!dataFile) {
            return res.status(400).json({ error: 'Invalid post type' });
        }

        const data = await fs.readFile(dataFile, 'utf-8');
        const posts = JSON.parse(data || '[]');
        const post = posts.find(p => p.id === postId);

        if (!post) {
            return res.status(404).json({ error: 'Post not found' });
        }

        const allLanguages = ['fr', 'en', 'ar'];
        const translatedLanguages = post.languageVariants?.map(v => v.language) || [];
        const missingLanguages = allLanguages.filter(lang => !translatedLanguages.includes(lang));

        // Always exclude the original language if it has a language property
        const missing = post.language ? missingLanguages.filter(lang => lang !== post.language) : missingLanguages;

        res.json({ missingLanguages: missing });
    } catch (error) {
        console.error('Error fetching missing languages:', error);
        res.status(500).json({ error: 'Failed to fetch missing languages' });
    }
});


/**
 * POST /api/post-translations/:postType/:postId/auto-translate
 * Automatically translate the post's title/description (and content if present)
 * to EN and AR using the server-side translation service.
 */
router.post('/:postType/:postId/auto-translate', authenticateToken, requirePostTypePermission, async (req, res) => {
    try {
        const { postType, postId } = req.params;
        const dataFile = DATA_FILES[postType];

        if (!dataFile) {
            return res.status(400).json({ error: 'Invalid post type' });
        }

        const data = await fs.readFile(dataFile, 'utf-8');
        let posts = JSON.parse(data || '[]');
        const postIndex = posts.findIndex(p => p.id === postId);
        if (postIndex === -1) {
            return res.status(404).json({ error: 'Post not found' });
        }

        const post = posts[postIndex];

        // Use translation service directly
        const { updateLanguageVariants } = require('../services/translationService');
        const variants = await updateLanguageVariants(post, post.languageVariants || []);

        post.languageVariants = variants;

        // Save updated post
        posts[postIndex] = post;
        await fs.writeFile(dataFile, JSON.stringify(posts, null, 2));

        return res.json({ message: 'Auto-translation completed', post, variants: post.languageVariants });
    } catch (error) {
        console.error('[AutoTranslate] Error:', error);
        return res.status(500).json({ error: 'Auto-translation failed' });
    }
});



/**
 * DELETE /api/post-translations/cleanup/home-content
 * Remove posts 41+ from home-content (keep only posts 1-40)
 * This permanently deletes posts beyond the display limit and their images
 */
router.delete('/cleanup/home-content', authenticateToken, (req, res, next) => {
    req.params.postType = 'home-content';
    requirePostTypePermission(req, res, next);
}, async (req, res) => {
    try {
        const dataFile = DATA_FILES['home-content'];
        const data = await fs.readFile(dataFile, 'utf-8');
        let posts = JSON.parse(data || '[]');

        const originalCount = posts.length;
        // Keep only first 40 posts (indices 0-39)
        posts = posts.slice(0, 40);
        const removedCount = originalCount - posts.length;

        // Write back the cleaned data
        await fs.writeFile(dataFile, JSON.stringify(posts, null, 2));

        res.json({
            message: 'Cleanup completed',
            originalCount,
            newCount: posts.length,
            removedCount,
            note: 'Posts 41+ have been permanently deleted (including their images)'
        });
    } catch (error) {
        console.error('Error cleaning up posts:', error);
        res.status(500).json({ error: 'Failed to clean up posts' });
    }
});

module.exports = router;
