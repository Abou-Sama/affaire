const express = require('express');
const router = express.Router();
const authController = require('../controllers/authController');
const { authenticateToken } = require('../middlewares/auth.middleware');
const { authRateLimiter } = require('../config/security');
const {
    validateSignup,
    validateLogin,
    validatePasswordChange,
    validatePasswordReset,
    validateProfileUpdate,
    validateRefreshToken,
    sanitizeInput
} = require('../middlewares/validation.middleware');

/**
 * Authentication Routes
 * @route /api/auth
 */

// Public self-registration is disabled. Users must be created by an admin.
router.post('/signup', authRateLimiter, (req, res) => {
    res.status(403).json({
        success: false,
        error: 'User registration is disabled. Only administrators can create users.'
    });
});
router.post('/login', authRateLimiter, sanitizeInput, validateLogin, authController.login);
router.post('/refresh', authRateLimiter, validateRefreshToken, authController.refreshToken);
router.post('/reset-password', authRateLimiter, sanitizeInput, validatePasswordReset, authController.resetPassword);

// Protected routes (require authentication)
router.use(authenticateToken);

router.get('/profile', authController.getProfile);
router.put('/profile', sanitizeInput, validateProfileUpdate, authController.updateProfile);
router.post('/change-password', sanitizeInput, validatePasswordChange, authController.changePassword);
router.post('/logout', authController.logout);

module.exports = router;
