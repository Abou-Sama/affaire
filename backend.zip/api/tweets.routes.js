const express = require('express');
const router = express.Router();

// Try to use NodeCache if available, otherwise fall back to a no-op cache
let NodeCache;
try {
    NodeCache = require('node-cache');
} catch (e) {
    NodeCache = null;
}

const cache = NodeCache ? new NodeCache({ stdTTL: 300, checkperiod: 60 }) : null;

const NITTER_INSTANCES = [
    'https://nitter.net',
    'https://nitter.1d4.us',
    'https://nitter.kavin.rocks',
    'https://nitter.unixfox.eu',
    'https://nitter.at'
];

function parseRss(xmlText, limit = 15) {
    const items = [];
    const itemRegex = /<item>([\s\S]*?)<\/item>/g;
    let match;
    while ((match = itemRegex.exec(xmlText)) && items.length < limit) {
        const item = match[1];
        const titleMatch = /<title>([\s\S]*?)<\/title>/.exec(item);
        const linkMatch = /<link>([\s\S]*?)<\/link>/.exec(item);
        const dateMatch = /<pubDate>([\s\S]*?)<\/pubDate>/.exec(item);
        const descMatch = /<description>([\s\S]*?)<\/description>/.exec(item);

        const title = titleMatch ? titleMatch[1].trim() : '';
        const link = linkMatch ? linkMatch[1].trim() : '';
        const pubDate = dateMatch ? dateMatch[1].trim() : '';
        const desc = descMatch ? descMatch[1].trim() : '';

        // extract images from description HTML
        const images = [];
        const imgRe = /<img[^>]+src="([^">]+)"/g;
        let im;
        while ((im = imgRe.exec(desc)) !== null) images.push(im[1]);

        items.push({
            id: link.split('/').pop() || Math.random().toString(36).slice(2),
            text: title || desc.replace(/<[^>]+>/g, '').slice(0, 280),
            author: 'MAE_Tchad',
            date: pubDate,
            likes: 0,
            retweets: 0,
            replies: 0,
            images,
            url: link
        });
    }
    return items;
}

async function fetchFromNitter(username, limit = 15) {
    const errors = [];
    for (const instance of NITTER_INSTANCES) {
        try {
            const url = `${instance}/${username}/rss`;
            const controller = new AbortController();
            const timeout = setTimeout(() => controller.abort(), 10000);
            const res = await fetch(url, { signal: controller.signal });
            clearTimeout(timeout);
            if (!res.ok) {
                errors.push(`${instance} HTTP ${res.status}`);
                continue;
            }
            const text = await res.text();
            const parsed = parseRss(text, limit);
            return { tweets: parsed, instance };
        } catch (err) {
            errors.push(`${instance} -> ${err && err.message ? err.message : String(err)}`);
            continue;
        }
    }
    throw new Error('All Nitter instances failed: ' + errors.join(' | '));
}

router.get('/health', (req, res) => {
    res.json({ success: true, message: 'tweets route ok' });
});

router.get('/', async (req, res) => {
    const username = req.query.username || 'MAE_Tchad';
    const limit = parseInt(req.query.limit || '15', 10) || 15;
    const cacheKey = `tweets_${username}_${limit}`;

    try {
        if (cache) {
            const cached = cache.get(cacheKey);
            if (cached) return res.json({ success: true, source: 'cache', data: cached });
        }

        const { tweets, instance } = await fetchFromNitter(username, limit);
        if (cache) cache.set(cacheKey, tweets);
        return res.json({ success: true, source: 'nitter', instance, data: tweets });
    } catch (err) {
        return res.status(502).json({ success: false, error: err.message || 'Failed to fetch tweets' });
    }
});

module.exports = router;
