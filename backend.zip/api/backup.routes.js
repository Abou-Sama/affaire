const express = require('express');
const fs = require('fs').promises;
const path = require('path');
const multer = require('multer');
const AdmZip = require('adm-zip');
const { fileEntry, bufferEntry, archiveSize, writeZip } = require('../utils/zipStream');
const router = express.Router();
const { authenticateToken, requireAdmin } = require('../middlewares/auth.unified');
const { adminRateLimiter } = require('../config/security');

const MAX_UPLOAD_BYTES = 500 * 1024 * 1024;
const MAX_UNCOMPRESSED_BYTES = 1024 * 1024 * 1024; // zip-bomb guard
const MAX_ZIP_ENTRIES = 20000; // zip-bomb guard

const upload = multer({
    defParamCharset: 'utf8',
    storage: multer.memoryStorage(),
    limits: { fileSize: MAX_UPLOAD_BYTES, files: 1 },
    fileFilter: (req, file, cb) => {
        const isZipName = /\.zip$/i.test(file.originalname || '');
        const isZipMime = ['application/zip', 'application/x-zip-compressed', 'application/octet-stream'].includes(file.mimetype);
        if (!isZipName || !isZipMime) {
            return cb(new Error('Seuls les fichiers .zip sont acceptés'));
        }
        cb(null, true);
    }
});

// Run multer manually so file-filter/size rejections come back as our own
// JSON error shape instead of falling through to Express's default HTML handler.
function handleZipUpload(req, res, next) {
    upload.single('backup')(req, res, (err) => {
        if (err) {
            return res.status(400).json({ success: false, error: err.message || 'Fichier de sauvegarde invalide' });
        }
        next();
    });
}

const BACKEND_ROOT = path.join(__dirname, '..');
const UPLOADS_ROOT = path.join(BACKEND_ROOT, 'uploads');

const SOURCES = [
    { key: 'accueil', label: "Contenu de la page d'accueil", file: path.join(__dirname, '../data/homeContents.json') },
    { key: 'syntheseActualite', label: 'Synthèse & Publications', file: path.join(__dirname, '../data/syntheseActualite.json') },
    { key: 'avisRecrutement', label: 'Avis de recrutement', file: path.join(__dirname, '../data/recrutement.json') }
];

async function readJsonSafe(filePath) {
    try {
        const raw = await fs.readFile(filePath, 'utf-8');
        return JSON.parse(raw || '[]');
    } catch (error) {
        console.warn(`[Backup] Could not read ${filePath}: ${error.message}`);
        return [];
    }
}

// Recursively walk a post record (or array of records) and collect every
// "/uploads/..." string it references, regardless of which field holds it
// (images, content, files[].url, ...) — this way nothing gets missed as the
// post schemas evolve.
function collectUploadPaths(value, acc = new Set()) {
    if (typeof value === 'string') {
        if (value.startsWith('/uploads/')) acc.add(value);
    } else if (Array.isArray(value)) {
        value.forEach((item) => collectUploadPaths(item, acc));
    } else if (value && typeof value === 'object') {
        Object.values(value).forEach((item) => collectUploadPaths(item, acc));
    }
    return acc;
}

// Resolve a "/uploads/..." reference to an absolute path, refusing anything
// that would escape the uploads directory (path traversal guard).
function safeUploadAbsolutePath(relUrl) {
    if (typeof relUrl !== 'string' || !relUrl.startsWith('/uploads/')) return null;
    const normalized = path.normalize(relUrl);
    if (normalized.split(path.sep).includes('..')) return null;
    const absPath = path.join(BACKEND_ROOT, normalized);
    if (!absPath.startsWith(UPLOADS_ROOT + path.sep)) return null;
    return absPath;
}

// Export all posts (Accueil, Synthèse, Avis de recrutement) — their text,
// description and date fields plus every image/file they reference — as a
// single downloadable .zip backup. Nothing is written to disk on the server:
// files are streamed one after another straight into the response, so the
// download starts at once, runs at full network speed and shows real progress.
router.get('/export', authenticateToken, requireAdmin, adminRateLimiter, async (req, res) => {
    try {
        const data = {};
        const filePaths = new Set();
        for (const source of SOURCES) {
            const records = await readJsonSafe(source.file);
            data[source.key] = records;
            collectUploadPaths(records, filePaths);
        }

        const entries = [];
        const missingFiles = [];

        for (const relUrl of filePaths) {
            const absPath = safeUploadAbsolutePath(relUrl);
            if (!absPath) continue;
            try {
                const stat = await fs.stat(absPath);
                if (!stat.isFile()) throw new Error('not a file');
                entries.push(fileEntry(`files${relUrl}`, absPath, stat.size, stat.mtime));
            } catch (error) {
                missingFiles.push(relUrl);
                console.warn(`[Backup] Referenced file missing on disk, skipped: ${relUrl}`);
            }
        }

        const backup = {
            meta: {
                exportedAt: new Date().toISOString(),
                exportedBy: req.user?.email || 'unknown',
                sources: SOURCES.map(({ key, label }) => ({ key, label })),
                postCounts: Object.fromEntries(SOURCES.map((s) => [s.key, data[s.key].length])),
                fileCount: entries.length,
                missingFiles
            },
            data
        };

        entries.push(bufferEntry('backup.json', Buffer.from(JSON.stringify(backup, null, 2), 'utf-8')));

        let totalSize;
        try {
            totalSize = archiveSize(entries);
        } catch (sizeError) {
            return res.status(413).json({ success: false, error: `Sauvegarde trop volumineuse: ${sizeError.message}` });
        }

        const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
        const filename = `backup-posts-${timestamp}.zip`;

        res.setHeader('Content-Type', 'application/zip');
        res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
        res.setHeader('Content-Length', totalSize);
        res.setHeader('Cache-Control', 'no-store');
        await writeZip(res, entries);
        res.end();
    } catch (error) {
        console.error('[Backup] Export failed:', error.message);
        // Once streaming has started the status is already sent: cut the connection so the
        // browser reports a failed download instead of saving a truncated archive.
        if (res.headersSent) return res.destroy(error);
        res.status(500).json({ success: false, error: 'Backup export failed' });
    }
});

// Restore posts from a previously exported .zip backup.
// This completely replaces the current Accueil, Synthèse and Avis de recrutement
// posts AND their files with whatever the backup contains — old posts and their
// files are deleted first, nothing is merged.
router.post('/restore', authenticateToken, requireAdmin, adminRateLimiter, handleZipUpload, async (req, res) => {
    try {
        if (!req.file) {
            return res.status(400).json({ success: false, error: 'Aucun fichier de sauvegarde fourni' });
        }

        let zip;
        try {
            zip = new AdmZip(req.file.buffer);
        } catch (error) {
            return res.status(400).json({ success: false, error: 'Fichier de sauvegarde invalide (archive illisible)' });
        }

        const entries = zip.getEntries();
        if (entries.length > MAX_ZIP_ENTRIES) {
            return res.status(400).json({ success: false, error: 'Archive de sauvegarde invalide (trop de fichiers)' });
        }
        const totalUncompressed = entries.reduce((sum, entry) => sum + (entry.header?.size || 0), 0);
        if (totalUncompressed > MAX_UNCOMPRESSED_BYTES) {
            return res.status(400).json({ success: false, error: 'Archive de sauvegarde invalide (taille décompressée excessive)' });
        }

        const manifestEntry = zip.getEntry('backup.json');
        if (!manifestEntry) {
            return res.status(400).json({ success: false, error: 'Fichier de sauvegarde invalide (manifeste introuvable)' });
        }

        let parsed;
        try {
            parsed = JSON.parse(manifestEntry.getData().toString('utf-8'));
        } catch (error) {
            return res.status(400).json({ success: false, error: 'Manifeste de sauvegarde illisible' });
        }

        const payload = parsed && typeof parsed === 'object' ? parsed.data : null;
        if (!payload || typeof payload !== 'object') {
            return res.status(400).json({ success: false, error: 'Format de sauvegarde invalide' });
        }

        const counts = {};
        for (const source of SOURCES) {
            const records = payload[source.key];
            if (!Array.isArray(records)) {
                return res.status(400).json({
                    success: false,
                    error: `Section manquante ou invalide dans la sauvegarde: ${source.label}`
                });
            }
            counts[source.key] = records.length;
        }

        // Delete every file referenced by the CURRENT posts before anything is overwritten.
        const oldFilePaths = new Set();
        for (const source of SOURCES) {
            const currentRecords = await readJsonSafe(source.file);
            collectUploadPaths(currentRecords, oldFilePaths);
        }

        let filesRemoved = 0;
        for (const relUrl of oldFilePaths) {
            const absPath = safeUploadAbsolutePath(relUrl);
            if (!absPath) continue;
            try {
                await fs.unlink(absPath);
                filesRemoved++;
            } catch (error) {
                // Already missing — nothing to remove.
            }
        }

        // Replace the post collections themselves.
        for (const source of SOURCES) {
            await fs.writeFile(source.file, JSON.stringify(payload[source.key], null, 2));
        }

        // Write back every file bundled in the archive.
        let filesRestored = 0;
        for (const entry of zip.getEntries()) {
            if (entry.isDirectory || !entry.entryName.startsWith('files/uploads/')) continue;
            const relUrl = entry.entryName.slice('files'.length); // "files/uploads/x" -> "/uploads/x"
            const absPath = safeUploadAbsolutePath(relUrl);
            if (!absPath) continue;
            await fs.mkdir(path.dirname(absPath), { recursive: true });
            await fs.writeFile(absPath, entry.getData());
            filesRestored++;
        }

        console.log(`[Backup] Restore completed by ${req.user?.email || 'unknown'}:`, counts, `filesRemoved=${filesRemoved} filesRestored=${filesRestored}`);
        res.json({ success: true, counts, filesRemoved, filesRestored });
    } catch (error) {
        console.error('[Backup] Restore failed:', error);
        res.status(500).json({ success: false, error: 'La restauration a échoué' });
    }
});

// Delete every post across all three categories (Accueil, Synthèse, Avis de
// recrutement) along with every file they reference. Unlike /restore, this
// does not replace the collections with anything — they are left empty.
router.delete('/purge-all', authenticateToken, requireAdmin, adminRateLimiter, async (req, res) => {
    try {
        const filePaths = new Set();
        const counts = {};
        for (const source of SOURCES) {
            const records = await readJsonSafe(source.file);
            counts[source.key] = records.length;
            collectUploadPaths(records, filePaths);
        }

        let filesRemoved = 0;
        for (const relUrl of filePaths) {
            const absPath = safeUploadAbsolutePath(relUrl);
            if (!absPath) continue;
            try {
                await fs.unlink(absPath);
                filesRemoved++;
            } catch (error) {
                // Already missing — nothing to remove.
            }
        }

        for (const source of SOURCES) {
            await fs.writeFile(source.file, JSON.stringify([], null, 2));
        }

        console.log(`[Backup] Purge-all completed by ${req.user?.email || 'unknown'}:`, counts, `filesRemoved=${filesRemoved}`);
        res.json({ success: true, counts, filesRemoved });
    } catch (error) {
        console.error('[Backup] Purge-all failed:', error);
        res.status(500).json({ success: false, error: 'La suppression a échoué' });
    }
});

module.exports = router;
