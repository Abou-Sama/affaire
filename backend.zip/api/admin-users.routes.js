const express = require('express');
const router = express.Router();
const fs = require('fs');
const path = require('path');
const { authenticateToken, requireAdmin } = require('../middlewares/auth.unified');
const bcrypt = require('bcrypt');
const { validatePassword } = require('../utils/password');
const nodemailer = require('nodemailer');

// Single shared mailbox: all account/password notifications are sent from and to this address
const MAIL_FROM = process.env.EMAIL_USER || 'admin@diplomatie.td';
const ADMIN_NOTIFY_EMAIL = process.env.ADMIN_EMAIL || 'admin@diplomatie.td';

const EMAIL_PASSWORD = process.env.EMAIL_PASSWORD || process.env.GMAIL_APP_PASSWORD;
const mailTransporter = nodemailer.createTransport({
    host: process.env.SMTP_HOST || 'smtp.hostinger.com',
    port: Number(process.env.SMTP_PORT || 465),
    secure: process.env.SMTP_SECURE ? process.env.SMTP_SECURE === 'true' : true,
    auth: EMAIL_PASSWORD ? {
        user: MAIL_FROM,
        pass: EMAIL_PASSWORD
    } : undefined
});

const escapeHtml = (value) => String(value ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

// Notification only: the password itself is never emailed (the admin who set it already knows it,
// and a copy in the shared mailbox would expose every account if that mailbox were compromised).
const sendCredentialsEmail = async ({ subject, heading, name, email }) => {
    const mailOptions = {
        from: `"MAE (Ministere des affaires etrangers)" <${MAIL_FROM}>`,
        to: ADMIN_NOTIFY_EMAIL,
        subject,
        html: `
            <div style="font-family: Arial, sans-serif; background-color: #f5f5f5; padding: 20px;">
                <div style="background-color: white; border-radius: 8px; padding: 30px; max-width: 600px; margin: 0 auto;">
                    <h2 style="color: #002D72; text-align: center;">${heading}</h2>
                    <div style="background-color: #f8f9fa; padding: 15px; margin: 20px 0; border-radius: 5px;">
                        <p><strong>Nom:</strong> ${escapeHtml(name || 'N/A')}</p>
                        <p><strong>Email / identifiant:</strong> ${escapeHtml(email)}</p>
                        <p><strong>Mot de passe:</strong> défini par l'administrateur (non transmis par email)</p>
                    </div>
                </div>
            </div>
        `
    };

    try {
        await mailTransporter.sendMail(mailOptions);
        console.log(`✅ Credentials email sent to ${ADMIN_NOTIFY_EMAIL} for ${email}`);
    } catch (emailError) {
        console.warn(`⚠️ Failed to send credentials email to ${ADMIN_NOTIFY_EMAIL}: ${emailError.message}`);
    }
};

// Middleware to require main admin (Administrateur MAE)
// Note: Admin role is already validated by requireAdmin middleware above
// This middleware is now a pass-through to allow any authenticated admin to manage users
const requireMainAdmin = (req, res, next) => {
    if (!req.user) {
        return res.status(401).json({
            success: false,
            error: 'Not authenticated'
        });
    }

    // Admin role is already verified by requireAdmin middleware
    // Allow any admin user to manage users
    console.log(`✅ [AUTH] Admin user ${req.user.email} authorized to manage users`);
    next();
};

// Try to import User model, but handle gracefully if DB is not available
let User = null;
let useDatabase = false;

try {
    const models = require('../models-sequelize');
    User = models.User;
    useDatabase = true;
    console.log('✅ Using Sequelize database for user management');
} catch (error) {
    console.warn('⚠️ Database model not available, using JSON fallback:', error.message);
    useDatabase = false;
}

// Data file path for JSON fallback
const dataDir = path.join(__dirname, '../data');
const usersFile = path.join(dataDir, 'users.json');

// Helper functions for JSON fallback
const readUsers = () => {
    try {
        const data = fs.readFileSync(usersFile, 'utf8');
        return JSON.parse(data);
    } catch (error) {
        console.error('Error reading users file:', error);
        return [];
    }
};

const writeUsers = (users) => {
    try {
        require('../utils/atomicJson').writeJsonAtomic(usersFile, users);
        return true;
    } catch (error) {
        console.error('Error writing users file:', error);
        return false;
    }
};

const normalizePermissions = (permissions) => {
    if (!permissions) return {};
    if (Array.isArray(permissions)) {
        return permissions.reduce((acc, permission) => {
            acc[permission] = true;
            return acc;
        }, {});
    }
    if (typeof permissions === 'object') {
        return Object.entries(permissions).reduce((acc, [permission, enabled]) => {
            acc[permission] = enabled === true;
            return acc;
        }, {});
    }
    return {};
};

// Baseline permissions granted per role so accounts can actually use the
// admin-panel features their role gives them UI access to (e.g. the 'editor'
// role sees buttons for recruitment posts, actualites, and missions
// diplomatiques management). Explicit permissions passed at creation/update
// time are merged on top of these, so they can still be overridden per user.
const DEFAULT_PERMISSIONS_BY_ROLE = {
    editor: {
        manage_recrutement: true,
        edit_news_content: true,
        manage_representations: true
    }
};

const withRoleDefaults = (role, permissions) => ({
    ...(DEFAULT_PERMISSIONS_BY_ROLE[role] || {}),
    ...normalizePermissions(permissions)
});

// GET /api/admin/users - Get all users
router.get('/', authenticateToken, requireAdmin, requireMainAdmin, async (req, res) => {
    try {
        console.log('\n📊 [GET /api/admin/users] Fetching all users');

        if (useDatabase && User) {
            try {
                const users = await User.findAll({
                    attributes: { exclude: ['password', 'passwordResetToken', 'passwordResetExpires'] }
                });
                console.log(`✅ Returned ${users.length} users from database`);
                return res.json(users);
            } catch (dbError) {
                console.warn('Database query failed, falling back to JSON:', dbError.message);
                useDatabase = false;
            }
        }

        // JSON fallback
        const users = readUsers();
        const sanitized = users.map(user => {
            const { password, otpCode, otpExpiry, otpAttempts, otpVerified, ...clean } = user;
            return clean;
        });

        console.log(`✅ Returned ${sanitized.length} users from JSON`);
        res.json(sanitized);
    } catch (error) {
        console.error('❌ Error fetching users:', error);
        res.status(500).json({
            success: false,
            error: 'Failed to fetch users',
            details: error.message
        });
    }
});

// GET /api/admin/users/:id - Get single user for editing
router.get('/:id', authenticateToken, requireAdmin, requireMainAdmin, async (req, res) => {
    try {
        console.log(`\n👤 [GET /api/admin/users/:id] Fetching user ${req.params.id}`);
        const { id } = req.params;

        if (useDatabase && User) {
            try {
                const user = await User.findOne({
                    where: { id },
                    attributes: { exclude: ['password', 'passwordResetToken', 'passwordResetExpires'] }
                });

                if (user) {
                    console.log(`✅ Fetched user: ${user.username} from database`);
                    return res.json(user);
                }
            } catch (dbError) {
                console.warn('Database query failed, falling back to JSON:', dbError.message);
                useDatabase = false;
            }
        }

        // JSON fallback
        const users = readUsers();
        const user = users.find(u => u.id === id || u.username === id || u.email === id);

        if (!user) {
            console.log(`❌ User not found: ${id}`);
            return res.status(404).json({
                success: false,
                error: 'User not found'
            });
        }

        const { password, otpCode, otpExpiry, otpAttempts, otpVerified, ...sanitized } = user;
        console.log(`✅ Fetched user: ${user.username} from JSON`);
        res.json(sanitized);
    } catch (error) {
        console.error('❌ Error fetching user:', error);
        res.status(500).json({
            success: false,
            error: 'Failed to fetch user',
            details: error.message
        });
    }
});

// POST /api/admin/users - Create new user
router.post('/', authenticateToken, requireAdmin, requireMainAdmin, async (req, res) => {
    try {
        console.log('\n📝 [POST /api/admin/users] Creating new user');
        const { username, role, password, permissions } = req.body;
        const adminEmail = req.user?.email;
        console.log('👤 Admin creating user - adminEmail:', adminEmail);
        console.log('👤 req.user:', req.user);

        if (!username || !password) {
            return res.status(400).json({
                success: false,
                error: 'Username and password are required'
            });
        }

        const strength = validatePassword(String(password));
        if (!strength.valid) {
            return res.status(400).json({ success: false, error: strength.message });
        }

        // An email typed as the username is used as the login email itself (it used to become
        // "name@domain@internal.ministere.td", so that user could never log in with their email)
        const loginName = String(username).trim().toLowerCase();
        const accountEmail = loginName.includes('@') ? loginName : `${loginName}@internal.ministere.td`;

        if (username.length < 3) {
            return res.status(400).json({
                success: false,
                error: 'Username must be at least 3 characters'
            });
        }

        if (useDatabase && User) {
            // Try to use database
            try {
                // Check if username already exists
                const existingUser = await User.findOne({ where: { username: username.toLowerCase() } });
                if (existingUser) {
                    return res.status(400).json({
                        success: false,
                        error: 'Username already exists'
                    });
                }

                // Create new user in database
                const resolvedRole = role || 'editor';
                const newUser = await User.create({
                    username: username.toLowerCase(),
                    password,
                    name: username,
                    email: accountEmail,
                    role: resolvedRole,
                    permissions: withRoleDefaults(resolvedRole, permissions),
                    status: 'active',
                    adminEmail: adminEmail
                });

                console.log(`✅ User ${username} created in database by ${adminEmail}`);
                await sendCredentialsEmail({
                    subject: 'Nouveau compte créé - Identifiants | Ministère des Affaires Étrangères',
                    heading: 'Nouveau compte créé',
                    name: newUser.name,
                    email: newUser.email,
                    password
                });
                res.status(201).json({
                    success: true,
                    message: 'User created successfully',
                    data: {
                        id: newUser.id,
                        username: newUser.username,
                        email: newUser.email,
                        name: newUser.name,
                        role: newUser.role,
                        status: newUser.status
                    }
                });
            } catch (dbError) {
                console.warn('Database operation failed, falling back to JSON:', dbError.message);
                useDatabase = false;
                // Fall through to JSON creation
            }
        }

        if (!useDatabase) {
            // Use JSON fallback
            const users = readUsers();
            if (users.find(u => u.username === username.toLowerCase())) {
                return res.status(400).json({
                    success: false,
                    error: 'Username already exists'
                });
            }

            const resolvedRole = role || 'editor';
            const newUser = {
                id: Date.now().toString(),
                username: username.toLowerCase(),
                password: await bcrypt.hash(password, 10),
                name: username,
                email: accountEmail,
                role: resolvedRole,
                permissions: withRoleDefaults(resolvedRole, permissions),
                status: 'active',
                adminEmail: adminEmail,
                createdAt: new Date().toISOString()
            };

            console.log('═══════════════════════════════════════════════════');
            console.log('📝 USER OBJECT BEFORE SAVING:');
            console.log('   adminEmail:', adminEmail);
            console.log('   username:', newUser.username);
            console.log('   Full object:', JSON.stringify(newUser, null, 2));
            console.log('═══════════════════════════════════════════════════');

            users.push(newUser);
            if (!writeUsers(users)) {
                return res.status(500).json({
                    success: false,
                    error: 'Failed to create user'
                });
            }

            console.log(`✅ User ${username} created in JSON by ${adminEmail}`);
            await sendCredentialsEmail({
                subject: 'Nouveau compte créé - Identifiants | Ministère des Affaires Étrangères',
                heading: 'Nouveau compte créé',
                name: newUser.name,
                email: newUser.email,
                password
            });
            res.status(201).json({
                success: true,
                message: 'User created successfully',
                data: {
                    id: newUser.id,
                    username: newUser.username,
                    email: newUser.email,
                    name: newUser.name,
                    role: newUser.role,
                    status: newUser.status
                }
            });
        }
    } catch (error) {
        console.error('❌ Error creating user:', error);
        res.status(500).json({
            success: false,
            error: 'Failed to create user',
            details: error.message
        });
    }
});

// PUT /api/admin/users/:id - Update user
router.put('/:id', authenticateToken, requireAdmin, requireMainAdmin, async (req, res) => {
    try {
        console.log(`\n📝 [PUT /api/admin/users/:id] Updating user ${req.params.id}`);
        const { id } = req.params;
        const updates = req.body;

        if (updates.password) {
            const strength = validatePassword(String(updates.password));
            if (!strength.valid) {
                return res.status(400).json({ success: false, error: strength.message });
            }
        }

        if (useDatabase && User) {
            try {
                const user = await User.findByPk(id);

                if (!user) {
                    // Fall through to JSON
                } else {
                    const allowedUpdates = ['name', 'email', 'role', 'status', 'password', 'permissions'];
                    const updateData = {};

                    allowedUpdates.forEach(field => {
                        if (updates[field] !== undefined) {
                            updateData[field] = field === 'permissions'
                                ? normalizePermissions(updates[field])
                                : updates[field];
                        }
                    });

                    await user.update(updateData);

                    console.log(`✅ User ${id} updated in database`);
                    if (updates.password) {
                        await sendCredentialsEmail({
                            subject: 'Mot de passe modifié - Identifiants | Ministère des Affaires Étrangères',
                            heading: 'Mot de passe modifié',
                            name: user.name,
                            email: user.email,
                            password: updates.password
                        });
                    }
                    return res.json({
                        success: true,
                        message: 'User updated successfully',
                        data: {
                            id: user.id,
                            username: user.username,
                            email: user.email,
                            name: user.name,
                            role: user.role,
                            permissions: user.permissions,
                            status: user.status
                        }
                    });
                }
            } catch (dbError) {
                console.warn('Database operation failed, falling back to JSON:', dbError.message);
                useDatabase = false;
            }
        }

        // JSON fallback
        const users = readUsers();
        const userIndex = users.findIndex(u => u.id === id || u.username === id || u.email === id);

        if (userIndex === -1) {
            return res.status(404).json({
                success: false,
                error: 'User not found'
            });
        }

        // Only editable fields: never let a request set ids, OTP state or timestamps
        const nextUpdates = {};
        ['name', 'email', 'role', 'status', 'password', 'permissions'].forEach(field => {
            if (updates[field] !== undefined) nextUpdates[field] = updates[field];
        });
        if (nextUpdates.password) {
            nextUpdates.password = await bcrypt.hash(nextUpdates.password, 10);
        }
        if (nextUpdates.permissions !== undefined) {
            nextUpdates.permissions = normalizePermissions(nextUpdates.permissions);
        }

        users[userIndex] = { ...users[userIndex], ...nextUpdates, updatedAt: new Date().toISOString() };

        if (!writeUsers(users)) {
            return res.status(500).json({
                success: false,
                error: 'Failed to update user'
            });
        }

        const { password, otpCode, otpExpiry, otpAttempts, otpVerified, ...userResponse } = users[userIndex];
        console.log(`✅ User ${id} updated in JSON`);
        if (updates.password) {
            await sendCredentialsEmail({
                subject: 'Mot de passe modifié - Identifiants | Ministère des Affaires Étrangères',
                heading: 'Mot de passe modifié',
                name: userResponse.name,
                email: userResponse.email,
                password: updates.password
            });
        }
        res.json({
            success: true,
            message: 'User updated successfully',
            data: userResponse
        });
    } catch (error) {
        console.error('❌ Error updating user:', error);
        res.status(500).json({
            success: false,
            error: 'Failed to update user',
            details: error.message
        });
    }
});

// DELETE /api/admin/users/:id - Delete user
router.delete('/:id', authenticateToken, requireAdmin, requireMainAdmin, async (req, res) => {
    try {
        console.log(`\n🗑️ [DELETE /api/admin/users/:id] Deleting user ${req.params.id}`);
        const { id } = req.params;

        if (useDatabase && User) {
            try {
                const user = await User.findByPk(id);

                if (user) {
                    // Prevent deletion of main admin account only
                    if (user.email === 'admin@diplomatie.td') {
                        console.warn(`🔒 Attempt to delete protected main admin user: ${user.email}`);
                        return res.status(403).json({
                            success: false,
                            error: 'Cannot delete the main Administrator user. This account is protected.'
                        });
                    }

                    await user.destroy();

                    console.log(`✅ User ${id} deleted from database`);
                    return res.json({
                        success: true,
                        message: 'User deleted successfully'
                    });
                }
            } catch (dbError) {
                console.warn('Database operation failed, falling back to JSON:', dbError.message);
                useDatabase = false;
            }
        }

        // JSON fallback
        const users = readUsers();
        const userIndex = users.findIndex(u => u.id === id || u.username === id || u.email === id);

        if (userIndex === -1) {
            return res.status(404).json({
                success: false,
                error: 'User not found'
            });
        }

        // Prevent deletion of main admin account only
        const userToDelete = users[userIndex];
        if (userToDelete.email === 'admin@diplomatie.td') {
            console.warn(`🔒 Attempt to delete protected main admin user: ${userToDelete.email}`);
            return res.status(403).json({
                success: false,
                error: 'Cannot delete the main Administrator user. This account is protected.'
            });
        }

        users.splice(userIndex, 1);

        if (!writeUsers(users)) {
            return res.status(500).json({
                success: false,
                error: 'Failed to delete user'
            });
        }

        console.log(`✅ User ${id} deleted from JSON`);
        res.json({
            success: true,
            message: 'User deleted successfully'
        });
    } catch (error) {
        console.error('❌ Error deleting user:', error);
        res.status(500).json({
            success: false,
            error: 'Failed to delete user',
            details: error.message
        });
    }
});

module.exports = router;
