const express = require('express');
const router = express.Router();
const fetch = require('node-fetch');
const fs = require('fs');
const path = require('path');
// Session-aware auth (same as the rest of the admin area)
const { authenticateToken, requireAdmin } = require('../middlewares/auth.unified');

const MAX_VIDEOS = 12;
const VIDEOS_FILE = path.join(__dirname, '../data/videos.json');

/**
 * Load videos from the local JSON storage file.
 */
function loadVideosFromFile() {
    try {
        if (fs.existsSync(VIDEOS_FILE)) {
            const data = fs.readFileSync(VIDEOS_FILE, 'utf-8');
            return JSON.parse(data) || [];
        }
    } catch (error) {
        console.error('Error loading videos from file:', error);
    }
    return [];
}

/**
 * Save videos to the local JSON storage file.
 */
function saveVideosToFile(videos) {
    try {
        const dir = path.dirname(VIDEOS_FILE);
        if (!fs.existsSync(dir)) {
            fs.mkdirSync(dir, { recursive: true });
        }
        fs.writeFileSync(VIDEOS_FILE, JSON.stringify(videos, null, 2), 'utf-8');
        console.log('✅ Videos saved to file storage');
    } catch (error) {
        console.error('Error saving videos to file:', error);
    }
}

/**
 * Extract YouTube video ID from various URL formats.
 */
function extractYoutubeId(url) {
    const patterns = [
        /(?:youtube\.com\/watch\?v=|youtu\.be\/)([a-zA-Z0-9_-]{11})/,
        /^([a-zA-Z0-9_-]{11})$/ // Direct video ID
    ];

    for (const pattern of patterns) {
        const match = url.match(pattern);
        if (match) {
            return match[1];
        }
    }
    return null;
}

/**
 * Fetch video title from YouTube oEmbed API.
 */
async function fetchVideoTitle(youtubeId) {
    try {
        const url = `https://www.youtube.com/oembed?url=http://youtube.com/watch?v=${youtubeId}&format=json`;
        const response = await fetch(url);

        if (!response.ok) {
            console.error(`YouTube oEmbed error: ${response.status}`);
            return `Video ${youtubeId.substring(0, 5)}...`;
        }

        const data = await response.json();
        return data.title || `Video ${youtubeId}`;
    } catch (error) {
        console.error('Error fetching video title:', error.message);
        return `Video ${youtubeId.substring(0, 5)}...`;
    }
}

/**
 * GET /api/videos
 * Get all videos sorted by position.
 */
router.get('/', async (req, res) => {
    try {
        const videos = loadVideosFromFile()
            .slice()
            .sort((a, b) => (a.position || 0) - (b.position || 0));

        res.json({
            success: true,
            count: videos.length,
            maxVideos: MAX_VIDEOS,
            isFull: videos.length >= MAX_VIDEOS,
            data: videos
        });
    } catch (error) {
        console.error('Error fetching videos:', error);
        const videos = loadVideosFromFile();
        res.json({
            success: true,
            count: videos.length,
            maxVideos: MAX_VIDEOS,
            isFull: videos.length >= MAX_VIDEOS,
            data: videos
        });
    }
});

/**
 * POST /api/videos
 * Add a new video (admin only).
 */
router.post('/', authenticateToken, requireAdmin, async (req, res) => {
    try {
        const { youtubeLink } = req.body;

        if (!youtubeLink || typeof youtubeLink !== 'string') {
            return res.status(400).json({
                success: false,
                error: 'YouTube link is required'
            });
        }

        const youtubeId = extractYoutubeId(youtubeLink.trim());
        if (!youtubeId) {
            return res.status(400).json({
                success: false,
                error: 'Invalid YouTube URL or video ID'
            });
        }

        const title = await fetchVideoTitle(youtubeId);
        let videos = loadVideosFromFile();

        if (videos.some(v => v.youtubeId === youtubeId)) {
            return res.status(400).json({
                success: false,
                error: 'This video is already in the container'
            });
        }

        const newVideo = {
            _id: `local_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
            youtubeId,
            title,
            position: 0,
            addedAt: new Date().toISOString()
        };

        videos.forEach(v => v.position = (v.position || 0) + 1);
        videos.unshift(newVideo);

        if (videos.length > MAX_VIDEOS) {
            videos = videos.slice(0, MAX_VIDEOS);
        }

        videos.forEach((v, i) => v.position = i);
        saveVideosToFile(videos);

        return res.json({
            success: true,
            message: 'Video added successfully',
            video: newVideo,
            count: videos.length
        });
    } catch (error) {
        console.error('Error adding video:', error);
        res.status(500).json({
            success: false,
            error: 'Failed to add video',
            message: error.message
        });
    }
});

/**
 * DELETE /api/videos/:id
 * Delete a video and renumber positions (admin only).
 */
router.delete('/:id', authenticateToken, requireAdmin, async (req, res) => {
    try {
        const { id } = req.params;
        let videos = loadVideosFromFile();
        const index = videos.findIndex(v => v._id === id);

        if (index === -1) {
            return res.status(404).json({
                success: false,
                error: 'Video not found'
            });
        }

        const removed = videos.splice(index, 1)[0];
        videos.forEach((v, i) => v.position = i);
        saveVideosToFile(videos);

        return res.json({
            success: true,
            message: 'Video deleted successfully',
            removed,
            count: videos.length
        });
    } catch (error) {
        console.error('Error deleting video:', error);
        res.status(500).json({
            success: false,
            error: 'Failed to delete video',
            message: error.message
        });
    }
});

/**
 * PUT /api/videos/order
 * Reorder videos based on the provided array of IDs (admin only).
 */
router.put('/order', authenticateToken, requireAdmin, async (req, res) => {
    try {
        const { orderedIds } = req.body;

        if (!Array.isArray(orderedIds)) {
            return res.status(400).json({
                success: false,
                error: 'orderedIds must be an array of video IDs'
            });
        }

        if (orderedIds.length > MAX_VIDEOS) {
            return res.status(400).json({
                success: false,
                error: `Maximum ${MAX_VIDEOS} videos allowed`
            });
        }

        let videos = loadVideosFromFile();
        const reordered = orderedIds
            .map(id => videos.find(v => v._id === id))
            .filter(v => v !== undefined);

        reordered.forEach((v, i) => v.position = i);
        saveVideosToFile(reordered);

        return res.json({
            success: true,
            message: 'Videos reordered successfully',
            data: reordered
        });
    } catch (error) {
        console.error('Error reordering videos:', error);
        res.status(500).json({
            success: false,
            error: 'Failed to reorder videos',
            message: error.message
        });
    }
});

module.exports = router;
