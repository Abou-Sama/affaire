/**
 * Translation API Route - STABLE PRODUCTION VERSION
 * Handles server-side translation with:
 * - Unlimited text support via intelligent chunking
 * - Caching and retries
 * - Rate limit handling
 * - Sequential processing to avoid overwhelming API
 */

const express = require('express');
const router = express.Router();

// Simple in-memory cache for translations
const translationCache = new Map();
const CACHE_DURATION = 24 * 60 * 60 * 1000; // 24 hours

// MyMemory API limits (conservative)
const MAX_CHUNK_SIZE = 300; // characters per request
const DELAY_BETWEEN_REQUESTS = 1500; // milliseconds

/**
 * Split text intelligently for translation
 * Preserves sentence boundaries and word integrity
 */
function splitTextForTranslation(text, maxSize = MAX_CHUNK_SIZE) {
    if (text.length <= maxSize) {
        return [text];
    }

    const chunks = [];
    
    // First try: split by paragraphs (empty lines)
    const paragraphs = text.split('\n\n').filter(p => p.trim());
    let currentChunk = '';

    for (const para of paragraphs) {
        // If adding this paragraph would exceed limit
        if ((currentChunk + '\n\n' + para).length > maxSize) {
            // Save current chunk if it has content
            if (currentChunk) {
                chunks.push(currentChunk.trim());
            }

            // If paragraph itself is too long, split it
            if (para.length > maxSize) {
                // Split paragraph by sentences
                const sentences = para.match(/[^.!?]+[.!?]+|[^.!?]+$/g) || [para];
                let sentenceChunk = '';

                for (const sentence of sentences) {
                    if ((sentenceChunk + ' ' + sentence).length > maxSize) {
                        if (sentenceChunk) chunks.push(sentenceChunk.trim());
                        sentenceChunk = sentence;
                    } else {
                        sentenceChunk += (sentenceChunk ? ' ' : '') + sentence;
                    }
                }
                if (sentenceChunk) chunks.push(sentenceChunk.trim());
            } else {
                currentChunk = para;
            }
        } else {
            currentChunk += (currentChunk ? '\n\n' : '') + para;
        }
    }

    if (currentChunk) {
        chunks.push(currentChunk.trim());
    }

    return chunks.filter(c => c.length > 0);
}

/**
 * Translate text using MyMemory API with retry logic and rate limiting
 */
async function translateChunk(text, sourceLang, targetLang, retries = 3) {
    const cacheKey = `${text}|${sourceLang}|${targetLang}`;

    // Check cache first
    const cached = translationCache.get(cacheKey);
    if (cached && Date.now() - cached.timestamp < CACHE_DURATION) {
        console.log(`[Translation] ✅ Cache hit`);
        return cached.translation;
    }

    for (let attempt = 0; attempt < retries; attempt++) {
        try {
            // Add delay before request to respect rate limits
            if (attempt === 0) {
                await new Promise(resolve => setTimeout(resolve, DELAY_BETWEEN_REQUESTS));
            }

            const encodedText = encodeURIComponent(text);
            const url = `https://api.mymemory.translated.net/get?q=${encodedText}&langpair=${sourceLang}|${targetLang}`;

            console.log(`[Translation] 📡 Attempt ${attempt + 1}/${retries} for ${targetLang} (${text.substring(0, 30)}...)`);

            const response = await fetch(url, {
                method: 'GET',
                headers: { 'Accept': 'application/json' }
            });

            // Rate limited - exponential backoff retry
            if (response.status === 429) {
                const waitMs = Math.pow(2, attempt + 1) * 1000;
                if (attempt < retries - 1) {
                    console.log(`[Translation] ⏳ Rate limited (429), waiting ${waitMs}ms...`);
                    await new Promise(resolve => setTimeout(resolve, waitMs));
                    continue;
                }
            }

            if (!response.ok) {
                console.warn(`[Translation] ⚠️ HTTP ${response.status}`);
                continue;
            }

            const data = await response.json();

            if (data.responseStatus === 200 && data.responseData?.translatedText) {
                const translation = data.responseData.translatedText;

                // Cache the result
                translationCache.set(cacheKey, {
                    translation,
                    timestamp: Date.now()
                });

                console.log(`[Translation] ✅ Success for ${targetLang}`);
                return translation;
            }

            console.warn(`[Translation] ⚠️ Invalid response for ${targetLang}`);

        } catch (error) {
            console.warn(`[Translation] ❌ Error on attempt ${attempt + 1}:`, error.message);

            if (attempt < retries - 1) {
                const waitMs = Math.pow(2, attempt + 1) * 500;
                await new Promise(resolve => setTimeout(resolve, waitMs));
                continue;
            }
        }
    }

    console.log(`[Translation] ⚠️ All retries failed, returning original`);
    return text;
}

/**
 * Translate text with unlimited size by chunking
 */
async function translateUnlimited(text, sourceLang, targetLang) {
    if (!text || !text.trim()) {
        return '';
    }

    const trimmed = text.trim();
    
    // Check full text cache first
    const fullCacheKey = `${trimmed}|${sourceLang}|${targetLang}`;
    const cached = translationCache.get(fullCacheKey);
    if (cached && Date.now() - cached.timestamp < CACHE_DURATION) {
        console.log(`[Translation] ✅ Full text cache hit`);
        return cached.translation;
    }

    // Split text into chunks
    const chunks = splitTextForTranslation(trimmed, MAX_CHUNK_SIZE);
    console.log(`[Translation] 📏 Split into ${chunks.length} chunk(s)`);

    if (chunks.length === 1) {
        // Single chunk - translate directly
        return await translateChunk(chunks[0], sourceLang, targetLang);
    }

    // Multiple chunks - translate sequentially
    const translatedChunks = [];
    for (let i = 0; i < chunks.length; i++) {
        console.log(`[Translation] 📝 Translating chunk ${i + 1}/${chunks.length}...`);
        const translated = await translateChunk(chunks[i], sourceLang, targetLang);
        translatedChunks.push(translated);
    }

    const result = translatedChunks.join('\n\n').trim();

    // Cache the full result
    translationCache.set(fullCacheKey, {
        translation: result,
        timestamp: Date.now()
    });

    return result;
}

/**
 * POST /api/translate
 * Translate text (unlimited size)
 * 
 * Request:
 * {
 *   "text": "Long text to translate",
 *   "languages": ["en", "ar"],
 *   "sourceLanguage": "fr"
 * }
 * 
 * Response:
 * {
 *   "en": "Translated text",
 *   "ar": "النص المترجم"
 * }
 */
router.post('/', async (req, res) => {
    try {
        const { text, languages, sourceLanguage = 'fr' } = req.body;

        if (!text || !text.trim()) {
            return res.status(400).json({ error: 'Text is required' });
        }

        if (!languages || !Array.isArray(languages) || languages.length === 0) {
            return res.status(400).json({ error: 'Languages array is required' });
        }

        console.log(`[Translation API] 🌍 Translating ${text.length} chars to: ${languages.join(', ')}`);

        const results = {};

        // Translate sequentially to avoid rate limiting
        for (const lang of languages) {
            console.log(`[Translation API] 🔄 Starting ${lang}...`);
            results[lang] = await translateUnlimited(text, sourceLanguage, lang);
            console.log(`[Translation API] ✅ Completed ${lang}`);
        }

        return res.json(results);

    } catch (error) {
        console.error('[Translation API] Error:', error);
        return res.status(500).json({ error: error.message });
    }
});

/**
 * POST /api/translate/batch
 * Translate multiple fields (with unlimited text size)
 * 
 * Request:
 * {
 *   "fields": {
 *     "title": "Title",
 *     "description": "Long description..."
 *   },
 *   "languages": ["en", "ar"],
 *   "sourceLanguage": "fr"
 * }
 */
router.post('/batch', async (req, res) => {
    try {
        const { fields, languages, sourceLanguage = 'fr' } = req.body;

        if (!fields || typeof fields !== 'object') {
            return res.status(400).json({ error: 'Fields object is required' });
        }

        if (!languages || !Array.isArray(languages) || languages.length === 0) {
            return res.status(400).json({ error: 'Languages array is required' });
        }

        console.log(`[Translation Batch] 🌍 Translating fields: ${Object.keys(fields).join(', ')} to ${languages.join(', ')}`);

        const results = {};

        // For each language
        for (const lang of languages) {
            console.log(`[Translation Batch] 🔄 Processing ${lang}...`);
            const translatedFields = {};

            // For each field
            for (const [key, value] of Object.entries(fields)) {
                if (typeof value === 'string' && value.trim()) {
                    console.log(`[Translation Batch] 📝 Translating ${key} (${value.length} chars)...`);
                    translatedFields[key] = await translateUnlimited(value, sourceLanguage, lang);
                } else {
                    translatedFields[key] = value;
                }
            }

            results[lang] = translatedFields;
            console.log(`[Translation Batch] ✅ Completed ${lang}`);
        }

        return res.json(results);

    } catch (error) {
        console.error('[Translation Batch] Error:', error);
        return res.status(500).json({ error: error.message });
    }
});

/**
 * GET /api/translate/cache-stats
 */
router.get('/cache-stats', (req, res) => {
    return res.json({
        cacheSize: translationCache.size,
        cacheEnabled: true,
        duration: '24 hours',
        timestamp: new Date().toISOString()
    });
});

/**
 * POST /api/translate/clear-cache
 */
router.post('/clear-cache', (req, res) => {
    translationCache.clear();
    return res.json({ message: 'Cache cleared', size: 0 });
});

module.exports = router;
