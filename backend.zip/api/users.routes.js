/**
 * User Management Routes
 * Routes for creating, managing, and resetting passwords for users
 */

const express = require('express');
const router = express.Router();
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { hashPassword, comparePassword, validatePassword } = require('../utils/password');
// Session-aware auth: a logged-out, suspended or deleted admin can no longer manage users
const { authenticateToken, requireAdmin } = require('../middlewares/auth.unified');

// Data file path
const dataDir = path.join(__dirname, '../data');
const usersFile = path.join(dataDir, 'users.json');

// Helper functions
const readUsers = () => {
    try {
        const data = fs.readFileSync(usersFile, 'utf8');
        return JSON.parse(data);
    } catch (error) {
        console.error('Error reading users file:', error);
        return [];
    }
};

const writeUsers = (users) => {
    try {
        require('../utils/atomicJson').writeJsonAtomic(usersFile, users);
        return true;
    } catch (error) {
        console.error('Error writing users file:', error);
        return false;
    }
};

// GET /api/users - List all users (admin only)
router.get('/', authenticateToken, requireAdmin, (req, res) => {
    try {
        const users = readUsers();
        // Remove sensitive data
        const sanitizedUsers = users.map(user => ({
            id: user.id,
            email: user.email,
            name: user.name,
            role: user.role,
            permissions: user.permissions,
            status: user.status,
            createdAt: user.createdAt
        }));
        res.json({
            success: true,
            data: sanitizedUsers
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            error: error.message
        });
    }
});

// GET /api/users/:id - Get specific user (admin only)
router.get('/:id', authenticateToken, requireAdmin, (req, res) => {
    try {
        const users = readUsers();
        const user = users.find(u => u.id === req.params.id || u.email === req.params.id);

        if (!user) {
            return res.status(404).json({
                success: false,
                error: 'User not found'
            });
        }

        // Remove password
        const { password, otpCode, ...sanitized } = user;
        res.json({
            success: true,
            data: sanitized
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            error: error.message
        });
    }
});

const normalizePermissions = (permissions) => {
    if (!permissions) return {};
    if (Array.isArray(permissions)) {
        return permissions.reduce((acc, permission) => {
            acc[permission] = true;
            return acc;
        }, {});
    }
    if (typeof permissions === 'object') {
        return Object.entries(permissions).reduce((acc, [permission, enabled]) => {
            acc[permission] = enabled === true;
            return acc;
        }, {});
    }
    return {};
};

// POST /api/users/create - Create new user (admin only)
router.post('/create', authenticateToken, requireAdmin, async (req, res) => {
    try {
        const { name, role, permissions, password } = req.body;
        const email = String(req.body.email || '').trim().toLowerCase();

        // Validation
        if (!email || !name || !role) {
            return res.status(400).json({
                success: false,
                error: 'Email, name, and role are required'
            });
        }

        if (!['admin', 'editor', 'content-creator', 'contact-receiver'].includes(role)) {
            return res.status(400).json({
                success: false,
                error: 'Invalid role. Must be: admin, editor, content-creator, or contact-receiver'
            });
        }

        const users = readUsers();

        // Check if user already exists
        if (users.find(u => String(u.email || '').toLowerCase() === email)) {
            return res.status(409).json({
                success: false,
                error: 'User with this email already exists'
            });
        }

        if (password) {
            const strength = validatePassword(String(password));
            if (!strength.valid) {
                return res.status(400).json({ success: false, error: strength.message });
            }
        }

        // Generate a strong temporary password if none was provided
        const finalPassword = password || `Tmp-${crypto.randomBytes(9).toString('base64url')}7a!`;
        const hashedPassword = await hashPassword(finalPassword);

        // Create new user
        const newUser = {
            id: `user-${Date.now()}`,
            email,
            name,
            role,
            permissions: normalizePermissions(permissions || getDefaultPermissions(role)),
            password: hashedPassword,
            status: 'active',
            username: email.split('@')[0], // Add username from email for login compatibility
            createdAt: new Date().toISOString(),
            otpCode: null,
            otpExpiry: null,
            otpAttempts: 0,
            otpVerified: false,
            passwordChangedAt: new Date().toISOString()
        };

        users.push(newUser);
        writeUsers(users);

        res.status(201).json({
            success: true,
            message: 'User created successfully',
            data: {
                id: newUser.id,
                email: newUser.email,
                name: newUser.name,
                role: newUser.role,
                permissions: newUser.permissions,
                temporaryPassword: finalPassword
            }
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            error: error.message
        });
    }
});

// PUT /api/users/:id - Update user (admin only)
router.put('/:id', authenticateToken, requireAdmin, (req, res) => {
    try {
        const { name, role, permissions, status } = req.body;
        const users = readUsers();
        const userIndex = users.findIndex(u => u.id === req.params.id || u.email === req.params.id);

        if (userIndex === -1) {
            return res.status(404).json({
                success: false,
                error: 'User not found'
            });
        }

        const user = users[userIndex];

        // Update allowed fields
        if (name) user.name = name;
        if (role && ['admin', 'editor', 'content-creator', 'contact-receiver'].includes(role)) {
            user.role = role;
        }
        if (permissions) {
            user.permissions = normalizePermissions(permissions);
        }
        if (status && ['active', 'suspended'].includes(status)) {
            user.status = status;
        }

        writeUsers(users);

        res.json({
            success: true,
            message: 'User updated successfully',
            data: {
                id: user.id,
                email: user.email,
                name: user.name,
                role: user.role,
                permissions: user.permissions,
                status: user.status
            }
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            error: error.message
        });
    }
});

// DELETE /api/users/:id - Delete user (admin only)
router.delete('/:id', authenticateToken, requireAdmin, (req, res) => {
    try {
        const users = readUsers();
        const userIndex = users.findIndex(u => u.id === req.params.id || u.email === req.params.id);

        if (userIndex === -1) {
            return res.status(404).json({
                success: false,
                error: 'User not found'
            });
        }

        // Prevent deletion of self
        if (users[userIndex].email === req.user.email) {
            return res.status(400).json({
                success: false,
                error: 'Cannot delete your own account'
            });
        }

        const deletedUser = users.splice(userIndex, 1)[0];
        writeUsers(users);

        res.json({
            success: true,
            message: 'User deleted successfully',
            data: deletedUser.email
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            error: error.message
        });
    }
});

// PUT /api/users/:id/permissions - Update user permissions (admin only)
router.put('/:id/permissions', authenticateToken, requireAdmin, (req, res) => {
    try {
        const { permissions } = req.body;

        if (!Array.isArray(permissions) && (!permissions || typeof permissions !== 'object')) {
            return res.status(400).json({
                success: false,
                error: 'Permissions must be an array or object'
            });
        }

        const users = readUsers();
        const user = users.find(u => u.id === req.params.id || u.email === req.params.id);

        if (!user) {
            return res.status(404).json({
                success: false,
                error: 'User not found'
            });
        }

        user.permissions = normalizePermissions(permissions);
        writeUsers(users);

        res.json({
            success: true,
            message: 'Permissions updated successfully',
            data: {
                email: user.email,
                permissions: user.permissions
            }
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            error: error.message
        });
    }
});

// Helper function: Get default permissions by role
function getDefaultPermissions(role) {
    const permissionsByRole = {
        admin: [
            'edit_all_text',
            'edit_page_titles',
            'edit_mot_de_ministre',
            'edit_home_content',
            'manage_representations',
            'manage_resource_documents',
            'manage_recrutement',
            'replace_official_images',
            'edit_news_content',
            'edit_recruitment_notices',
            'create_users',
            'manage_permissions',
            'view_users',
            'delete_users',
            'initiate_password_reset',
            'view_contact_emails',
            'manage_content',
            'access_admin_dashboard'
        ],
        'content-creator': [
            'edit_home_content',
            'manage_recrutement',
            'create_news_posts',
            'edit_own_news_posts',
            'delete_own_news_posts',
            'arrange_news_posts',
            'create_recruitment_notices',
            'edit_own_recruitment_notices',
            'delete_own_recruitment_notices',
            'arrange_recruitment_notices'
        ],
        'contact-receiver': [
            'receive_contact_emails'
        ]
    };

    return permissionsByRole[role] || [];
}

module.exports = router;
