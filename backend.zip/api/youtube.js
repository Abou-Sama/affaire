const express = require('express');
const router = express.Router();
const { XMLParser } = require('fast-xml-parser');

/**
 * YouTube Videos Route
 * Fetches YouTube channel videos via RSS feed
 * @route GET /api/youtube
 * @query {string} channel - YouTube channel name (default: TchadDiplomatie)
 * @returns {object} { videos: Array, channelName: string }
 */
router.get('/', async (req, res) => {
    try {
        const channel = req.query.channel || 'TchadDiplomatie';
        console.log(`[YouTube API] Fetching videos for channel: ${channel}`);

        // Step 1: Get channel page to find channel ID
        const channelPageUrl = `https://www.youtube.com/@${channel}`;
        console.log(`[YouTube API] Step 1: Fetching channel page...`);

        const channelPageResp = await fetch(channelPageUrl, {
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
            },
            timeout: 10000
        });

        if (!channelPageResp.ok) {
            console.log(`[YouTube API] ❌ Channel fetch failed with status ${channelPageResp.status}`);
            return res.status(404).json({
                error: `Could not find channel: ${channel}`,
                videos: [],
                channelName: channel
            });
        }

        const channelHtml = await channelPageResp.text();
        const channelIdMatch = channelHtml.match(/\"externalId\":\"(UC[^\"]+)\"/);
        if (!channelIdMatch || !channelIdMatch[1]) {
            console.log(`[YouTube API] ❌ Could not extract channel ID from HTML`);
            throw new Error('Could not extract channel ID');
        }
        const channelId = channelIdMatch[1];
        console.log(`[YouTube API] ✅ Found channel ID: ${channelId}`);

        // Step 2: Fetch RSS feed
        const rssUrl = `https://www.youtube.com/feeds/videos.xml?channel_id=${channelId}`;
        console.log(`[YouTube API] Step 2: Fetching RSS feed...`);

        const rssResp = await fetch(rssUrl, {
            headers: {
                'User-Agent': 'Mozilla/5.0'
            },
            timeout: 10000
        });

        if (!rssResp.ok) {
            console.log(`[YouTube API] ❌ RSS fetch failed with status ${rssResp.status}`);
            throw new Error(`Failed to fetch YouTube RSS feed (status ${rssResp.status})`);
        }
        const rssText = await rssResp.text();
        console.log(`[YouTube API] ✅ RSS feed fetched (${rssText.length} chars)`);

        // Step 3: Parse XML and map to JSON
        const parser = new XMLParser({ ignoreAttributes: false, attributeNamePrefix: '@_' });
        const xmlData = parser.parse(rssText);
        const feed = xmlData?.feed;
        if (!feed) {
            console.log(`[YouTube API] ❌ Invalid RSS feed format`);
            throw new Error('Invalid RSS feed format');
        }

        const entries = Array.isArray(feed.entry) ? feed.entry : (feed.entry ? [feed.entry] : []);
        console.log(`[YouTube API] ✅ Found ${entries.length} entries in RSS feed`);

        const videos = entries.slice(0, 12).map((entry) => {
            const videoId = (entry.id || '').toString().split('yt:video:')[1] || '';

            let videoLink = `https://www.youtube.com/watch?v=${videoId}`;
            if (entry.link) {
                if (Array.isArray(entry.link)) {
                    const alternate = entry.link.find((l) => l['@_rel'] === 'alternate');
                    if (alternate && alternate['@_href']) videoLink = alternate['@_href'];
                    else if (entry.link[0] && entry.link[0]['@_href']) videoLink = entry.link[0]['@_href'];
                } else if (typeof entry.link === 'object' && entry.link['@_href']) {
                    videoLink = entry.link['@_href'];
                }
            }

            const thumbnail = entry['media:group']?.['media:thumbnail']?.['@_url'] ||
                `https://i.ytimg.com/vi/${videoId}/sddefault.jpg`;

            return {
                id: videoId,
                title: entry['media:group']?.['media:title'] || entry.title || 'Untitled',
                description: entry['media:group']?.['media:description'] || '',
                link: videoLink,
                thumbnail,
                publishedAt: entry.published,
                channelName: entry.author?.name || feed.title || channel,
            };
        });

        console.log(`[YouTube API] ✅ Returning ${videos.length} videos`);

        // Set cache headers for CDN caching (5 minutes)
        res.set('Cache-Control', 'public, max-age=300');
        res.status(200).json({
            videos,
            channelName: feed.title || channel
        });

    } catch (error) {
        console.error('❌ YouTube API Error:', error);
        const message = error instanceof Error ? error.message : 'Unknown error';
        res.status(500).json({
            error: message,
            videos: [],
            channelName: 'TchadDiplomatie'
        });
    }
});

module.exports = router;
