const express = require('express');
const router = express.Router();
const fs = require('fs');
const path = require('path');

/**
 * Tweets Route with Caching
 * Falls back to cached data if Nitter instances are unreachable
 */

const TWEETS_CACHE_FILE = path.join(__dirname, '../data/tweetsCache.json');
const CACHE_DURATION = 12 * 60 * 60 * 1000; // 12 hours

const NITTER_INSTANCES = [
    'https://nitter.net',
    'https://nitter.1d4.us',
    'https://nitter.kavin.rocks',
    'https://nitter.unixfox.eu',
    'https://nitter.at'
];

// Load cached tweets from file
function getCachedTweets() {
    try {
        if (fs.existsSync(TWEETS_CACHE_FILE)) {
            const data = JSON.parse(fs.readFileSync(TWEETS_CACHE_FILE, 'utf8'));
            if (data.timestamp && Date.now() - data.timestamp < CACHE_DURATION) {
                console.log('[Tweets] ✅ Returning cached tweets');
                return { tweets: data.tweets, source: 'cache', cached: true };
            }
        }
    } catch (err) {
        console.error('[Tweets] Error reading cache:', err.message);
    }
    return null;
}

// Save tweets to cache file
function cacheTweets(tweets) {
    try {
        const data = { tweets, timestamp: Date.now() };
        fs.writeFileSync(TWEETS_CACHE_FILE, JSON.stringify(data, null, 2));
        console.log('[Tweets] 💾 Tweets cached to file');
    } catch (err) {
        console.error('[Tweets] Error caching tweets:', err.message);
    }
}

function parseRss(xmlText, limit = 15) {
    const items = [];
    const itemRegex = /<item>([\s\S]*?)<\/item>/g;
    let match;
    while ((match = itemRegex.exec(xmlText)) && items.length < limit) {
        const item = match[1];
        const titleMatch = /<title>([\s\S]*?)<\/title>/.exec(item);
        const linkMatch = /<link>([\s\S]*?)<\/link>/.exec(item);
        const dateMatch = /<pubDate>([\s\S]*?)<\/pubDate>/.exec(item);
        const descMatch = /<description>([\s\S]*?)<\/description>/.exec(item);

        const title = titleMatch ? titleMatch[1].trim() : '';
        const link = linkMatch ? linkMatch[1].trim() : '';
        const pubDate = dateMatch ? dateMatch[1].trim() : '';
        const desc = descMatch ? descMatch[1].trim() : '';

        // extract images from description HTML
        const images = [];
        const imgRe = /<img[^>]+src="([^">]+)"/g;
        let im;
        while ((im = imgRe.exec(desc)) !== null) images.push(im[1]);

        items.push({
            id: link.split('/').pop() || Math.random().toString(36).slice(2),
            text: title || desc.replace(/<[^>]+>/g, '').slice(0, 280),
            author: 'MAE_Tchad',
            date: pubDate,
            likes: 0,
            retweets: 0,
            replies: 0,
            images,
            url: link
        });
    }
    return items;
}

async function fetchFromNitter(username, limit = 15) {
    const errors = [];
    for (const instance of NITTER_INSTANCES) {
        try {
            const url = `${instance}/${username}/rss`;
            const controller = new AbortController();
            const timeout = setTimeout(() => controller.abort(), 10000);

            console.log(`[Tweets] Trying instance: ${instance}`);
            const res = await fetch(url, { signal: controller.signal });
            clearTimeout(timeout);

            if (!res.ok) {
                errors.push(`${instance} HTTP ${res.status}`);
                console.log(`[Tweets] ❌ ${instance} returned ${res.status}`);
                continue;
            }

            const text = await res.text();
            const parsed = parseRss(text, limit);
            console.log(`[Tweets] ✅ Successfully fetched from ${instance}`);
            return { tweets: parsed, instance };
        } catch (err) {
            errors.push(`${instance} -> ${err && err.message ? err.message : String(err)}`);
            console.log(`[Tweets] ❌ ${instance} failed: ${err.message}`);
            continue;
        }
    }
    throw new Error('All Nitter instances failed: ' + errors.join(' | '));
}

router.get('/health', (req, res) => {
    res.json({ success: true, message: 'tweets route ok' });
});

router.get('/', async (req, res) => {
    const username = req.query.username || 'MAE_Tchad';
    const limit = parseInt(req.query.limit || '15', 10) || 15;

    try {
        console.log(`[Tweets] Fetching tweets for @${username}...`);

        // Try to fetch fresh data
        const { tweets, instance } = await fetchFromNitter(username, limit);

        // Cache the fresh data
        cacheTweets(tweets);

        return res.json({
            success: true,
            source: 'live',
            instance,
            data: tweets,
            message: 'Tweets fetched from Nitter'
        });

    } catch (error) {
        console.error('[Tweets] Error fetching fresh data:', error.message);

        // Try to return cached data
        const cached = getCachedTweets();
        if (cached) {
            console.log('[Tweets] Returning cached tweets as fallback');
            return res.json({
                success: true,
                source: 'cache',
                data: cached.tweets,
                message: 'Tweets served from cache due to network error'
            });
        }

        // No cache and network failed
        console.log('[Tweets] No cache available, returning empty');
        return res.status(503).json({
            success: false,
            error: 'Twitter service temporarily unavailable',
            data: [],
            source: 'error',
            message: 'Unable to fetch tweets. Please try again later.'
        });
    }
});

module.exports = router;