const { DataTypes } = require('sequelize');

/**
 * Recrutement Model - For recruitment posts
 */
module.exports = (sequelize) => {
    const Recrutement = sequelize.define('Recrutement', {
        id: {
            type: DataTypes.UUID,
            defaultValue: DataTypes.UUIDV4,
            primaryKey: true
        },
        title: {
            type: DataTypes.STRING(255),
            allowNull: false
        },
        description: {
            type: DataTypes.TEXT,
            allowNull: false
        },
        position: {
            type: DataTypes.STRING(150),
            allowNull: false
        },
        department: {
            type: DataTypes.STRING(150),
            allowNull: true
        },
        location: {
            type: DataTypes.STRING(150),
            allowNull: true
        },
        salary: {
            type: DataTypes.STRING(100),
            allowNull: true
        },
        contractType: {
            type: DataTypes.STRING(100),
            allowNull: true
        },
        deadline: {
            type: DataTypes.DATE,
            allowNull: true
        },
        publishDate: {
            type: DataTypes.DATE,
            defaultValue: DataTypes.NOW
        },
        active: {
            type: DataTypes.BOOLEAN,
            defaultValue: true
        },
        createdAt: {
            type: DataTypes.DATE,
            defaultValue: DataTypes.NOW
        },
        updatedAt: {
            type: DataTypes.DATE,
            defaultValue: DataTypes.NOW
        }
    }, {
        tableName: 'recrutements',
        timestamps: true,
        indexes: [
            { fields: ['active', 'publishDate'] },
            { fields: ['position'] }
        ]
    });

    return Recrutement;
};
