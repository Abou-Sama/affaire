const { DataTypes } = require('sequelize');
const bcrypt = require('bcrypt');

/**
 * User Model for Sequelize
 * Migration from Mongoose to SQL database
 */

module.exports = (sequelize) => {
    const User = sequelize.define('User', {
        id: {
            type: DataTypes.UUID,
            defaultValue: DataTypes.UUIDV4,
            primaryKey: true
        },
        email: {
            type: DataTypes.STRING(255),
            allowNull: true, // Email is optional - linked to admin account
            unique: true,
            lowercase: true,
            trim: true,
            validate: {
                isEmail: { msg: 'Please provide a valid email address' }
            },
            index: true
        },
        username: {
            type: DataTypes.STRING(100),
            allowNull: false,
            unique: true,
            lowercase: true,
            trim: true,
            validate: {
                len: {
                    args: [3, 100],
                    msg: 'Username must be between 3 and 100 characters'
                },
                isAlphanumeric: { msg: 'Username must contain only letters, numbers, and underscores' }
            },
            index: true
        },
        name: {
            type: DataTypes.STRING(100),
            allowNull: false,
            trim: true,
            validate: {
                len: {
                    args: [2, 100],
                    msg: 'Name must be between 2 and 100 characters'
                }
            }
        },
        password: {
            type: DataTypes.STRING(255),
            allowNull: false,
            validate: {
                len: {
                    args: [8, 255],
                    msg: 'Password must be at least 8 characters'
                }
            }
        },
        role: {
            type: DataTypes.ENUM('user', 'editor', 'admin'),
            defaultValue: 'user'
        },
        status: {
            type: DataTypes.ENUM('pending', 'active', 'suspended', 'deleted'),
            defaultValue: 'active'
        },
        permissions: {
            type: DataTypes.JSON,
            defaultValue: {}
        },
        passwordChangedAt: {
            type: DataTypes.DATE,
            allowNull: true
        },
        passwordResetToken: {
            type: DataTypes.STRING(255),
            allowNull: true
        },
        passwordResetExpires: {
            type: DataTypes.DATE,
            allowNull: true
        },
        failedLoginAttempts: {
            type: DataTypes.INTEGER,
            defaultValue: 0
        },
        accountLockedUntil: {
            type: DataTypes.DATE,
            allowNull: true
        },
        lastLogin: {
            type: DataTypes.DATE,
            allowNull: true
        },
        createdAt: {
            type: DataTypes.DATE,
            defaultValue: DataTypes.NOW
        },
        updatedAt: {
            type: DataTypes.DATE,
            defaultValue: DataTypes.NOW
        }
    }, {
        tableName: 'users',
        timestamps: true,
        indexes: [
            { fields: ['email'] },
            { fields: ['username'] },
            { fields: ['status'] }
        ]
    });

    // === HOOKS ===

    // Hash password before creating/updating
    User.beforeCreate(async (user) => {
        if (user.password) {
            const salt = await bcrypt.genSalt(10);
            user.password = await bcrypt.hash(user.password, salt);
        }
    });

    User.beforeUpdate(async (user) => {
        if (user.changed('password')) {
            const salt = await bcrypt.genSalt(10);
            user.password = await bcrypt.hash(user.password, salt);
            user.passwordChangedAt = new Date();
        }
    });

    // === INSTANCE METHODS ===

    // Compare password
    User.prototype.comparePassword = async function (enteredPassword) {
        return await bcrypt.compare(enteredPassword, this.password);
    };

    // Check if account is locked
    User.prototype.isAccountLocked = function () {
        if (!this.accountLockedUntil) return false;
        return new Date() < this.accountLockedUntil;
    };

    // Lock account
    User.prototype.lockAccount = async function (durationMinutes = 30) {
        this.accountLockedUntil = new Date(Date.now() + durationMinutes * 60 * 1000);
        await this.save();
    };

    // Unlock account
    User.prototype.unlockAccount = async function () {
        this.accountLockedUntil = null;
        this.failedLoginAttempts = 0;
        await this.save();
    };

    // Increment failed login attempts
    User.prototype.incrementFailedAttempts = async function () {
        this.failedLoginAttempts += 1;
        if (this.failedLoginAttempts >= 5) {
            await this.lockAccount();
        }
        await this.save();
    };

    // Reset failed login attempts on successful login
    User.prototype.resetFailedAttempts = async function () {
        this.failedLoginAttempts = 0;
        this.accountLockedUntil = null;
        this.lastLogin = new Date();
        await this.save();
    };

    // Check if password was changed after token was issued
    User.prototype.changedPasswordAfter = function (tokenIssuedAt) {
        if (!this.passwordChangedAt) return false;
        // Convert to seconds for comparison with JWT iat (issued at) claim
        const changedAtSeconds = Math.floor(this.passwordChangedAt.getTime() / 1000);
        return changedAtSeconds > tokenIssuedAt;
    };

    // JSON representation (exclude password)
    User.prototype.toJSON = function () {
        const { password, ...user } = this.dataValues;
        return user;
    };

    return User;
};
