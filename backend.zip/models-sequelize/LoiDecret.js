const { DataTypes } = require('sequelize');

/**
 * LoiDecret Model - For laws and decrees
 */
module.exports = (sequelize) => {
    const LoiDecret = sequelize.define('LoiDecret', {
        id: {
            type: DataTypes.UUID,
            defaultValue: DataTypes.UUIDV4,
            primaryKey: true
        },
        title: {
            type: DataTypes.STRING(255),
            allowNull: false
        },
        description: {
            type: DataTypes.TEXT,
            allowNull: true
        },
        content: {
            type: DataTypes.TEXT,
            allowNull: true
        },
        documentUrl: {
            type: DataTypes.TEXT,
            allowNull: true
        },
        documentDate: {
            type: DataTypes.DATE,
            allowNull: true
        },
        publishDate: {
            type: DataTypes.DATE,
            defaultValue: DataTypes.NOW
        },
        category: {
            type: DataTypes.STRING(150),
            allowNull: true
        },
        active: {
            type: DataTypes.BOOLEAN,
            defaultValue: true
        },
        createdAt: {
            type: DataTypes.DATE,
            defaultValue: DataTypes.NOW
        },
        updatedAt: {
            type: DataTypes.DATE,
            defaultValue: DataTypes.NOW
        }
    }, {
        tableName: 'lois_decrets',
        timestamps: true,
        indexes: [
            { fields: ['active', 'publishDate'] },
            { fields: ['category'] }
        ]
    });

    return LoiDecret;
};
