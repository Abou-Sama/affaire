const { DataTypes } = require('sequelize');

/**
 * Mediatheque Model - For media files and resources
 */
module.exports = (sequelize) => {
    const Mediatheque = sequelize.define('Mediatheque', {
        id: {
            type: DataTypes.UUID,
            defaultValue: DataTypes.UUIDV4,
            primaryKey: true
        },
        title: {
            type: DataTypes.STRING(255),
            allowNull: false
        },
        description: {
            type: DataTypes.TEXT,
            allowNull: true
        },
        mediaType: {
            type: DataTypes.ENUM('image', 'video', 'audio', 'document', 'other'),
            allowNull: false,
            defaultValue: 'document'
        },
        fileUrl: {
            type: DataTypes.TEXT,
            allowNull: false
        },
        fileName: {
            type: DataTypes.STRING(255),
            allowNull: true
        },
        fileSize: {
            type: DataTypes.BIGINT,
            allowNull: true
        },
        category: {
            type: DataTypes.STRING(150),
            allowNull: true
        },
        uploadDate: {
            type: DataTypes.DATE,
            defaultValue: DataTypes.NOW
        },
        active: {
            type: DataTypes.BOOLEAN,
            defaultValue: true
        },
        createdAt: {
            type: DataTypes.DATE,
            defaultValue: DataTypes.NOW
        },
        updatedAt: {
            type: DataTypes.DATE,
            defaultValue: DataTypes.NOW
        }
    }, {
        tableName: 'mediatheques',
        timestamps: true,
        indexes: [
            { fields: ['category', 'active'] },
            { fields: ['uploadDate'] },
            { fields: ['mediaType'] }
        ]
    });

    return Mediatheque;
};
