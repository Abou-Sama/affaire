const { DataTypes } = require('sequelize');

/**
 * Video Model for Sequelize
 * Stores YouTube videos
 */

module.exports = (sequelize) => {
    const Video = sequelize.define('Video', {
        id: {
            type: DataTypes.UUID,
            defaultValue: DataTypes.UUIDV4,
            primaryKey: true
        },
        youtubeId: {
            type: DataTypes.STRING(50),
            allowNull: false,
            unique: true,
            index: true,
            trim: true
        },
        title: {
            type: DataTypes.STRING(255),
            allowNull: false,
            trim: true
        },
        description: {
            type: DataTypes.TEXT,
            defaultValue: ''
        },
        publishedAt: {
            type: DataTypes.DATE,
            allowNull: false,
            index: true
        },
        thumbnailUrl: {
            type: DataTypes.STRING(500),
            allowNull: false
        },
        videoUrl: {
            type: DataTypes.STRING(500),
            allowNull: false
        },
        channelId: {
            type: DataTypes.STRING(100),
            defaultValue: ''
        },
        channelTitle: {
            type: DataTypes.STRING(255),
            defaultValue: ''
        },
        position: {
            type: DataTypes.INTEGER,
            defaultValue: 0,
            index: true
        },
        addedAt: {
            type: DataTypes.DATE,
            defaultValue: DataTypes.NOW,
            index: true
        },
        createdAt: {
            type: DataTypes.DATE,
            defaultValue: DataTypes.NOW
        },
        updatedAt: {
            type: DataTypes.DATE,
            defaultValue: DataTypes.NOW
        }
    }, {
        tableName: 'videos',
        timestamps: true,
        indexes: [
            { fields: ['youtubeId'] },
            { fields: ['publishedAt', 'descending'] },
            { fields: ['addedAt', 'descending'] }
        ]
    });

    // === VIRTUAL PROPERTIES ===

    // Get embed URL
    Video.prototype.getEmbedUrl = function () {
        return `https://www.youtube.com/embed/${this.youtubeId}`;
    };

    return Video;
};
