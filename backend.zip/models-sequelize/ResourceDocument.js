const { DataTypes } = require('sequelize');

/**
 * ResourceDocument Model - For resource documents and files
 */
module.exports = (sequelize) => {
    const ResourceDocument = sequelize.define('ResourceDocument', {
        id: {
            type: DataTypes.UUID,
            defaultValue: DataTypes.UUIDV4,
            primaryKey: true
        },
        title: {
            type: DataTypes.STRING(255),
            allowNull: false
        },
        description: {
            type: DataTypes.TEXT,
            allowNull: true
        },
        category: {
            type: DataTypes.STRING(150),
            allowNull: false
        },
        fileUrl: {
            type: DataTypes.TEXT,
            allowNull: false
        },
        fileName: {
            type: DataTypes.STRING(255),
            allowNull: true
        },
        fileSize: {
            type: DataTypes.BIGINT,
            allowNull: true
        },
        uploadDate: {
            type: DataTypes.DATE,
            defaultValue: DataTypes.NOW
        },
        active: {
            type: DataTypes.BOOLEAN,
            defaultValue: true
        },
        createdAt: {
            type: DataTypes.DATE,
            defaultValue: DataTypes.NOW
        },
        updatedAt: {
            type: DataTypes.DATE,
            defaultValue: DataTypes.NOW
        }
    }, {
        tableName: 'resource_documents',
        timestamps: true,
        indexes: [
            { fields: ['category', 'active'] },
            { fields: ['uploadDate'] }
        ]
    });

    return ResourceDocument;
};
