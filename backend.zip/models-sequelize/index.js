const { sequelize, Sequelize, isUsingJSON } = require('../config/database-mysql');

/**
 * Database Models Index
 * Initialize all Sequelize models
 */

// If using JSON mode, export stub models
if (isUsingJSON || !sequelize) {
    module.exports = {
        sequelize: null,
        Sequelize: null,
        User: null,
        Video: null,
        HomeContent: null,
        SyntheseActualite: null,
        Recrutement: null,
        LoiDecret: null,
        Mediatheque: null,
        ResourceDocument: null
    };
    return;
}

// Import model definitions
const UserModel = require('./User');
const VideoModel = require('./Video');
const HomeContentModel = require('./HomeContent');
const SyntheseActualiteModel = require('./SyntheseActualite');
const RecrutementModel = require('./Recrutement');
const LoiDecretModel = require('./LoiDecret');
const MediathequeModel = require('./Mediatheque');
const ResourceDocumentModel = require('./ResourceDocument');

// Initialize models
const User = UserModel(sequelize);
const Video = VideoModel(sequelize);
const HomeContent = HomeContentModel(sequelize);
const SyntheseActualite = SyntheseActualiteModel(sequelize);
const Recrutement = RecrutementModel(sequelize);
const LoiDecret = LoiDecretModel(sequelize);
const Mediatheque = MediathequeModel(sequelize);
const ResourceDocument = ResourceDocumentModel(sequelize);

// === ASSOCIATIONS ===
// Add relationships between models here if needed
// Example:
// User.hasMany(Video, { foreignKey: 'userId' });
// Video.belongsTo(User, { foreignKey: 'userId' });

// Export models
module.exports = {
    sequelize,
    Sequelize,
    User,
    Video,
    HomeContent,
    SyntheseActualite,
    Recrutement,
    LoiDecret,
    Mediatheque,
    ResourceDocument
};
