const { DataTypes } = require('sequelize');

/**
 * SyntheseActualite Model - For news synthesis posts
 */
module.exports = (sequelize) => {
    const SyntheseActualite = sequelize.define('SyntheseActualite', {
        id: {
            type: DataTypes.UUID,
            defaultValue: DataTypes.UUIDV4,
            primaryKey: true
        },
        type: {
            type: DataTypes.ENUM('image', 'video', 'text', 'poster'),
            allowNull: false,
            defaultValue: 'text'
        },
        title: {
            type: DataTypes.STRING(255),
            allowNull: false
        },
        description: {
            type: DataTypes.TEXT,
            allowNull: true
        },
        content: {
            type: DataTypes.TEXT,
            allowNull: false
        },
        publishDate: {
            type: DataTypes.DATE,
            defaultValue: DataTypes.NOW
        },
        active: {
            type: DataTypes.BOOLEAN,
            defaultValue: true
        },
        language: {
            type: DataTypes.ENUM('fr', 'en', 'ar'),
            defaultValue: 'fr',
            allowNull: false
        },
        createdAt: {
            type: DataTypes.DATE,
            defaultValue: DataTypes.NOW
        },
        updatedAt: {
            type: DataTypes.DATE,
            defaultValue: DataTypes.NOW
        }
    }, {
        tableName: 'synthese_actualites',
        timestamps: true,
        indexes: [
            { fields: ['active', 'publishDate'] },
            { fields: ['type'] }
        ]
    });

    return SyntheseActualite;
};
