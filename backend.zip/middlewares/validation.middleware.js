const { body, param, query, validationResult } = require('express-validator');

/**
 * Validation Middleware
 * Input validation rules for different routes
 */

/**
 * Handle validation errors
 */
const handleValidationErrors = (req, res, next) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(400).json({
            success: false,
            error: 'Validation failed',
            errors: errors.array().map(err => ({
                field: err.path,
                message: err.msg
            }))
        });
    }
    next();
};

/**
 * Validation Rules for User Registration/Signup
 */
const validateSignup = [
    body('email')
        .trim()
        .isEmail()
        .withMessage('Valid email is required')
        .normalizeEmail(),
    body('name')
        .trim()
        .isLength({ min: 2, max: 100 })
        .withMessage('Name must be between 2 and 100 characters')
        .matches(/^[a-zA-ZÀ-ÿ\s'-]+$/)
        .withMessage('Name can only contain letters, spaces, hyphens and apostrophes'),
    body('password')
        .isLength({ min: 8 })
        .withMessage('Password must be at least 8 characters')
        .matches(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]/)
        .withMessage('Password must contain uppercase, lowercase, number and special character'),
    handleValidationErrors
];

/**
 * Validation Rules for User Login
 */
const validateLogin = [
    body('email')
        .trim()
        .isEmail()
        .withMessage('Valid email is required')
        .normalizeEmail(),
    body('password')
        .notEmpty()
        .withMessage('Password is required'),
    handleValidationErrors
];

/**
 * Validation Rules for Password Change
 */
const validatePasswordChange = [
    body('currentPassword')
        .notEmpty()
        .withMessage('Current password is required'),
    body('newPassword')
        .isLength({ min: 8 })
        .withMessage('New password must be at least 8 characters')
        .matches(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]/)
        .withMessage('Password must contain uppercase, lowercase, number and special character'),
    body('newPassword')
        .custom((value, { req }) => {
            if (value === req.body.currentPassword) {
                throw new Error('New password must be different from current password');
            }
            return true;
        }),
    handleValidationErrors
];

/**
 * Validation Rules for Password Reset
 */
const validatePasswordReset = [
    body('email')
        .trim()
        .isEmail()
        .withMessage('Valid email is required')
        .normalizeEmail(),
    body('newPassword')
        .isLength({ min: 8 })
        .withMessage('Password must be at least 8 characters')
        .matches(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]/)
        .withMessage('Password must contain uppercase, lowercase, number and special character'),
    handleValidationErrors
];

/**
 * Validation Rules for User Profile Update
 */
const validateProfileUpdate = [
    body('name')
        .optional()
        .trim()
        .isLength({ min: 2, max: 100 })
        .withMessage('Name must be between 2 and 100 characters')
        .matches(/^[a-zA-ZÀ-ÿ\s'-]+$/)
        .withMessage('Name can only contain letters, spaces, hyphens and apostrophes'),
    body('email')
        .optional()
        .trim()
        .isEmail()
        .withMessage('Valid email is required')
        .normalizeEmail(),
    handleValidationErrors
];

/**
 * Validation Rules for Admin User Creation
 */
const validateAdminUserCreation = [
    body('email')
        .trim()
        .isEmail()
        .withMessage('Valid email is required')
        .normalizeEmail(),
    body('name')
        .trim()
        .isLength({ min: 2, max: 100 })
        .withMessage('Name must be between 2 and 100 characters'),
    body('password')
        .isLength({ min: 8 })
        .withMessage('Password must be at least 8 characters')
        .matches(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]/)
        .withMessage('Password must contain uppercase, lowercase, number and special character'),
    body('role')
        .optional()
        .isIn(['user', 'editor', 'admin'])
        .withMessage('Invalid role'),
    handleValidationErrors
];

/**
 * Validation Rules for MongoDB ObjectId
 */
const validateObjectId = [
    param('id')
        .isMongoId()
        .withMessage('Invalid ID format'),
    handleValidationErrors
];

/**
 * Validation Rules for Refresh Token
 */
const validateRefreshToken = [
    body('refreshToken')
        .notEmpty()
        .withMessage('Refresh token is required'),
    handleValidationErrors
];

/**
 * Sanitize input to prevent XSS and injection attacks
 */
const sanitizeInput = (req, res, next) => {
    const sanitizeValue = (value) => {
        if (typeof value === 'string') {
            // Remove HTML tags and dangerous characters
            return value
                .replace(/<[^>]*>/g, '')
                .replace(/[<>]/g, '')
                .replace(/javascript:/gi, '')
                .replace(/on\w+\s*=/gi, '');
        }
        return value;
    };

    const sanitize = (obj) => {
        if (obj === null || obj === undefined) return;
        
        for (let key in obj) {
            if (Object.prototype.hasOwnProperty.call(obj, key)) {
                if (typeof obj[key] === 'string') {
                    obj[key] = sanitizeValue(obj[key]);
                } else if (typeof obj[key] === 'object') {
                    sanitize(obj[key]);
                }
            }
        }
    };

    if (req.body) sanitize(req.body);
    if (req.query) sanitize(req.query);
    if (req.params) sanitize(req.params);

    next();
};

/**
 * Validate file uploads
 */
const validateFileUpload = (req, res, next) => {
    if (!req.file) {
        return next();
    }

    const MAX_FILE_SIZE = 10 * 1024 * 1024; // 10 MB
    const ALLOWED_MIMETYPES = [
        'image/jpeg',
        'image/png',
        'image/webp',
        'image/gif',
        'application/pdf',
        'video/mp4',
        'video/webm'
    ];

    // Check file size
    if (req.file.size > MAX_FILE_SIZE) {
        return res.status(400).json({
            success: false,
            error: 'File size exceeds maximum limit (10MB)'
        });
    }

    // Check MIME type
    if (!ALLOWED_MIMETYPES.includes(req.file.mimetype)) {
        return res.status(400).json({
            success: false,
            error: 'Invalid file type. Only images, videos, and PDFs are allowed.'
        });
    }

    next();
};

/**
 * Validate email domain (optional: restrict to certain domains)
 */
const validateEmailDomain = (allowedDomains = []) => {
    return body('email').custom((value) => {
        if (allowedDomains.length > 0) {
            const domain = value.split('@')[1];
            if (!allowedDomains.includes(domain)) {
                throw new Error(`Email domain must be one of: ${allowedDomains.join(', ')}`);
            }
        }
        return true;
    });
};

/**
 * Validate password strength
 */
const validatePasswordStrength = body('password').custom((value) => {
    const strength = {
        hasLowerCase: /[a-z]/.test(value),
        hasUpperCase: /[A-Z]/.test(value),
        hasNumbers: /\d/.test(value),
        hasSpecialChar: /[@$!%*?&]/.test(value),
        isLongEnough: value.length >= 12
    };

    const score = Object.values(strength).filter(Boolean).length;

    if (score < 4) {
        throw new Error('Password is not strong enough. Use at least 12 characters with uppercase, lowercase, numbers, and special characters.');
    }

    // Check for common weak passwords
    const commonPasswords = [
        'password123', 'admin123', 'qwerty123', '123456789',
        'password', 'admin', 'welcome', 'letmein'
    ];

    if (commonPasswords.includes(value.toLowerCase())) {
        throw new Error('This password is too common. Please choose a stronger password.');
    }

    return true;
});

/**
 * Validate SQL injection patterns
 */
const validateNoSQLInjection = (req, res, next) => {
    const sqlPatterns = [
        /(\b(UNION|SELECT|INSERT|UPDATE|DELETE|DROP|EXEC|EXECUTE|SCRIPT)\b)/i,
        /(-{2}|\/\*|\*\/|;)/,
        /(or|and)\s*['"]?\d+['"]?\s*=\s*['"]?\d+['"]?/i,
        /(['"];?\s*(or|and)\s*['"]|--|\*)/
    ];

    const checkValue = (value) => {
        if (typeof value !== 'string') return false;
        return sqlPatterns.some(pattern => pattern.test(value));
    };

    const checkObject = (obj) => {
        for (let key in obj) {
            if (checkValue(obj[key])) {
                return true;
            }
            if (typeof obj[key] === 'object' && obj[key] !== null) {
                if (checkObject(obj[key])) {
                    return true;
                }
            }
        }
        return false;
    };

    if (req.body && checkObject(req.body)) {
        return res.status(400).json({
            success: false,
            error: 'Invalid input detected'
        });
    }

    next();
};

module.exports = {
    validateSignup,
    validateLogin,
    validatePasswordChange,
    validatePasswordReset,
    validateProfileUpdate,
    validateAdminUserCreation,
    validateObjectId,
    validateRefreshToken,
    validatePasswordStrength,
    validateFileUpload,
    validateEmailDomain,
    validateNoSQLInjection,
    sanitizeInput,
    handleValidationErrors
};
