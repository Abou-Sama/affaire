const logger = require('../config/logger');

/**
 * HTTPS Enforcement Middleware
 * Redirects HTTP to HTTPS and enforces secure connections
 */

/**
 * Redirect HTTP to HTTPS
 */
const httpsRedirect = (req, res, next) => {
    if (process.env.NODE_ENV === 'production') {
        // Check if request is already HTTPS
        if (req.header('x-forwarded-proto') !== 'https') {
            // Reconstruct URL with https
            const url = `https://${req.header('host')}${req.url}`;
            return res.redirect(301, url);
        }
    }
    next();
};

/**
 * Enforce secure cookies
 */
const enforceSecureCookies = (req, res, next) => {
    if (process.env.NODE_ENV === 'production') {
        // Set Strict-Transport-Security header
        res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains; preload');
    }
    next();
};

/**
 * Verify HTTPS in headers (for reverse proxy setups)
 */
const verifyHttpsProxy = (req, res, next) => {
    if (process.env.NODE_ENV === 'production') {
        const protocol = req.header('x-forwarded-proto') || req.protocol;
        
        if (protocol !== 'https') {
            logger.warn(`Non-HTTPS request detected from ${req.ip}: ${req.method} ${req.path}`);
            // In strict mode, reject non-HTTPS requests
            // return res.status(403).json({
            //     success: false,
            //     error: 'HTTPS is required'
            // });
        }
    }
    next();
};

module.exports = {
    httpsRedirect,
    enforceSecureCookies,
    verifyHttpsProxy
};
