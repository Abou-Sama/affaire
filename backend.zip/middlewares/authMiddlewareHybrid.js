/**
 * Hybrid Authentication Middleware
 * Works with both database and JSON
 */

const authService = require('../services/authServiceHybrid');
const logger = require('../config/logger');

/**
 * Authenticate token from Bearer header
 */
function authenticateTokenHybrid(req, res, next) {
    try {
        const authHeader = req.headers['authorization'];
        const token = authHeader && authHeader.split(' ')[1]; // Bearer TOKEN

        if (!token) {
            return res.status(401).json({
                success: false,
                error: 'Access token required'
            });
        }

        try {
            const decoded = authService.verifyToken(token);
            req.user = decoded;
            next();
        } catch (tokenError) {
            logger.warn('Invalid token:', tokenError.message);
            return res.status(401).json({
                success: false,
                error: 'Invalid or expired token'
            });
        }
    } catch (error) {
        logger.error('Auth middleware error:', error);
        return res.status(500).json({
            success: false,
            error: 'Authentication failed'
        });
    }
}

/**
 * Require admin role
 */
function requireAdmin(req, res, next) {
    if (!req.user) {
        return res.status(401).json({
            success: false,
            error: 'Not authenticated'
        });
    }

    if (req.user.role !== 'admin') {
        return res.status(403).json({
            success: false,
            error: 'Admin access required'
        });
    }

    next();
}

module.exports = {
    authenticateTokenHybrid,
    authenticateToken: authenticateTokenHybrid, // Alias for compatibility
    requireAdmin
};
