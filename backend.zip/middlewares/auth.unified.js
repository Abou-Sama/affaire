/**
 * Unified Authentication Middleware
 * - Uses JWT_SECRET from environment
 * - Validates with Sequelize User model (MySQL)
 * - Falls back to JSON users when the DB is unavailable or the user is not in DB
 * - Works for ALL protected endpoints
 */

const jwt = require('jsonwebtoken');
const fs = require('fs');
const path = require('path');
const logger = require('../config/logger');
const sessionService = require('../services/sessionService');

// Get JWT_SECRET from environment (loaded by dotenv in server.js).
// Legacy fallback secrets are accepted only outside production so a public default
// cannot be used to forge production admin tokens.
const JWT_SECRET = process.env.JWT_SECRET || (process.env.NODE_ENV === 'production' ? undefined : 'your-secret-key-change-in-production');
const configuredSecrets = [
    process.env.JWT_SECRET,
    process.env.JWT_REFRESH_SECRET,
    process.env.REFRESH_TOKEN_SECRET
];
const developmentFallbackSecrets = process.env.NODE_ENV === 'production' ? [] : [
    'your-secret-key-change-in-production',
    'ministere-tchad-diplomatie-secret-key-2026-prod'
];
const JWT_SECRETS = Array.from(new Set([
    ...configuredSecrets,
    ...developmentFallbackSecrets
].filter(Boolean)));

console.log('\n=== AUTH.UNIFIED.JS INITIALIZED ===');
console.log(`JWT_SECRET loaded: ${JWT_SECRET ? 'YES' : 'NO'}`);
console.log('====================================\n');

function findJsonUser(decoded) {
    try {
        const usersFile = path.join(__dirname, '../data/users.json');
        if (!fs.existsSync(usersFile)) return null;

        const users = JSON.parse(fs.readFileSync(usersFile, 'utf8') || '[]');
        return users.find((user) =>
            String(user.id) === String(decoded.id) ||
            String(user.email || '').toLowerCase() === String(decoded.email || '').toLowerCase()
        ) || null;
    } catch (error) {
        console.warn(`[AUTH] JSON user fallback failed: ${error.message}`);
        return null;
    }
}

function setRequestUser(req, user) {
    req.user = {
        id: user.id,
        email: user.email,
        role: user.role,
        name: user.name,
        status: user.status || 'active',
        permissions: user.permissions || {},
        sessionId: user.sessionId
    };
}

function hasUserPermission(user, permission) {
    if (!user) return false;
    if (user.role === 'admin' || user.role === 'superadmin') return true;

    const permissions = user.permissions || {};
    if (Array.isArray(permissions)) {
        return permissions.includes(permission);
    }

    if (permissions && typeof permissions === 'object') {
        return permissions[permission] === true;
    }

    return false;
}

function getCookie(req, name) {
    const cookieHeader = req.headers.cookie;
    if (!cookieHeader) return null;

    const cookies = cookieHeader.split(';').map((cookie) => cookie.trim());
    const cookie = cookies.find((item) => item.startsWith(`${name}=`));
    if (!cookie) return null;

    return decodeURIComponent(cookie.slice(name.length + 1));
}

function verifyJwtWithKnownSecrets(token) {
    let lastError;

    for (const secret of JWT_SECRETS) {
        try {
            return jwt.verify(token, secret);
        } catch (error) {
            lastError = error;
        }
    }

    throw lastError;
}

/**
 * Authenticate JWT Token
 * Verifies JWT and validates user in database or JSON fallback.
 */
async function authenticateToken(req, res, next) {
    try {
        const authHeader = req.headers['authorization'];
        const token = authHeader && authHeader.split(' ')[1]; // Bearer TOKEN
        const refreshToken = getCookie(req, 'refreshToken');

        if (!token && !refreshToken) {
            console.log('[AUTH] No token provided');
            return res.status(401).json({
                success: false,
                error: 'Access token required'
            });
        }

        console.log(`\n[AUTH] Verifying token for request: ${req.method} ${req.path}`);

        let decoded;
        let tokenError;
        for (const candidateToken of [token, refreshToken].filter(Boolean)) {
            try {
                decoded = verifyJwtWithKnownSecrets(candidateToken);
                break;
            } catch (error) {
                tokenError = error;
            }
        }

        if (!decoded) {
            console.error('[AUTH] JWT verification failed:', tokenError.message);
            return res.status(401).json({
                success: false,
                error: 'Invalid or expired token',
                details: tokenError.message
            });
        }

        const sessionCheck = sessionService.validateSession(decoded.id, decoded.sid);
        if (!sessionCheck.valid) {
            console.warn(`[AUTH] Session rejected for ${decoded.email || decoded.id}: ${sessionCheck.reason}`);
            return res.status(401).json({
                success: false,
                error: sessionCheck.reason === 'session_expired'
                    ? 'Session expired. Please login again.'
                    : 'This account is already connected elsewhere or the session is invalid.'
            });
        }

        decoded.sessionId = decoded.sid;

        console.log(`[AUTH] JWT verified for user: ${decoded.email}`);

        try {
            const { User } = require('../models-sequelize');

            if (User) {
                console.log(`[AUTH] Querying Sequelize User model for ID: ${decoded.id}`);
                const user = await User.findByPk(decoded.id);

                if (user) {
                    if (user.status !== 'active') {
                        console.warn(`[AUTH] User not active (Status: ${user.status})`);
                        return res.status(403).json({
                            success: false,
                            error: 'Account is not active'
                        });
                    }

                    console.log(`[AUTH] User validated from DB: ${user.email} (Role: ${user.role})`);
                    setRequestUser(req, user);
                } else {
                    console.warn(`[AUTH] User not found in DB (ID: ${decoded.id}), checking JSON fallback`);
                    const jsonUser = findJsonUser(decoded);

                    if (!jsonUser) {
                        return res.status(401).json({
                            success: false,
                            error: 'User not found'
                        });
                    }

                    if (jsonUser.status && jsonUser.status !== 'active') {
                        console.warn(`[AUTH] JSON user not active (Status: ${jsonUser.status})`);
                        return res.status(403).json({
                            success: false,
                            error: 'Account is not active'
                        });
                    }

                    console.log(`[AUTH] User validated from JSON fallback: ${jsonUser.email} (Role: ${jsonUser.role})`);
                    setRequestUser(req, jsonUser);
                }
            } else {
                console.warn('[AUTH] Sequelize User model not available, using JSON/JWT fallback');
                setRequestUser(req, findJsonUser(decoded) || decoded);
            }
        } catch (dbError) {
            console.warn(`[AUTH] Database validation failed: ${dbError.message}`);
            setRequestUser(req, findJsonUser(decoded) || decoded);
        }

        req.user.sessionId = decoded.sid;

        console.log(`[AUTH] Authentication successful for: ${req.user.email}\n`);
        next();
    } catch (error) {
        console.error('[AUTH] Unexpected error:', error);
        return res.status(500).json({
            success: false,
            error: 'Authentication failed'
        });
    }
}

/**
 * Require Admin Role
 */
function requireAdmin(req, res, next) {
    if (!req.user) {
        console.log('[AUTH] No user in request');
        return res.status(401).json({
            success: false,
            error: 'Not authenticated'
        });
    }

    if (req.user.role !== 'admin' && req.user.role !== 'superadmin') {
        console.log(`[AUTH] Admin required, user role: ${req.user.role}`);
        return res.status(403).json({
            success: false,
            error: 'Admin access required'
        });
    }

    console.log(`[AUTH] Admin verified: ${req.user.email}`);
    next();
}

/**
 * Require Superadmin Role
 */
function requireSuperadmin(req, res, next) {
    if (!req.user) {
        return res.status(401).json({
            success: false,
            error: 'Not authenticated'
        });
    }

    if (req.user.role !== 'superadmin') {
        return res.status(403).json({
            success: false,
            error: 'Superadmin access required'
        });
    }

    next();
}

/**
 * Require Editor or Admin Role
 */
function requireEditor(req, res, next) {
    if (!req.user) {
        console.log('[AUTH] No user in request');
        return res.status(401).json({
            success: false,
            error: 'Not authenticated'
        });
    }

    if (req.user.role !== 'admin' && req.user.role !== 'editor' && req.user.role !== 'superadmin') {
        console.log(`[AUTH] Editor access required, user role: ${req.user.role}`);
        return res.status(403).json({
            success: false,
            error: 'Editor or admin access required'
        });
    }

    console.log(`[AUTH] Editor verified: ${req.user.email}`);
    next();
}

function requirePermission(permission) {
    return (req, res, next) => {
        if (!req.user) {
            return res.status(401).json({
                success: false,
                error: 'Not authenticated'
            });
        }

        if (!hasUserPermission(req.user, permission)) {
            console.log(`[AUTH] Permission required: ${permission}, user: ${req.user.email}`);
            return res.status(403).json({
                success: false,
                error: `Permission required: ${permission}`
            });
        }

        next();
    };
}

function requireAnyPermission(permissions) {
    return (req, res, next) => {
        if (!req.user) {
            return res.status(401).json({
                success: false,
                error: 'Not authenticated'
            });
        }

        if (!permissions.some(permission => hasUserPermission(req.user, permission))) {
            console.log(`[AUTH] One of permissions required: ${permissions.join(', ')}, user: ${req.user.email}`);
            return res.status(403).json({
                success: false,
                error: 'Insufficient permissions'
            });
        }

        next();
    };
}

module.exports = {
    authenticateToken,
    requireAdmin,
    requireSuperadmin,
    requireEditor,
    requirePermission,
    requireAnyPermission,
    hasUserPermission,
    JWT_SECRET
};
