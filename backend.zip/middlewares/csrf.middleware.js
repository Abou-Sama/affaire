const crypto = require('crypto');
const logger = require('../config/logger');

/**
 * CSRF Protection Middleware
 * Prevents Cross-Site Request Forgery attacks
 */

// Store CSRF tokens with expiration (in production, use Redis)
const csrfTokens = new Map();

/**
 * Generate CSRF Token
 * Token expires after 1 hour
 */
const generateCSRFToken = () => {
    const token = crypto.randomBytes(32).toString('hex');
    const expiresAt = Date.now() + (60 * 60 * 1000); // 1 hour
    csrfTokens.set(token, expiresAt);
    
    // Clean up expired tokens
    for (const [key, expiry] of csrfTokens.entries()) {
        if (expiry < Date.now()) {
            csrfTokens.delete(key);
        }
    }
    
    return token;
};

/**
 * Validate CSRF Token
 * Checks if token is valid and not expired
 */
const validateCSRFToken = (token) => {
    if (!token) return false;
    
    const expiresAt = csrfTokens.get(token);
    if (!expiresAt) return false;
    
    if (expiresAt < Date.now()) {
        csrfTokens.delete(token);
        return false;
    }
    
    return true;
};

/**
 * CSRF Protection Middleware
 * GET requests get a CSRF token
 * POST/PUT/DELETE/PATCH requests must include valid CSRF token
 */
const csrfProtection = (req, res, next) => {
    // Skip CSRF for safe methods (GET, HEAD, OPTIONS)
    if (['GET', 'HEAD', 'OPTIONS'].includes(req.method)) {
        // Generate and attach token for safe methods
        const token = generateCSRFToken();
        res.setHeader('X-CSRF-Token', token);
        return next();
    }
    
    // For state-changing requests, validate CSRF token
    const token = req.headers['x-csrf-token'] || req.body._csrf;
    
    if (!token) {
        logger.warn(`CSRF token missing for ${req.method} ${req.path}`);
        return res.status(403).json({
            success: false,
            error: 'CSRF token required',
            code: 'CSRF_TOKEN_MISSING'
        });
    }
    
    if (!validateCSRFToken(token)) {
        logger.warn(`Invalid CSRF token for ${req.method} ${req.path}`);
        return res.status(403).json({
            success: false,
            error: 'Invalid or expired CSRF token',
            code: 'CSRF_TOKEN_INVALID'
        });
    }
    
    // Token is valid, remove it from storage
    csrfTokens.delete(token);
    next();
};

/**
 * Middleware to get CSRF token
 * GET /api/csrf-token - Returns new CSRF token
 */
const getCsrfToken = (req, res) => {
    const token = generateCSRFToken();
    res.json({
        success: true,
        csrfToken: token
    });
};

module.exports = {
    csrfProtection,
    generateCSRFToken,
    validateCSRFToken,
    getCsrfToken
};
