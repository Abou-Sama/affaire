/**
 * Permission Middleware
 * Checks if user has specific permissions
 */

const fs = require('fs');
const path = require('path');

// Read users from JSON file
const getUsersFile = () => {
    try {
        const dataDir = path.join(__dirname, '../data');
        const usersFile = path.join(dataDir, 'users.json');
        const data = fs.readFileSync(usersFile, 'utf8');
        return JSON.parse(data);
    } catch (error) {
        console.error('Error reading users file:', error);
        return [];
    }
};

// Get user permissions
const getUserPermissions = (email) => {
    const users = getUsersFile();
    const user = users.find(u => u.email === email);
    if (!user) return [];
    return user.permissions || [];
};

// Check if user has permission
const hasPermission = (email, permission) => {
    const permissions = getUserPermissions(email);
    return permissions.includes(permission);
};

// Middleware: Check specific permission
const checkPermission = (requiredPermission) => {
    return (req, res, next) => {
        const userEmail = req.user?.email;

        if (!userEmail) {
            return res.status(401).json({
                success: false,
                error: 'User not authenticated'
            });
        }

        if (!hasPermission(userEmail, requiredPermission)) {
            return res.status(403).json({
                success: false,
                error: `Permission denied. Required: ${requiredPermission}`
            });
        }

        next();
    };
};

// Middleware: Check if user is admin
const requireAdmin = (req, res, next) => {
    const users = getUsersFile();
    const user = users.find(u => u.email === req.user?.email);

    if (!user || user.role !== 'admin') {
        return res.status(403).json({
            success: false,
            error: 'Admin access required'
        });
    }

    next();
};

// Middleware: Check multiple permissions (any)
const checkAnyPermission = (permissions) => {
    return (req, res, next) => {
        const userEmail = req.user?.email;

        if (!userEmail) {
            return res.status(401).json({
                success: false,
                error: 'User not authenticated'
            });
        }

        const userPermissions = getUserPermissions(userEmail);
        const hasAny = permissions.some(p => userPermissions.includes(p));

        if (!hasAny) {
            return res.status(403).json({
                success: false,
                error: 'Insufficient permissions'
            });
        }

        next();
    };
};

// Middleware: Check multiple permissions (all)
const checkAllPermissions = (permissions) => {
    return (req, res, next) => {
        const userEmail = req.user?.email;

        if (!userEmail) {
            return res.status(401).json({
                success: false,
                error: 'User not authenticated'
            });
        }

        const userPermissions = getUserPermissions(userEmail);
        const hasAll = permissions.every(p => userPermissions.includes(p));

        if (!hasAll) {
            return res.status(403).json({
                success: false,
                error: 'Insufficient permissions'
            });
        }

        next();
    };
};

module.exports = {
    checkPermission,
    requireAdmin,
    checkAnyPermission,
    checkAllPermissions,
    getUserPermissions,
    hasPermission
};
