const AuthService = require('../services/authService');
const { User } = require('../models-sequelize');
const logger = require('../config/logger');

/**
 * Authentication Middleware
 * Protects routes requiring authentication
 */

/**
 * Authenticate JWT Token
 * Verifies access token and attaches user to request
 */
const authenticateToken = async (req, res, next) => {
    try {
        // Get token from header
        const authHeader = req.headers.authorization;
        const token = authHeader && authHeader.split(' ')[1]; // Bearer TOKEN

        if (!token) {
            return res.status(401).json({
                success: false,
                error: 'Access token required'
            });
        }

        // Verify token
        const decoded = AuthService.verifyAccessToken(token);

        // Check if user exists
        const user = await User.findByPk(decoded.id, {
            attributes: { exclude: ['password'] }
        });
        if (!user) {
            return res.status(401).json({
                success: false,
                error: 'User no longer exists'
            });
        }

        // Check if user is active
        if (user.status !== 'active') {
            return res.status(403).json({
                success: false,
                error: 'Account is not active'
            });
        }

        // Check if password was changed after token was issued
        if (user.changedPasswordAfter(decoded.iat)) {
            return res.status(401).json({
                success: false,
                error: 'Password was recently changed. Please login again'
            });
        }

        // Check if account is locked
        if (user.isAccountLocked()) {
            return res.status(403).json({
                success: false,
                error: 'Account is locked due to failed login attempts'
            });
        }

        // Attach user to request
        req.user = user;
        next();
    } catch (error) {
        logger.error('Authentication error:', error);

        if (error.message === 'Access token expired') {
            return res.status(401).json({
                success: false,
                error: 'Access token expired',
                code: 'TOKEN_EXPIRED'
            });
        }

        return res.status(401).json({
            success: false,
            error: 'Invalid or expired token'
        });
    }
};

/**
 * Require Admin Role
 * Checks if authenticated user has admin role
 */
const requireAdmin = (req, res, next) => {
    if (!req.user) {
        return res.status(401).json({
            success: false,
            error: 'Authentication required'
        });
    }

    if (req.user.role !== 'admin') {
        logger.warn(`Unauthorized admin access attempt by user: ${req.user.email}`);
        return res.status(403).json({
            success: false,
            error: 'Admin access required'
        });
    }

    next();
};

/**
 * Require Editor or Admin Role
 * Checks if authenticated user has editor or admin role
 */
const requireEditor = (req, res, next) => {
    if (!req.user) {
        return res.status(401).json({
            success: false,
            error: 'Authentication required'
        });
    }

    if (req.user.role !== 'admin' && req.user.role !== 'editor') {
        logger.warn(`Unauthorized editor access attempt by user: ${req.user.email}`);
        return res.status(403).json({
            success: false,
            error: 'Editor or admin access required'
        });
    }

    next();
};

/**
 * Require Specific Permission
 * Checks if user has specific permission
 */
const requirePermission = (permission) => {
    return (req, res, next) => {
        if (!req.user) {
            return res.status(401).json({
                success: false,
                error: 'Authentication required'
            });
        }

        // Admins have all permissions
        if (req.user.role === 'admin') {
            return next();
        }

        // Check specific permission
        if (!req.user.permissions || !req.user.permissions.get(permission)) {
            logger.warn(`Permission denied for user ${req.user.email}: ${permission}`);
            return res.status(403).json({
                success: false,
                error: `Permission required: ${permission}`
            });
        }

        next();
    };
};

/**
 * Optional Authentication
 * Attaches user if token is valid, but doesn't require it
 */
const optionalAuth = async (req, res, next) => {
    try {
        const authHeader = req.headers.authorization;
        const token = authHeader && authHeader.split(' ')[1];

        if (token) {
            const decoded = AuthService.verifyAccessToken(token);
            const user = await User.findById(decoded.id).select('-password');
            if (user && user.status === 'active') {
                req.user = user;
            }
        }
    } catch (error) {
        // Silently fail - authentication is optional
    }
    next();
};

module.exports = {
    authenticateToken,
    requireAdmin,
    requireEditor,
    requirePermission,
    optionalAuth
};
