const fs = require('fs');
const path = require('path');
const logger = require('../config/logger');

/**
 * Security Audit Logging
 * Logs all security-related events for audit trails
 */

const logDir = path.join(__dirname, '../logs');
const auditLogFile = path.join(logDir, 'security-audit.log');

// Ensure logs directory exists
if (!fs.existsSync(logDir)) {
    fs.mkdirSync(logDir, { recursive: true });
}

/**
 * Log security events
 */
const logSecurityEvent = (eventType, details) => {
    const timestamp = new Date().toISOString();
    const logEntry = {
        timestamp,
        eventType,
        details,
        ipAddress: details.ipAddress || 'unknown',
        userId: details.userId || 'anonymous',
        severity: details.severity || 'info'
    };

    // Log to file
    fs.appendFileSync(auditLogFile, JSON.stringify(logEntry) + '\n', 'utf8');

    // Also log to console in development
    if (process.env.NODE_ENV !== 'production') {
        console.log(`[SECURITY AUDIT] ${eventType}:`, logEntry);
    }
};

/**
 * Security Audit Middleware
 * Logs security-related events and suspicious activity
 */
const auditMiddleware = (req, res, next) => {
    const originalSend = res.send;

    // Override response send to capture status codes
    res.send = function (data) {
        const statusCode = res.statusCode;
        const clientIp = req.ip || req.connection.remoteAddress;

        // Log failed authentication attempts
        if (statusCode === 401) {
            logSecurityEvent('AUTH_FAILED', {
                ipAddress: clientIp,
                path: req.path,
                method: req.method,
                userId: req.user?.id || 'unknown',
                severity: 'warning'
            });
        }

        // Log authorization failures
        if (statusCode === 403) {
            logSecurityEvent('AUTH_DENIED', {
                ipAddress: clientIp,
                path: req.path,
                method: req.method,
                userId: req.user?.id,
                role: req.user?.role,
                severity: 'warning'
            });
        }

        // Log suspicious patterns
        if (statusCode === 400 && req.body) {
            const suspiciousPatterns = ['<script', 'javascript:', 'sql', 'union', 'select'];
            const bodyStr = JSON.stringify(req.body).toLowerCase();
            if (suspiciousPatterns.some(pattern => bodyStr.includes(pattern))) {
                logSecurityEvent('SUSPICIOUS_INPUT', {
                    ipAddress: clientIp,
                    path: req.path,
                    userId: req.user?.id,
                    severity: 'high'
                });
            }
        }

        // Log rate limit violations
        if (statusCode === 429) {
            logSecurityEvent('RATE_LIMIT_EXCEEDED', {
                ipAddress: clientIp,
                path: req.path,
                userId: req.user?.id,
                severity: 'warning'
            });
        }

        // Log successful sensitive operations
        if ([200, 201].includes(statusCode) && ['POST', 'PUT', 'DELETE'].includes(req.method)) {
            if (['/api/auth/login', '/api/auth/logout', '/api/users', '/api/admin'].some(route => req.path.startsWith(route))) {
                logSecurityEvent('SENSITIVE_OPERATION', {
                    ipAddress: clientIp,
                    path: req.path,
                    method: req.method,
                    userId: req.user?.id,
                    severity: 'info'
                });
            }
        }

        res.send = originalSend;
        return originalSend.call(this, data);
    };

    next();
};

/**
 * Middleware to log admin actions
 */
const logAdminAction = (req, res, next) => {
    if (req.user && req.user.role === 'admin') {
        const clientIp = req.ip || req.connection.remoteAddress;
        
        if (['POST', 'PUT', 'DELETE'].includes(req.method)) {
            logSecurityEvent('ADMIN_ACTION', {
                ipAddress: clientIp,
                path: req.path,
                method: req.method,
                userId: req.user.id,
                adminEmail: req.user.email,
                severity: 'info'
            });
        }
    }
    next();
};

/**
 * Middleware to log password changes
 */
const logPasswordChange = (action) => {
    return (req, res, next) => {
        const originalSend = res.send;

        res.send = function (data) {
            const statusCode = res.statusCode;
            const clientIp = req.ip || req.connection.remoteAddress;

            if ([200, 201].includes(statusCode)) {
                logSecurityEvent(`PASSWORD_${action.toUpperCase()}`, {
                    ipAddress: clientIp,
                    userId: req.user?.id,
                    userEmail: req.user?.email,
                    severity: 'high'
                });
            }

            res.send = originalSend;
            return originalSend.call(this, data);
        };

        next();
    };
};

/**
 * Get security audit logs
 * Admin only endpoint
 */
const getAuditLogs = (req, res) => {
    try {
        if (!fs.existsSync(auditLogFile)) {
            return res.json({ success: true, logs: [] });
        }

        const data = fs.readFileSync(auditLogFile, 'utf8');
        const logs = data
            .split('\n')
            .filter(line => line.trim())
            .map(line => {
                try {
                    return JSON.parse(line);
                } catch (e) {
                    return null;
                }
            })
            .filter(Boolean)
            .reverse()
            .slice(0, 1000); // Last 1000 entries

        res.json({
            success: true,
            logs,
            total: logs.length
        });
    } catch (error) {
        logger.error('Error reading audit logs:', error);
        res.status(500).json({
            success: false,
            error: 'Failed to retrieve audit logs'
        });
    }
};

/**
 * Clear old audit logs (older than specified days)
 */
const clearOldAuditLogs = (daysToKeep = 90) => {
    try {
        if (!fs.existsSync(auditLogFile)) return;

        const data = fs.readFileSync(auditLogFile, 'utf8');
        const lines = data.split('\n').filter(line => line.trim());
        
        const cutoffDate = new Date();
        cutoffDate.setDate(cutoffDate.getDate() - daysToKeep);

        const recentLines = lines.filter(line => {
            try {
                const log = JSON.parse(line);
                return new Date(log.timestamp) > cutoffDate;
            } catch (e) {
                return true;
            }
        });

        fs.writeFileSync(auditLogFile, recentLines.join('\n') + '\n', 'utf8');
        console.log(`[Security Audit] Cleared logs older than ${daysToKeep} days`);
    } catch (error) {
        logger.error('Error clearing old audit logs:', error);
    }
};

// Clear old logs daily
setInterval(() => {
    clearOldAuditLogs(90); // Keep 90 days of logs
}, 24 * 60 * 60 * 1000); // Run daily

module.exports = {
    auditMiddleware,
    logAdminAction,
    logPasswordChange,
    logSecurityEvent,
    getAuditLogs,
    clearOldAuditLogs
};
