const mongoose = require('mongoose');

/**
 * Connect to MongoDB
 * Uses MONGODB_URI environment variable for connection string
 */
const connectDB = async () => {
    try {
        const mongoURI = process.env.MONGODB_URI || 'mongodb://localhost:27017/ministere-tchad';

        await mongoose.connect(mongoURI);

        console.log('✅ MongoDB connected successfully');
        console.log(`📊 Database: ${mongoose.connection.name}`);

        // Handle connection events
        mongoose.connection.on('error', (err) => {
            console.error('❌ MongoDB connection error:', err);
        });

        mongoose.connection.on('disconnected', () => {
            console.warn('⚠️  MongoDB disconnected');
        });

        mongoose.connection.on('reconnected', () => {
            console.log('✅ MongoDB reconnected');
        });

    } catch (error) {
        console.error('❌ MongoDB connection failed:', error.message);
        console.error('\n⚠️  Make sure MongoDB is running and MONGODB_URI is set correctly');
        console.error('   Example: MONGODB_URI=mongodb://localhost:27017/ministere-tchad');
        // Don't exit process - allow server to run without DB for static content
        console.warn('⚠️  Server will continue running with limited functionality');
    }
};

module.exports = { connectDB };
