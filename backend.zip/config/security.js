const helmet = require('helmet');
const { rateLimit, ipKeyGenerator } = require('express-rate-limit');

/**
 * Security Configuration
 * Configures all security middlewares
 */

const sanitizeObject = (value, { stripNoSqlKeys = false } = {}) => {
    if (Array.isArray(value)) {
        return value.map((item) => sanitizeObject(item, { stripNoSqlKeys }));
    }

    if (value && typeof value === 'object') {
        const sanitized = {};

        for (const [key, nestedValue] of Object.entries(value)) {
            if (stripNoSqlKeys && (key.startsWith('$') || key.includes('.'))) {
                continue;
            }

            sanitized[key] = sanitizeObject(nestedValue, { stripNoSqlKeys });
        }

        return sanitized;
    }

    if (typeof value !== 'string') {
        return value;
    }

    return value
        .replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g, '')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;');
};

// Express 5-safe NoSQL key sanitizer. We avoid mutating req.query/req.params
// because Express 5 exposes them through getters in some configurations.
const mongoSanitizeConfig = () => {
    return (req, res, next) => {
        if (req.body && typeof req.body === 'object') {
            req.body = sanitizeObject(req.body, { stripNoSqlKeys: true });
        }
        next();
    };
};

// Helmet configuration for HTTP headers security
const helmetConfig = () => {
    return helmet({
        contentSecurityPolicy: {
            directives: {
                defaultSrc: ["'self'"],
                styleSrc: ["'self'", "'unsafe-inline'"],
                scriptSrc: ["'self'", 'https://cdn.curator.io'],
                imgSrc: ["'self'", 'data:', 'https:'],
                connectSrc: ["'self'", 'https://www.googleapis.com', 'https://youtube.googleapis.com'],
                fontSrc: ["'self'"],
                objectSrc: ["'none'"],
                mediaSrc: ["'self'"],
                frameSrc: ["'self'", 'https://www.youtube.com', 'https://www.youtube-nocookie.com'],
            },
        },
        hsts: {
            maxAge: 31536000, // 1 year
            includeSubDomains: true,
            preload: true
        },
        frameguard: {
            action: 'deny'
        },
        noSniff: true,
        xssFilter: true,
        referrerPolicy: { policy: 'strict-origin-when-cross-origin' }
    });
};

// Rate limiting configuration
const createRateLimiter = (windowMs, max, message = 'Too many requests from this IP') => {
    return rateLimit({
        windowMs: windowMs || parseInt(process.env.RATE_LIMIT_WINDOW_MS) || 15 * 60 * 1000, // 15 minutes
        max: max || parseInt(process.env.RATE_LIMIT_MAX_REQUESTS) || 100,
        message: message,
        standardHeaders: true,
        legacyHeaders: false,
        handler: (req, res) => {
            res.status(429).json({
                success: false,
                error: 'Too many requests, please try again later.',
                retryAfter: Math.ceil(windowMs / 1000)
            });
        }
    });
};

// Strict rate limiter for authentication endpoints
const authRateLimiter = createRateLimiter(
    15 * 60 * 1000, // 15 minutes
    5, // 5 requests max
    'Too many authentication attempts, please try again later'
);

// Very strict rate limiter for login attempts (brute force protection)
const loginRateLimiter = createRateLimiter(
    60 * 60 * 1000, // 60 minutes
    3, // 3 requests max
    'Too many login attempts. Please try again later.'
);

// Strict rate limiter for password reset attempts
const passwordResetRateLimiter = createRateLimiter(
    60 * 60 * 1000, // 60 minutes
    3, // 3 requests max
    'Too many password reset attempts. Please try again later.'
);

// Rate limiter for admin endpoints
const adminRateLimiter = createRateLimiter(
    10 * 60 * 1000, // 10 minutes
    50, // 50 requests max
    'Too many admin requests, please try again later'
);

// General API rate limiters. Reading public content is generous: one page view already makes
// several API calls, so a low shared limit blocked normal visitors and admins after a few pages.
const isReadRequest = (req) => ['GET', 'HEAD', 'OPTIONS'].includes(req.method);

const apiReadRateLimiter = rateLimit({
    windowMs: 15 * 60 * 1000,
    max: parseInt(process.env.RATE_LIMIT_READ_MAX_REQUESTS) || 3000,
    skip: (req) => !isReadRequest(req),
    standardHeaders: true,
    legacyHeaders: false,
    handler: (req, res) => {
        res.status(429).json({ success: false, error: 'Too many requests, please try again later.', retryAfter: 900 });
    }
});

const apiWriteRateLimiter = rateLimit({
    windowMs: 15 * 60 * 1000,
    max: parseInt(process.env.RATE_LIMIT_MAX_REQUESTS) || 300,
    skip: isReadRequest,
    standardHeaders: true,
    legacyHeaders: false,
    handler: (req, res) => {
        res.status(429).json({ success: false, error: 'Too many requests, please try again later.', retryAfter: 900 });
    }
});

const apiRateLimiter = [apiReadRateLimiter, apiWriteRateLimiter];

// Brute-force protection for credentials and one-time codes. The key combines the client IP with
// the targeted account, so a misconfigured proxy (all visitors sharing one IP) cannot lock out everyone.
const accountKey = (req) => {
    const body = req.body || {};
    const account = String(body.email || body.username || body.challengeId || body.targetEmail || '').trim().toLowerCase();
    return `${ipKeyGenerator(req.ip || '')}|${account}`;
};

const createSensitiveLimiter = (max, windowMs, message, onlyFailures) => rateLimit({
    windowMs,
    max,
    keyGenerator: accountKey,
    skipSuccessfulRequests: onlyFailures,
    standardHeaders: true,
    legacyHeaders: false,
    handler: (req, res) => {
        res.status(429).json({ success: false, error: message, retryAfter: Math.ceil(windowMs / 1000) });
    }
});

// Failed logins / wrong codes only: a correct password or code never counts
const credentialRateLimiter = createSensitiveLimiter(
    10, 15 * 60 * 1000,
    'Trop de tentatives de connexion. Reessayez dans 15 minutes.',
    true
);

// Requests that send an email (codes, password reset): limits mailbox spam
const emailSendingRateLimiter = createSensitiveLimiter(
    8, 15 * 60 * 1000,
    "Trop de demandes d'envoi d'email. Reessayez dans 15 minutes.",
    false
);

// Public contact form
const contactRateLimiter = createSensitiveLimiter(
    10, 15 * 60 * 1000,
    'Trop de messages envoyes. Reessayez dans 15 minutes.',
    false
);

// Baseline XSS protection for request bodies. React escapes rendered text,
// but encoded angle brackets keep stored content safe if a future view changes.
const xssConfig = () => {
    return (req, res, next) => {
        if (req.body && typeof req.body === 'object') {
            req.body = sanitizeObject(req.body);
        }
        next();
    };
};

/**
 * Request Size Limit Middleware
 * Prevents large payload attacks
 */
const requestSizeLimit = (limit = '10kb') => {
    return (req, res, next) => {
        const contentLength = parseInt(req.get('content-length')) || 0;
        const maxBytes = parseFloat(limit) * (limit.includes('mb') ? 1024 * 1024 : 1024);
        
        if (contentLength > maxBytes) {
            return res.status(413).json({
                success: false,
                error: `Request payload too large. Maximum size: ${limit}`
            });
        }
        next();
    };
};

/**
 * Request Timeout Middleware
 * Prevents slow client attacks
 */
const requestTimeout = (timeoutMs = 30000) => {
    return (req, res, next) => {
        const timeoutId = setTimeout(() => {
            if (!res.headersSent) {
                res.status(408).json({
                    success: false,
                    error: 'Request timeout'
                });
            }
            res.destroy();
        }, timeoutMs);
        
        res.on('finish', () => clearTimeout(timeoutId));
        res.on('close', () => clearTimeout(timeoutId));
        
        next();
    };
};

/**
 * Enhanced Helmet Configuration for Production
 */
const helmetConfigProduction = () => {
    return helmet({
        contentSecurityPolicy: {
            directives: {
                defaultSrc: ["'self'"],
                styleSrc: ["'self'", "'unsafe-inline'"],
                scriptSrc: ["'self'", 'https://cdn.curator.io'],
                imgSrc: ["'self'", 'data:', 'https:'],
                connectSrc: ["'self'", 'https://www.googleapis.com', 'https://youtube.googleapis.com'],
                fontSrc: ["'self'"],
                objectSrc: ["'none'"],
                mediaSrc: ["'self'"],
                frameSrc: ["'self'", 'https://www.youtube.com', 'https://www.youtube-nocookie.com'],
                baseUri: ["'self'"],
                formAction: ["'self'"],
                upgradeInsecureRequests: [''],
            },
        },
        hsts: {
            maxAge: 31536000, // 1 year
            includeSubDomains: true,
            preload: true
        },
        frameguard: {
            action: 'deny'
        },
        noSniff: true,
        xssFilter: true,
        referrerPolicy: { policy: 'strict-origin-when-cross-origin' },
        permissionsPolicy: {
            geolocation: [],
            microphone: [],
            camera: [],
            magnetometer: [],
            gyroscope: [],
            accelerometer: [],
            usb: [],
            payment: []
        },
        crossOriginResourcePolicy: { policy: 'cross-origin' },
        originAgentCluster: true,
        dnsPrefetchControl: { allow: false }
    });
};

module.exports = {
    helmetConfig,
    helmetConfigProduction,
    mongoSanitizeConfig,
    xssConfig,
    createRateLimiter,
    authRateLimiter,
    loginRateLimiter,
    passwordResetRateLimiter,
    adminRateLimiter,
    apiRateLimiter,
    credentialRateLimiter,
    emailSendingRateLimiter,
    contactRateLimiter,
    requestSizeLimit,
    requestTimeout
};
