/**
 * Sequelize Database Connection for MySQL/MariaDB
 * Falls back to JSON if MySQL is not available
 */

let sequelize = null;
let isUsingJSON = false;

try {
    const { Sequelize } = require('sequelize');

    // Initialize Sequelize instance
    sequelize = new Sequelize(
        process.env.DB_NAME || 'ministere_tchad',
        process.env.DB_USER || 'root',
        process.env.DB_PASSWORD || 'password',
        {
            host: process.env.DB_HOST || 'localhost',
            port: process.env.DB_PORT || 3306,
            dialect: 'mysql',
            logging: process.env.NODE_ENV === 'production' ? false : console.log,
            pool: {
                max: 10,
                min: 0,
                acquire: 30000,
                idle: 10000
            },
            define: {
                timestamps: true,
                underscored: true,
                freezeTableName: true
            }
        }
    );
} catch (error) {
    console.warn('[DB] ⚠️ MySQL not available, using JSON mode only');
    isUsingJSON = true;
}

/**
 * Connect to MySQL/MariaDB database
 * Falls back to JSON mode if MySQL is not available
 */
const connectDB = async () => {
    // If using JSON mode, skip database connection
    if (isUsingJSON) {
        console.log('[DB] 📄 Using JSON mode (MySQL not available)');
        return { success: false, sequelize: null, usingJSON: true };
    }

    try {
        console.log('[DB] Attempting to connect to MySQL/MariaDB...');
        console.log(`[DB] Host: ${process.env.DB_HOST || 'localhost'}`);
        console.log(`[DB] Database: ${process.env.DB_NAME || 'ministere_tchad'}`);

        // Test connection
        await sequelize.authenticate();
        console.log('✅ MySQL/MariaDB connected successfully');

        // Sync all models with database (creates tables if they don't exist)
        // force: false = don't drop tables, alter: true = modify tables as needed
        await sequelize.sync({
            alter: process.env.NODE_ENV === 'production' ? false : true,
            force: false
        });
        console.log('✅ Database models synchronized');
        console.log('[DB] ✅ All tables created/updated successfully');

        return { success: true, sequelize };
    } catch (error) {
        console.warn('⚠️  MySQL connection failed:', error.message);
        console.warn('\n📝 Database connection issue detected:');
        console.warn('   Error:', error.message);
        console.warn('   Falling back to JSON mode...');
        console.warn('');

        // Return as if using JSON
        return { success: false, sequelize: null, usingJSON: true };
    }
};
/**
 * Close database connection
 */
const closeDB = async () => {
    if (!sequelize) return;
    try {
        await sequelize.close();
        console.log('✅ Database connection closed');
    } catch (error) {
        console.error('❌ Error closing database connection:', error.message);
    }
};

module.exports = {
    sequelize,
    connectDB,
    closeDB,
    Sequelize: require('sequelize')?.Sequelize || null,
    isUsingJSON
};
