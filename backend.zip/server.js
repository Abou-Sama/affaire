// Load environment variables first
require('dotenv').config();

// Validate JWT_SECRET is set
if (!process.env.JWT_SECRET) {
    if (process.env.NODE_ENV === 'production') {
        console.error('❌ JWT_SECRET must be set in production');
        process.exit(1);
    }
    console.warn('⚠️  WARNING: JWT_SECRET not set in .env, continuing in development mode');
} else {
    console.log('✅ JWT_SECRET loaded from .env');
}

const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const cookieParser = require('cookie-parser');
const fs = require('fs');
const path = require('path');
const multer = require('multer');
const nodemailer = require('nodemailer');
const fetch = require('node-fetch');
const jwt = require('jsonwebtoken');
const crypto = require('crypto');

// Use unified authentication middleware (MySQL + JWT)
const {
    authenticateToken,
    requireAdmin,
    requireEditor,
    requirePermission,
    JWT_SECRET
} = require('./middlewares/auth.unified');
const {
    helmetConfig,
    mongoSanitizeConfig,
    xssConfig,
    apiRateLimiter,
    credentialRateLimiter,
    emailSendingRateLimiter,
    contactRateLimiter
} = require('./config/security');
const {
    hashPassword,
    comparePassword,
    validatePassword
} = require('./utils/password');
const sessionService = require('./services/sessionService');
const { enforcePostLimit } = require('./utils/postLimit');
const {
    IMAGE_MIME_EXTENSIONS,
    DOCUMENT_MIME_EXTENSIONS,
    VIDEO_MIME_EXTENSIONS,
    createFileFilter,
    generateSafeFilename,
    blockDangerousUploads,
    uploadedStaticOptions
} = require('./utils/uploadSecurity');
const {
    normalizeImageUrl,
    normalizeSafeUrl,
    normalizeYouTubeEmbedUrl
} = require('./utils/urlSecurity');
const { sanitizeText, sanitizeHtmlContent } = require('./utils/sanitizeContent');
const { writeJsonAtomic } = require('./utils/atomicJson');

// ⚠️ DEPRECATED ROUTES - Still using MongoDB/Mongoose
// These routes need to be migrated to Sequelize for MySQL/MariaDB
// TODO: Migrate these routes to use /models-sequelize
const videosRoutes = require('./api/videosRoutes');
// const syntheseActualiteRoutes = require('./routes/syntheseActualite.routes');
// const recrutementRoutes = require('./routes/recrutement.routes');

// ✅ ACTIVE ROUTES - Express routes with caching
const youtubeRoutes = require('./api/youtube-cached');
const tweetsRoutes = require('./api/tweets-cached');
const syntheseActualiteRoutes = require('./api/syntheseActualite.routes');
const recrutementRoutes = require('./api/recrutement.routes');
const adminUsersRoutes = require('./api/admin-users.routes');
const backupRoutes = require('./api/backup.routes');
const postTranslationsRoutes = require('./api/post-translations.routes');
// Translation endpoint now set up directly below
// const translateRoutes = require('./api/translate');
// const pageContentRoutes = require('./api/page-content.routes');

// Data Sync Service
const { syncOnStartup, setupPeriodicSync } = require('./services/dataSync');

// Translation Service
const { updateLanguageVariants } = require('./services/translationService');

// Daily copy of backend/data (kept 30 days in backend/backups/data)
const { setupDailyDataBackup } = require('./services/dataBackup');

// Data Migration Service
const DataMigration = require('./services/dataMigration');

// MySQL/MariaDB Database Connection (Sequelize)
const { connectDB } = require('./config/database-mysql');
const {
    User,
    HomeContent,
    SyntheseActualite,
    Recrutement,
    LoiDecret,
    Mediatheque,
    ResourceDocument
} = require('./models-sequelize');
const app = express();
const trustProxy = process.env.TRUST_PROXY || 'loopback';
app.set('trust proxy', trustProxy);
const PORT = Number(process.env.PORT || process.env.API_PORT || (process.env.NODE_ENV === 'production' ? 8080 : 3002));
const LARGE_TEXT_LIMIT = '50mb';
const LARGE_TEXT_FIELD_LIMIT_BYTES = 50 * 1024 * 1024;
const LOGIN_2FA_TTL_MS = 5 * 60 * 1000;
const LOGIN_2FA_MAX_ATTEMPTS = 5;
const pendingLogin2FA = new Map();

const normalizeContentUrls = (payload) => {
    if (!payload || typeof payload !== 'object') return payload;

    if (payload.type === 'video' && Object.prototype.hasOwnProperty.call(payload, 'content')) {
        const embedUrl = normalizeYouTubeEmbedUrl(payload.content);
        if (!embedUrl) {
            const error = new Error('Invalid video URL. Only YouTube video URLs are allowed.');
            error.status = 400;
            throw error;
        }
        payload.content = embedUrl;
    } else if ((payload.type === 'image' || payload.type === 'poster') && typeof payload.content === 'string') {
        payload.content = normalizeImageUrl(payload.content);
    }

    if (Array.isArray(payload.images)) {
        payload.images = payload.images
            .map((image) => normalizeImageUrl(image))
            .filter(Boolean);
    }

    if (typeof payload.website === 'string') {
        payload.website = normalizeSafeUrl(payload.website);
    }

    return payload;
};

// Email configuration - Hostinger (Titan) mailbox for admin@diplomatie.td
// SMTP_HOST/SMTP_PORT/SMTP_SECURE can be overridden in .env; defaults match Hostinger's Titan Mail.
// EMAIL_PASSWORD must be the mailbox's own password (not a Gmail app password).
const EMAIL_PASSWORD = process.env.EMAIL_PASSWORD || process.env.GMAIL_APP_PASSWORD;
const transporter = nodemailer.createTransport({
    host: process.env.SMTP_HOST || 'smtp.hostinger.com',
    port: Number(process.env.SMTP_PORT || 465),
    secure: process.env.SMTP_SECURE ? process.env.SMTP_SECURE === 'true' : true, // true for port 465
    auth: EMAIL_PASSWORD ? {
        user: process.env.EMAIL_USER || 'admin@diplomatie.td',
        pass: EMAIL_PASSWORD
    } : undefined
});

// Verify email connection (silently)
transporter.verify((error, success) => {
    if (success) {
        console.log('✅ Email service configured - OTPs will be sent to admin@diplomatie.td');
    }
    // Silent on error - will still send OTPs
});

// Single shared mailbox: all account/password notifications are sent from and to this address
const MAIL_FROM = process.env.EMAIL_USER || 'admin@diplomatie.td';
const ADMIN_NOTIFY_EMAIL = process.env.ADMIN_EMAIL || 'admin@diplomatie.td';

// Middleware - Configure CORS for both development and production
// Normalize domain by removing www prefix for comparison
function normalizeDomain(origin) {
    try {
        const url = new URL(origin);
        let host = url.hostname;
        if (host.startsWith('www.')) {
            host = host.slice(4);
        }
        return `${url.protocol}//${host}`;
    } catch (e) {
        return origin;
    }
}

const corsOptions = {
    origin: function (origin, callback) {
        // Build allowed origins list
        const allowedOrigins = new Set();

        // Add localhost always
        allowedOrigins.add('http://localhost:3000');
        allowedOrigins.add('http://localhost:5173');
        allowedOrigins.add('http://localhost:3002');

        // Parse FRONTEND_URL from env
        if (process.env.FRONTEND_URL) {
            const urls = process.env.FRONTEND_URL.split(',').map(s => s.trim());
            urls.forEach(url => {
                allowedOrigins.add(url);
                // Also add www variant
                if (!url.includes('www.')) {
                    allowedOrigins.add(url.replace('://', '://www.'));
                }
            });
        }

        // Parse ALLOWED_ORIGINS from env
        if (process.env.ALLOWED_ORIGINS) {
            const urls = process.env.ALLOWED_ORIGINS.split(',').map(s => s.trim());
            urls.forEach(url => {
                allowedOrigins.add(url);
                // Also add www variant
                if (!url.includes('www.')) {
                    allowedOrigins.add(url.replace('://', '://www.'));
                }
            });
        }

        // Hostinger compatibility: allow the real site domain and its www variant explicitly.
        const hostingerDomains = ['https://diplomatie.td', 'https://www.diplomatie.td'];
        hostingerDomains.forEach(domain => allowedOrigins.add(domain));

        if (process.env.NODE_ENV === 'production') {
            // In production, strictly check origin
            if (!origin) {
                console.log('[CORS] ✅ No origin (same-site request)');
                callback(null, true);
            } else if (allowedOrigins.has(origin)) {
                console.log(`[CORS] ✅ Allowed origin: ${origin}`);
                callback(null, true);
            } else {
                // Try normalized comparison (ignore www)
                const normalizedOrigin = normalizeDomain(origin);
                const normalizedAllowed = Array.from(allowedOrigins).map(o => normalizeDomain(o));
                if (normalizedAllowed.includes(normalizedOrigin)) {
                    console.log(`[CORS] ✅ Allowed origin (normalized): ${origin}`);
                    callback(null, true);
                } else {
                    console.log('[CORS] ❌ Rejecting origin:', origin);
                    console.log('[CORS] Allowed:', Array.from(allowedOrigins));
                    callback(new Error('Not allowed by CORS'));
                }
            }
        } else {
            // Allow all origins in development
            callback(null, true);
        }
    },
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With', 'X-Admin-Secret'],
};

app.disable('x-powered-by');
app.use(helmetConfig());
app.use('/api', apiRateLimiter);
app.use(cors(corsOptions));
app.use(bodyParser.json({ limit: LARGE_TEXT_LIMIT }));
app.use(bodyParser.urlencoded({ limit: LARGE_TEXT_LIMIT, extended: true }));
// Must run AFTER body-parsing: req.body is undefined until bodyParser fills it in,
// so mounting these before bodyParser made them a no-op on every request.
app.use(mongoSanitizeConfig());
app.use(xssConfig());
app.use(cookieParser(process.env.COOKIE_SECRET));

const uploadedStaticMiddleware = express.static(path.join(__dirname, 'uploads'), uploadedStaticOptions);

// Serve static files with explicit CORS headers for images/documents
app.use('/uploads', blockDangerousUploads, (req, res, next) => {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Methods', 'GET, HEAD, OPTIONS');
    res.header('Access-Control-Allow-Headers', 'Content-Type');
    next();
}, uploadedStaticMiddleware);

// DEBUG: Log all requests
app.use((req, res, next) => {
    console.log(`[${new Date().toISOString()}] ${req.method} ${req.path}`);
    next();
});

// Configure multer for file uploads
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        const uploadDir = path.join(__dirname, 'uploads');
        if (!fs.existsSync(uploadDir)) {
            fs.mkdirSync(uploadDir, {
                recursive: true
            });
        }
        cb(null, uploadDir);
    },
    filename: (req, file, cb) => {
        cb(null, generateSafeFilename(file.originalname));
    }
});

const upload = multer({
    defParamCharset: 'utf8',
    storage: storage,
    limits: {
        fileSize: 10 * 1024 * 1024,
        fieldSize: LARGE_TEXT_FIELD_LIMIT_BYTES,
        files: 20
    },
    fileFilter: createFileFilter({
        groups: [IMAGE_MIME_EXTENSIONS],
        label: 'JPG, PNG, WebP, or GIF images'
    })
});

// Multer storage for mediatheque with dedicated folder
const mediathequeStorage = multer.diskStorage({
    destination: (req, file, cb) => {
        const uploadDir = path.join(__dirname, 'uploads', 'mediatheque');
        if (!fs.existsSync(uploadDir)) {
            fs.mkdirSync(uploadDir, {
                recursive: true
            });
        }
        cb(null, uploadDir);
    },
    filename: (req, file, cb) => {
        cb(null, generateSafeFilename(file.originalname));
    }
});

const mediathequeUpload = multer({
    defParamCharset: 'utf8',
    storage: mediathequeStorage,
    limits: {
        fileSize: 50 * 1024 * 1024
    },
    fileFilter: createFileFilter({
        groups: [IMAGE_MIME_EXTENSIONS, DOCUMENT_MIME_EXTENSIONS, VIDEO_MIME_EXTENSIONS],
        label: 'images, PDF documents, or videos'
    })
});

const pageImageStorage = multer.diskStorage({
    destination: (req, file, cb) => {
        const uploadDir = path.join(__dirname, 'uploads', 'page-images');
        if (!fs.existsSync(uploadDir)) {
            fs.mkdirSync(uploadDir, {
                recursive: true
            });
        }
        cb(null, uploadDir);
    },
    filename: (req, file, cb) => {
        const safeKey = String(req.params.key || 'page-image').replace(/[^a-z0-9-]/gi, '-').toLowerCase();
        cb(null, `${safeKey}-${generateSafeFilename(file.originalname)}`);
    }
});

const pageImageUpload = multer({
    defParamCharset: 'utf8',
    storage: pageImageStorage,
    limits: {
        fileSize: 10 * 1024 * 1024
    },
    fileFilter: createFileFilter({
        groups: [IMAGE_MIME_EXTENSIONS],
        label: 'JPG, PNG, WebP, or GIF images'
    })
});
const anciensMinistresStorage = multer.diskStorage({
    destination: (req, file, cb) => {
        const uploadDir = path.join(__dirname, 'uploads', 'anciens-ministres');
        if (!fs.existsSync(uploadDir)) {
            fs.mkdirSync(uploadDir, {
                recursive: true
            });
        }
        cb(null, uploadDir);
    },
    filename: (req, file, cb) => {
        cb(null, generateSafeFilename(file.originalname));
    }
});

const anciensMinistresUpload = multer({
    defParamCharset: 'utf8',
    storage: anciensMinistresStorage,
    limits: {
        fileSize: 10 * 1024 * 1024
    },
    fileFilter: createFileFilter({
        groups: [IMAGE_MIME_EXTENSIONS],
        label: 'JPG, PNG, WebP, or GIF images'
    })
});

// Data storage
const dataDir = path.join(__dirname, 'data');
if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir);
}

// Users storage
const usersFile = path.join(dataDir, 'users.json');
if (!fs.existsSync(usersFile)) {
    fs.writeFileSync(usersFile, JSON.stringify([]));
}

const homeContentsFile = path.join(dataDir, 'homeContents.json');
const loisDecretsFile = path.join(dataDir, 'loisDecrets.json');
const mediathequeFile = path.join(dataDir, 'mediatheque.json');
const ambassadesFile = path.join(dataDir, 'ambassades.json');
const consulatsGenerauxFile = path.join(dataDir, 'consulatsGeneraux.json');
const consulatsHonorairesFile = path.join(dataDir, 'consulatsHonoraires.json');
const pageImagesFile = path.join(dataDir, 'pageImages.json');
const anciensMinistresFile = path.join(dataDir, 'anciensMinistres.json');
const ministerContentFile = path.join(dataDir, 'ministerContent.json');

const defaultPageImages = {
    'minister-message': {
        label: 'Mot du ministre',
        url: '/images/ministre.jpg'
    },
    'cabinet': {
        label: 'Cabinets',
        url: '/images/trombinoscope/cabinet.png'
    },
    'services-exterieurs': {
        label: 'Services exterieurs',
        url: '/images/trombinoscope/services exterieurs.png'
    },
    'services-rattaches': {
        label: 'Services rattaches',
        url: '/images/trombinoscope/services rattaches.png'
    },
    'administration-centrale': {
        label: 'Administration centrale',
        url: '/images/trombinoscope/administration centrale.png'
    },
    'minister-etat': {
        label: "Ministre d'Etat",
        url: '/images/ministre_etat.jpg'
    },
    'minister-delegue': {
        label: 'Ministre delegue',
        url: '/images/ministre_deleguee.png'
    }
};

// Initialize data files if they don't exist
if (!fs.existsSync(homeContentsFile)) {
    fs.writeFileSync(homeContentsFile, JSON.stringify([]));
}
if (!fs.existsSync(loisDecretsFile)) {
    fs.writeFileSync(loisDecretsFile, JSON.stringify([]));
}
if (!fs.existsSync(mediathequeFile)) {
    fs.writeFileSync(mediathequeFile, JSON.stringify([]));
}
if (!fs.existsSync(ambassadesFile)) {
    fs.writeFileSync(ambassadesFile, JSON.stringify([]));
}
if (!fs.existsSync(consulatsGenerauxFile)) {
    fs.writeFileSync(consulatsGenerauxFile, JSON.stringify([]));
}
if (!fs.existsSync(consulatsHonorairesFile)) {
    fs.writeFileSync(consulatsHonorairesFile, JSON.stringify([]));
}
if (!fs.existsSync(pageImagesFile)) {
    fs.writeFileSync(pageImagesFile, JSON.stringify(defaultPageImages, null, 2));
}
if (!fs.existsSync(ministerContentFile)) {
    fs.writeFileSync(ministerContentFile, JSON.stringify({}));
}
// Former ministers: every photo lives in backend/uploads/anciens-ministres
const anciensMinistresUploadDir = path.join(__dirname, 'uploads', 'anciens-ministres');
const legacyAnciensImageDirs = [
    path.join(__dirname, '..', 'public', 'images', 'anciens'),
    path.join(__dirname, '..', 'dist', 'images', 'anciens'),
    // Hostinger: the Node app runs from nodejs/ and the site files live in public_html/
    path.join(__dirname, '..', 'public_html', 'images', 'anciens')
];

// Copies a historical photo (/images/anciens/N.jpg) into the backend upload folder and returns its new URL
const importLegacyAncienImage = (imageUrl) => {
    const match = /^\/images\/anciens\/([\w.-]+\.(?:jpe?g|png|webp|gif))$/i.exec(imageUrl || '');
    if (!match) return imageUrl;

    const target = path.join(anciensMinistresUploadDir, match[1]);
    if (!fs.existsSync(target)) {
        const source = legacyAnciensImageDirs.map(dir => path.join(dir, match[1])).find(file => fs.existsSync(file));
        if (!source) return imageUrl;
        fs.copyFileSync(source, target);
    }
    return `/uploads/anciens-ministres/${match[1]}`;
};

try {
    fs.mkdirSync(anciensMinistresUploadDir, { recursive: true });

    // readData is declared further down, so read the file directly here
    const existingAnciens = fs.existsSync(anciensMinistresFile) ? JSON.parse(fs.readFileSync(anciensMinistresFile, 'utf8') || 'null') : null;
    const anciensMinistres = Array.isArray(existingAnciens) ? existingAnciens : Array.from({ length: 31 }, (_, index) => {
        // Seed with the historical gallery photos (most recent first)
        const number = 31 - index;
        return {
            id: `seed-${number}`,
            name: '',
            title: '',
            startDate: '',
            endDate: '',
            image: `/images/anciens/${number}.jpg`,
            order: index
        };
    });

    let anciensChanged = !Array.isArray(existingAnciens);
    anciensMinistres.forEach((item) => {
        const imported = importLegacyAncienImage(item.image);
        if (imported !== item.image) {
            item.image = imported;
            anciensChanged = true;
        }
    });

    if (anciensChanged) {
        writeJsonAtomic(anciensMinistresFile, anciensMinistres);
        console.log('[Anciens Ministres] Photos stored in uploads/anciens-ministres');
    }
} catch (error) {
    console.error('[Anciens Ministres] Initialization failed:', error.message);
}

// Helper functions
const readData = (filePath) => {
    try {
        const data = fs.readFileSync(filePath, 'utf8');
        return JSON.parse(data);
    } catch (error) {
        console.error('Error reading data:', error);
        return [];
    }
};

const writeData = (filePath, data) => {
    try {
        writeJsonAtomic(filePath, data);
        return true;
    } catch (error) {
        console.error('Error writing data:', error);
        return false;
    }
};

const compareRepresentationsByCountry = (a, b) => {
    const countryCompare = String(a.country || '').localeCompare(String(b.country || ''), 'fr', { sensitivity: 'base' });
    if (countryCompare !== 0) return countryCompare;
    return String(a.city || '').localeCompare(String(b.city || ''), 'fr', { sensitivity: 'base' });
};

const sortRepresentationsByCountry = (items) => {
    return [...items].sort(compareRepresentationsByCountry);
};

const normalizeRepresentation = (item, index) => ({
    ...item,
    id: item.id ? String(item.id) : `${Date.now()}-${index}`,
    phones: Array.isArray(item.phones) ? item.phones : [],
    emails: Array.isArray(item.emails) ? item.emails : [],
    order: typeof item.order === 'number' ? item.order : index
});

const registerRepresentationRoutes = (routeName, filePath) => {
    app.get(`/api/${routeName}`, (req, res) => {
        res.json(sortRepresentationsByCountry(readData(filePath).map(normalizeRepresentation)));
    });

    app.post(`/api/${routeName}/bulk`, authenticateToken, requirePermission('manage_representations'), (req, res) => {
        if (!Array.isArray(req.body)) {
            return res.status(400).json({ error: 'Body must be an array' });
        }

        const items = req.body.map((item, index) => normalizeRepresentation(normalizeContentUrls(item), index));
        const sortedItems = sortRepresentationsByCountry(items).map((item, index) => ({ ...item, order: index }));
        if (writeData(filePath, sortedItems)) {
            return res.json(sortedItems);
        }

        return res.status(500).json({ error: 'Failed to save records' });
    });

    app.post(`/api/${routeName}`, authenticateToken, requirePermission('manage_representations'), (req, res) => {
        const items = readData(filePath).map(normalizeRepresentation);
        const newItem = normalizeRepresentation(normalizeContentUrls({
            ...req.body,
            id: req.body.id || Date.now().toString(),
            order: typeof req.body.order === 'number' ? req.body.order : items.length
        }), items.length);

        const nextItems = sortRepresentationsByCountry([...items, newItem]).map((item, index) => ({ ...item, order: index }));
        if (writeData(filePath, nextItems)) {
            return res.status(201).json(nextItems.find(item => String(item.id) === String(newItem.id)) || newItem);
        }

        return res.status(500).json({ error: 'Failed to create record' });
    });

    app.put(`/api/${routeName}/reorder`, authenticateToken, requirePermission('manage_representations'), (req, res) => {
        if (!Array.isArray(req.body)) {
            return res.status(400).json({ error: 'Body must be an array' });
        }

        const items = readData(filePath).map(normalizeRepresentation);
        const nextItems = sortRepresentationsByCountry(items).map((item, index) => ({ ...item, order: index }));

        if (writeData(filePath, nextItems)) {
            return res.json(nextItems);
        }

        return res.status(500).json({ error: 'Failed to reorder records' });
    });

    app.put(`/api/${routeName}/:id`, authenticateToken, requirePermission('manage_representations'), (req, res) => {
        const id = String(req.params.id);
        const items = readData(filePath).map(normalizeRepresentation);
        const existingIndex = items.findIndex(item => String(item.id) === id);
        const nextItem = normalizeRepresentation(
            normalizeContentUrls({ ...req.body, id }),
            existingIndex >= 0 ? existingIndex : items.length
        );
        const nextItems = existingIndex >= 0
            ? items.map(item => String(item.id) === id ? nextItem : item)
            : [...items, nextItem];

        const sortedItems = sortRepresentationsByCountry(nextItems).map((item, index) => ({ ...item, order: index }));
        if (writeData(filePath, sortedItems)) {
            return res.json(sortedItems.find(item => String(item.id) === id) || nextItem);
        }

        return res.status(500).json({ error: 'Failed to update record' });
    });

    app.delete(`/api/${routeName}/:id`, authenticateToken, requirePermission('manage_representations'), (req, res) => {
        const id = String(req.params.id);
        const nextItems = readData(filePath)
            .map(normalizeRepresentation)
            .filter(item => String(item.id) !== id)
            .sort(compareRepresentationsByCountry)
            .map((item, index) => ({ ...item, order: index }));

        if (writeData(filePath, nextItems)) {
            return res.json({ success: true });
        }

        return res.status(500).json({ error: 'Failed to delete record' });
    });
};

// Admin API secret for simple protection (set ADMIN_API_SECRET env var in production)
const ADMIN_API_SECRET = process.env.ADMIN_API_SECRET || 'dev-secret';

// Middleware to protect admin endpoints
const requireAdminSecret = (req, res, next) => {
    const secret = req.headers['x-admin-secret'];
    if (!secret || secret !== ADMIN_API_SECRET) {
        return res.status(403).json({
            error: 'Admin secret required'
        });
    }
    next();
};

const readPageImages = () => {
    try {
        const saved = fs.existsSync(pageImagesFile) ? JSON.parse(fs.readFileSync(pageImagesFile, 'utf8')) : {};
        return {
            ...defaultPageImages,
            ...saved
        };
    } catch (error) {
        console.error('Error reading page images:', error);
        return defaultPageImages;
    }
};

const deleteUploadedPageImage = (imageUrl) => {
    if (!imageUrl || !imageUrl.startsWith('/uploads/page-images/')) return;

    const relativePath = imageUrl.replace(/^\/uploads\//, '');
    const targetPath = path.resolve(__dirname, 'uploads', relativePath);
    const uploadRoot = path.resolve(__dirname, 'uploads', 'page-images');

    if (!targetPath.startsWith(uploadRoot + path.sep)) return;
    if (fs.existsSync(targetPath)) {
        fs.unlinkSync(targetPath);
        console.log(`[Page Images] Deleted old image: ${imageUrl}`);
    }
};

const getUploadedUrlsFromContent = (content) => {
    const urls = new Set();

    if (Array.isArray(content?.images)) {
        content.images.forEach((imageUrl) => {
            if (typeof imageUrl === 'string' && imageUrl.startsWith('/uploads/')) {
                urls.add(imageUrl);
            }
        });
    }

    if (typeof content?.content === 'string' && content.content.startsWith('/uploads/')) {
        urls.add(content.content);
    }

    return Array.from(urls);
};

const deleteUploadedFile = (fileUrl) => {
    if (!fileUrl || !fileUrl.startsWith('/uploads/')) return;

    const relativePath = fileUrl.replace(/^\/uploads\//, '');
    const targetPath = path.resolve(__dirname, 'uploads', relativePath);
    const uploadRoot = path.resolve(__dirname, 'uploads');

    if (targetPath !== uploadRoot && !targetPath.startsWith(uploadRoot + path.sep)) return;
    if (fs.existsSync(targetPath)) {
        fs.unlinkSync(targetPath);
        console.log(`[Uploads] Deleted old file: ${fileUrl}`);
    }
};

const deleteRemovedUploadedFiles = (previousUrls, nextUrls) => {
    const retainedUrls = new Set(nextUrls || []);
    previousUrls.forEach((fileUrl) => {
        if (!retainedUrls.has(fileUrl)) {
            try {
                deleteUploadedFile(fileUrl);
            } catch (err) {
                console.warn(`[Uploads] Could not delete file: ${fileUrl}`, err.message);
            }
        }
    });
};

const requirePageImageAdmin = (req, res, next) => {
    if (!req.user || (req.user.role !== 'admin' && req.user.role !== 'superadmin')) {
        return res.status(403).json({ error: 'Only the admin account can change page images' });
    }
    next();
};

const getCookieValue = (req, name) => {
    const cookieHeader = req.headers.cookie;
    if (!cookieHeader) return null;

    const cookie = cookieHeader
        .split(';')
        .map(value => value.trim())
        .find(value => value.startsWith(`${name}=`));

    return cookie ? decodeURIComponent(cookie.slice(name.length + 1)) : null;
};

const verifyPageImageToken = (token) => {
    const configuredSecrets = [
        process.env.JWT_SECRET,
        process.env.JWT_REFRESH_SECRET,
        process.env.REFRESH_TOKEN_SECRET
    ];
    const developmentFallbackSecrets = process.env.NODE_ENV === 'production' ? [] : [
        'your-secret-key-change-in-production',
        'ministere-tchad-diplomatie-secret-key-2026-prod'
    ];
    const secrets = Array.from(new Set([
        ...configuredSecrets,
        ...developmentFallbackSecrets
    ].filter(Boolean)));

    let lastError;
    for (const secret of secrets) {
        try {
            return jwt.verify(token, secret);
        } catch (error) {
            lastError = error;
        }
    }

    if (secrets.length === 0) {
        throw new Error('JWT secret is not configured');
    }

    throw lastError || new Error('Invalid token');
};

const findPageImageAdminUser = async (decoded) => {
    if (!decoded) return null;

    try {
        const where = decoded.email ? { email: decoded.email } : null;
        const dbUser = decoded.id
            ? await User.findByPk(decoded.id)
            : where
                ? await User.findOne({ where })
                : null;

        if (dbUser) {
            const plainUser = dbUser.toJSON ? dbUser.toJSON() : dbUser;
            if (
                plainUser.status === 'active' &&
                (plainUser.role === 'admin' || plainUser.role === 'superadmin')
            ) {
                return plainUser;
            }
        }
    } catch (error) {
        console.warn(`[Page Images] DB admin validation failed: ${error.message}`);
    }

    try {
        const users = fs.existsSync(usersFile) ? JSON.parse(fs.readFileSync(usersFile, 'utf8') || '[]') : [];
        return users.find(user =>
            (String(user.id) === String(decoded.id) ||
                String(user.email || '').toLowerCase() === String(decoded.email || '').toLowerCase()) &&
            user.status === 'active' &&
            (user.role === 'admin' || user.role === 'superadmin')
        ) || null;
    } catch (error) {
        console.warn(`[Page Images] JSON admin validation failed: ${error.message}`);
        return null;
    }
};

const authenticatePageImageAdmin = async (req, res, next) => {
    try {
        const authHeader = req.headers.authorization || '';
        const bearerToken = authHeader.startsWith('Bearer ') ? authHeader.slice(7) : null;
        const token = bearerToken || getCookieValue(req, 'refreshToken');

        if (!token) {
            return res.status(401).json({ error: 'Access token required' });
        }

        const decoded = verifyPageImageToken(token);
        const sessionCheck = sessionService.validateSession(decoded.id, decoded.sid);
        if (!sessionCheck.valid) {
            return res.status(401).json({ error: 'Session expired or already active elsewhere' });
        }

        const adminUser = await findPageImageAdminUser(decoded);

        if (!adminUser) {
            return res.status(401).json({ error: 'Admin session not recognized' });
        }

        req.user = {
            id: adminUser.id,
            email: adminUser.email,
            role: adminUser.role,
            name: adminUser.name,
            status: adminUser.status
        };
        next();
    } catch (error) {
        console.error('[Page Images] Authentication failed:', error.message);
        return res.status(401).json({ error: 'Invalid or expired token', details: error.message });
    }
};

// ====== VIDEO MANAGEMENT ROUTES (data/videos.json) ======
app.use('/api/videos', videosRoutes);

// ====== SYNTHESE ACTUALITE ROUTES ======
console.log('[Server] Mounting synthese-actualite routes at /api/synthese-actualite');

// Add specific logging middleware for synthese-actualite
app.use('/api/synthese-actualite', (req, res, next) => {
    console.log('[Server Middleware] Synthese route accessed:', req.method, req.path);
    next();
});

app.use('/api/synthese-actualite', syntheseActualiteRoutes);
console.log('[Server] ✅ Synthese-actualite routes mounted successfully');

// ====== TWEETS ROUTES (CACHED) ======
console.log('[Server] Mounting tweets routes at /api/tweets');
app.use('/api/tweets', tweetsRoutes);
console.log('[Server] Tweets routes mounted successfully');

// ====== RECRUITMENT POSTS ROUTES ======
console.log('[Server] Mounting recruitment routes at /api/recrutement-posts');

// DEBUG: Log all requests to recruitment endpoint BEFORE mounting routes
app.use('/api/recrutement-posts', (req, res, next) => {
    console.log(`\n[SERVER MIDDLEWARE] Recruitment request: ${req.method} ${req.path} ${req.url}`);
    console.log('[SERVER MIDDLEWARE] Authorization header:', req.headers.authorization ? 'Present' : 'Missing');
    next();
});

app.use('/api/recrutement-posts', recrutementRoutes);
console.log('[Server] ✅ Recruitment routes mounted successfully');

// ====== ADMIN BACKUP/EXPORT ROUTES ======
console.log('[Server] Mounting backup routes at /api/admin/backup');
app.use('/api/admin/backup', backupRoutes);
console.log('[Server] ✅ Backup routes mounted successfully');

// ✅ HEALTH CHECK ENDPOINT - Test if server is running
app.get('/api/health', (req, res) => {
    res.json({
        status: 'ok',
        timestamp: new Date().toISOString(),
        port: PORT,
        environment: process.env.NODE_ENV,
        frontend: process.env.FRONTEND_URL
    });
});

// TEST ENDPOINT: Simple POST, protected so it cannot be abused on deployed hosts.
app.post('/api/test-post', authenticatePageImageAdmin, (req, res) => {
    console.log('[TEST POST] Request received');
    res.json({
        success: true,
        message: 'TEST_POST_WORKS'
    });
});

// ✅ ACTIVE EXPRESS ROUTES
// ====== YOUTUBE ROUTES ======
console.log('[Server] 📺 Mounting YouTube routes at /api/youtube');
app.post('/api/contact-message', contactRateLimiter, async (req, res) => {
    try {
        const { name, email, phone, subject, message } = req.body;

        if (!name || !email || !phone || !subject || !message) {
            return res.status(400).json({ error: 'All contact fields are required' });
        }

        const escapeHtml = (value) => String(value)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#039;');

        const mailOptions = {
            from: `"MAE Contact" <${MAIL_FROM}>`,
            to: ADMIN_NOTIFY_EMAIL,
            replyTo: email,
            subject: `Message du site - ${subject}`,
            text: [
                'Nouveau message depuis le site web du MAE',
                '',
                `Nom: ${name}`,
                `Email: ${email}`,
                `Telephone: ${phone}`,
                `Sujet: ${subject}`,
                '',
                'Message:',
                message
            ].join('\n'),
            html: `
                <div style="font-family: Arial, sans-serif; line-height: 1.6; color: #1f2937;">
                    <h2 style="color: #002D72;">Nouveau message depuis le site web du MAE</h2>
                    <p><strong>Nom:</strong> ${escapeHtml(name)}</p>
                    <p><strong>Email:</strong> ${escapeHtml(email)}</p>
                    <p><strong>Téléphone:</strong> ${escapeHtml(phone)}</p>
                    <p><strong>Sujet:</strong> ${escapeHtml(subject)}</p>
                    <div style="margin-top: 20px; padding: 16px; border-left: 4px solid #002D72; background: #f8fafc;">
                        <strong>Message:</strong>
                        <p style="white-space: pre-wrap;">${escapeHtml(message)}</p>
                    </div>
                </div>
            `
        };

        await transporter.sendMail(mailOptions);

        res.json({ success: true, message: 'Message sent successfully' });
    } catch (error) {
        console.error('Error sending contact message:', error.message);
        res.status(500).json({ error: 'Failed to send contact message' });
    }
});

app.use('/api/youtube', youtubeRoutes);
console.log('[Server] ✅ YouTube routes mounted successfully');

// ====== ADMIN USERS MANAGEMENT ROUTES ======
console.log('[Server] 👥 Mounting admin users routes at /api/admin/users');
app.use('/api/admin/users', adminUsersRoutes);
console.log('[Server] ✅ Admin users routes mounted successfully');

// ====== POST TRANSLATIONS ROUTES ======
console.log('[Server] 🌐 Mounting post translations routes at /api/post-translations');
app.use('/api/post-translations', postTranslationsRoutes);
console.log('[Server] ✅ Post translations routes mounted successfully');

// ====== SIMPLE TRANSLATION ENDPOINT ======
console.log('[Server] 🌍 Mounting translation endpoint at /api/translate');
require('./api/simple-translate')(app);
console.log('[Server] ✅ Translation endpoint mounted successfully');

// ====== PAGE CONTENT MANAGEMENT ROUTES - DISABLED ======
// Page content editor has been removed from the admin panel
// Uncomment below to re-enable
// console.log('[Server] 📄 Mounting page content routes at /api/page-content');
// app.use('/api/page-content', pageContentRoutes);
// console.log('[Server] ✅ Page content routes mounted successfully');

// ====== GENERIC FILE UPLOAD ENDPOINT ======
app.get('/api/page-images', (req, res) => {
    res.json(readPageImages());
});

app.post('/api/page-images/:key', authenticatePageImageAdmin, pageImageUpload.single('file'), (req, res) => {
    try {
        const key = String(req.params.key || '');
        const defaults = defaultPageImages[key];

        if (!defaults) {
            if (req.file) {
                fs.unlinkSync(req.file.path);
            }
            return res.status(404).json({ error: 'Unknown page image key' });
        }

        if (!req.file) {
            return res.status(400).json({ error: 'No image file provided' });
        }

        const pageImages = readPageImages();
        const previousUrl = pageImages[key]?.url;
        const nextItem = {
            ...defaults,
            ...pageImages[key],
            url: `/uploads/page-images/${req.file.filename}`,
            updatedAt: new Date().toISOString()
        };

        pageImages[key] = nextItem;

        if (!writeData(pageImagesFile, pageImages)) {
            deleteUploadedPageImage(nextItem.url);
            return res.status(500).json({ error: 'Failed to save page image' });
        }

        deleteUploadedPageImage(previousUrl);
        res.json({ key, image: nextItem, images: pageImages });
    } catch (error) {
        console.error('[Page Images] Upload error:', error);
        if (req.file?.path && fs.existsSync(req.file.path)) {
            fs.unlinkSync(req.file.path);
        }
        res.status(500).json({ error: 'Failed to update page image' });
    }
});

app.post('/api/upload', authenticateToken, requirePermission('edit_home_content'), upload.single('file'), (req, res) => {
    try {
        if (!req.file) {
            return res.status(400).json({ error: 'No file provided' });
        }
        const filePath = `/uploads/${req.file.filename}`;
        res.json({
            success: true,
            url: filePath,
            filePath: filePath,
            filename: req.file.filename
        });
    } catch (error) {
        console.error('[Upload] Error:', error);
        res.status(500).json({ error: 'Upload failed' });
    }
});

// ====== MINISTER CONTENT ROUTES (Mot du Ministre, Ministre d'Etat, Ministre delegue) ======
const MINISTER_CONTENT_KEYS = ['minister-message', 'minister-etat', 'minister-delegue'];
const MINISTER_CONTENT_LANGUAGES = ['fr', 'en', 'ar'];
const MINISTER_CONTENT_TEXT_FIELDS = [
    'title', 'subtitle', 'greeting', 'closing', 'name', 'position',
    'headerBadge', 'headerTitle', 'headerSubtitle',
    'badge', 'quote', 'highlightTitle', 'highlightText', 'bioHeading', 'fullTitle',
    'presentationTitle', 'formationTitle', 'experienceTitle', 'engagementsTitle'
];
const MINISTER_CONTENT_LIST_FIELDS = ['paragraphs', 'presentation'];
const MINISTER_CONTENT_ITEM_FIELDS = {
    formationItems: ['label', 'detail'],
    experienceItems: ['label', 'detail'],
    engagementsItems: ['label', 'detail'],
    timeline: ['year', 'title', 'description']
};

// Plain text only (React escapes on render); newlines are kept for multi-line fields
const cleanMinisterText = (value, maxLength = 5000) => String(typeof value === 'string' ? value : '')
    .replace(/<[^>]*>/g, '')
    .replace(/\r\n/g, '\n')
    .trim()
    .slice(0, maxLength);

const buildMinisterContent = (body = {}) => {
    const content = {};

    MINISTER_CONTENT_TEXT_FIELDS.forEach((field) => {
        if (typeof body[field] === 'string') content[field] = cleanMinisterText(body[field]);
    });

    MINISTER_CONTENT_LIST_FIELDS.forEach((field) => {
        if (Array.isArray(body[field])) {
            content[field] = body[field].slice(0, 50).map(item => cleanMinisterText(item)).filter(Boolean);
        }
    });

    Object.entries(MINISTER_CONTENT_ITEM_FIELDS).forEach(([field, keys]) => {
        if (Array.isArray(body[field])) {
            content[field] = body[field]
                .slice(0, 50)
                .filter(item => item && typeof item === 'object')
                .map(item => Object.fromEntries(keys.map(key => [key, cleanMinisterText(item[key], 1000)])))
                .filter(item => keys.some(key => item[key]));
        }
    });

    return content;
};

const readMinisterContent = () => {
    const data = readData(ministerContentFile);
    return data && typeof data === 'object' && !Array.isArray(data) ? data : {};
};

const validateMinisterContentParams = (req, res) => {
    const { key, lang } = req.params;
    if (!MINISTER_CONTENT_KEYS.includes(key) || !MINISTER_CONTENT_LANGUAGES.includes(lang)) {
        res.status(404).json({ error: 'Unknown page or language' });
        return false;
    }
    return true;
};

app.get('/api/minister-content', (req, res) => {
    res.json(readMinisterContent());
});

app.put('/api/minister-content/:key/:lang', authenticatePageImageAdmin, (req, res) => {
    if (!validateMinisterContentParams(req, res)) return;

    const { key, lang } = req.params;
    const data = readMinisterContent();
    data[key] = {
        ...(data[key] || {}),
        [lang]: { ...buildMinisterContent(req.body), updatedAt: new Date().toISOString() }
    };

    if (!writeData(ministerContentFile, data)) {
        return res.status(500).json({ error: 'Failed to save content' });
    }

    res.json(data);
});

// Translate a saved page/language into the other languages and save the results
const { translateUnlimited } = require('./api/simple-translate');

const translateMinisterValue = async (value, source, target) => {
    if (typeof value === 'string') {
        return value.trim() ? translateUnlimited(value, source, target) : value;
    }
    if (Array.isArray(value)) {
        const results = [];
        for (const item of value) results.push(await translateMinisterValue(item, source, target));
        return results;
    }
    if (value && typeof value === 'object') {
        const entries = await Promise.all(Object.entries(value).map(async ([key, inner]) => [key, await translateMinisterValue(inner, source, target)]));
        return Object.fromEntries(entries);
    }
    return value;
};

// Fields are translated a few at a time: fast enough for long texts without flooding the translation service
const translateMinisterContent = async (content, source, target) => {
    const fields = Object.keys(content);
    const translated = {};
    for (let i = 0; i < fields.length; i += 4) {
        const batch = fields.slice(i, i + 4);
        const values = await Promise.all(batch.map(field => translateMinisterValue(content[field], source, target)));
        batch.forEach((field, index) => { translated[field] = values[index]; });
    }
    return translated;
};

app.post('/api/minister-content/:key/:lang/translate', authenticatePageImageAdmin, async (req, res) => {
    if (!validateMinisterContentParams(req, res)) return;

    const { key, lang } = req.params;
    const source = buildMinisterContent(req.body);
    const targets = MINISTER_CONTENT_LANGUAGES.filter(language => language !== lang);

    try {
        const results = await Promise.all(targets.map(target => translateMinisterContent(source, lang, target)));

        const data = readMinisterContent();
        data[key] = { ...(data[key] || {}) };
        targets.forEach((target, index) => {
            data[key][target] = {
                ...buildMinisterContent(results[index]),
                autoTranslatedFrom: lang,
                updatedAt: new Date().toISOString()
            };
        });

        if (!writeData(ministerContentFile, data)) {
            return res.status(500).json({ error: 'Failed to save translations' });
        }

        res.json(data);
    } catch (error) {
        console.error('[Minister Content] Translation failed:', error.message);
        res.status(502).json({ error: 'Le service de traduction ne repond pas. Reessayez dans quelques minutes.' });
    }
});

// Reset a page/language back to the built-in default texts
app.delete('/api/minister-content/:key/:lang', authenticatePageImageAdmin, (req, res) => {
    if (!validateMinisterContentParams(req, res)) return;

    const { key, lang } = req.params;
    const data = readMinisterContent();
    if (data[key]) {
        delete data[key][lang];
        if (Object.keys(data[key]).length === 0) delete data[key];
    }

    if (!writeData(ministerContentFile, data)) {
        return res.status(500).json({ error: 'Failed to reset content' });
    }

    res.json(data);
});

// ====== ANCIENS MINISTRES ROUTES ======
const ANCIEN_MINISTRE_DATE_PATTERN = /^\d{4}(-\d{2}(-\d{2})?)?$/;

const normalizeAncienMinistreDate = (value) => {
    const text = typeof value === 'string' ? value.trim() : '';
    return ANCIEN_MINISTRE_DATE_PATTERN.test(text) ? text : '';
};

const readAnciensMinistres = () => {
    const items = readData(anciensMinistresFile);
    return (Array.isArray(items) ? items : [])
        .map((item, index) => ({ ...item, order: typeof item.order === 'number' ? item.order : index }))
        .sort((a, b) => a.order - b.order);
};

const writeAnciensMinistres = (items) => writeData(
    anciensMinistresFile,
    items.map((item, index) => ({ ...item, order: index }))
);

const buildAncienMinistreFields = (body = {}) => ({
    name: sanitizeText(String(body.name || '')).trim().slice(0, 200),
    title: sanitizeText(String(body.title || '')).trim().slice(0, 300),
    startDate: normalizeAncienMinistreDate(body.startDate),
    endDate: normalizeAncienMinistreDate(body.endDate)
});

const removeUploadedRequestFile = (req) => {
    if (req.file?.path && fs.existsSync(req.file.path)) {
        fs.unlinkSync(req.file.path);
    }
};

app.get('/api/anciens-ministres', (req, res) => {
    res.json(readAnciensMinistres());
});

app.post('/api/anciens-ministres', authenticatePageImageAdmin, anciensMinistresUpload.single('file'), (req, res) => {
    try {
        if (!req.file) {
            return res.status(400).json({ error: 'No image file provided' });
        }

        const fields = buildAncienMinistreFields(req.body);
        if (fields.startDate && fields.endDate && fields.startDate > fields.endDate) {
            removeUploadedRequestFile(req);
            return res.status(400).json({ error: 'La date de debut doit preceder la date de fin' });
        }

        const newItem = {
            id: Date.now().toString(),
            ...fields,
            image: `/uploads/anciens-ministres/${req.file.filename}`,
            createdAt: new Date().toISOString()
        };

        // The most recent former minister is shown first
        const nextItems = [newItem, ...readAnciensMinistres()];
        if (!writeAnciensMinistres(nextItems)) {
            removeUploadedRequestFile(req);
            return res.status(500).json({ error: 'Failed to create record' });
        }

        res.status(201).json(readAnciensMinistres());
    } catch (error) {
        console.error('[Anciens Ministres] Create error:', error);
        removeUploadedRequestFile(req);
        res.status(500).json({ error: 'Failed to create record' });
    }
});

app.put('/api/anciens-ministres/reorder', authenticatePageImageAdmin, (req, res) => {
    if (!Array.isArray(req.body)) {
        return res.status(400).json({ error: 'Body must be an array of ids' });
    }

    const items = readAnciensMinistres();
    const position = new Map(req.body.map((id, index) => [String(id), index]));
    const nextItems = [...items].sort((a, b) =>
        (position.get(String(a.id)) ?? items.length + a.order) - (position.get(String(b.id)) ?? items.length + b.order)
    );

    if (writeAnciensMinistres(nextItems)) {
        return res.json(readAnciensMinistres());
    }

    res.status(500).json({ error: 'Failed to reorder records' });
});

app.put('/api/anciens-ministres/:id', authenticatePageImageAdmin, anciensMinistresUpload.single('file'), (req, res) => {
    try {
        const id = String(req.params.id);
        const items = readAnciensMinistres();
        const existing = items.find(item => String(item.id) === id);

        if (!existing) {
            removeUploadedRequestFile(req);
            return res.status(404).json({ error: 'Record not found' });
        }

        const fields = buildAncienMinistreFields(req.body);
        if (fields.startDate && fields.endDate && fields.startDate > fields.endDate) {
            removeUploadedRequestFile(req);
            return res.status(400).json({ error: 'La date de debut doit preceder la date de fin' });
        }

        const updated = {
            ...existing,
            ...fields,
            image: req.file ? `/uploads/anciens-ministres/${req.file.filename}` : existing.image,
            updatedAt: new Date().toISOString()
        };

        if (!writeAnciensMinistres(items.map(item => String(item.id) === id ? updated : item))) {
            removeUploadedRequestFile(req);
            return res.status(500).json({ error: 'Failed to update record' });
        }

        if (req.file) {
            deleteUploadedFile(existing.image);
        }

        res.json(readAnciensMinistres());
    } catch (error) {
        console.error('[Anciens Ministres] Update error:', error);
        removeUploadedRequestFile(req);
        res.status(500).json({ error: 'Failed to update record' });
    }
});

app.delete('/api/anciens-ministres/:id', authenticatePageImageAdmin, (req, res) => {
    const id = String(req.params.id);
    const items = readAnciensMinistres();
    const existing = items.find(item => String(item.id) === id);

    if (!existing) {
        return res.status(404).json({ error: 'Record not found' });
    }

    if (!writeAnciensMinistres(items.filter(item => String(item.id) !== id))) {
        return res.status(500).json({ error: 'Failed to delete record' });
    }

    deleteUploadedFile(existing.image);
    res.json(readAnciensMinistres());
});

// Routes for Home Contents
registerRepresentationRoutes('ambassades', ambassadesFile);
registerRepresentationRoutes('consulats-generaux', consulatsGenerauxFile);
registerRepresentationRoutes('consulats-honoraires', consulatsHonorairesFile);

const HOME_CONTENTS_LIMIT = 40;

// Sort comparator shared between display order and cap enforcement:
// manual order first (if set), then newest publishDate, then newest id
function compareHomeContents(a, b) {
    if (a.order !== undefined && b.order !== undefined) return a.order - b.order;
    if (a.order !== undefined) return -1;
    if (b.order !== undefined) return 1;
    const dateA = a.publishDate ? new Date(a.publishDate).getTime() : 0;
    const dateB = b.publishDate ? new Date(b.publishDate).getTime() : 0;
    if (dateB !== dateA) return dateB - dateA;
    return Number(b.id) - Number(a.id);
}

function deleteHomeContentImageFiles(content) {
    if (content.images && Array.isArray(content.images)) {
        for (const imageUrl of content.images) {
            if (imageUrl && imageUrl.startsWith('/uploads/')) {
                try {
                    const filePath = path.join(__dirname, imageUrl);
                    if (fs.existsSync(filePath)) {
                        fs.unlinkSync(filePath);
                        console.log(`[HOME-CONTENTS] ✓ Deleted file: ${imageUrl}`);
                    }
                } catch (err) {
                    console.warn(`[HOME-CONTENTS] Could not delete file: ${imageUrl}`, err.message);
                }
            }
        }
    } else if (content.content && content.content.startsWith('/uploads/')) {
        try {
            const filePath = path.join(__dirname, content.content);
            if (fs.existsSync(filePath)) {
                fs.unlinkSync(filePath);
                console.log(`[HOME-CONTENTS] ✓ Deleted file: ${content.content}`);
            }
        } catch (err) {
            console.warn(`[HOME-CONTENTS] Could not delete file: ${content.content}`, err.message);
        }
    }
}

app.get('/api/home-contents', (req, res) => {
    try {
        let contents = readData(homeContentsFile);

        // Sort: manual order first (if set), then newest publishDate, then newest id
        contents.sort(compareHomeContents);
        res.json(contents);
    } catch (error) {
        console.error('[Home Contents] Error fetching:', error);
        res.status(500).json({ error: 'Failed to fetch home contents' });
    }
});

app.post('/api/home-contents/reorder', authenticateToken, requirePermission('edit_home_content'), (req, res) => {
    const { orderedIds } = req.body;
    if (!Array.isArray(orderedIds)) {
        return res.status(400).json({ error: 'orderedIds must be an array' });
    }
    const contents = readData(homeContentsFile);
    const contentMap = {};
    contents.forEach(c => { contentMap[c.id] = c; });
    const reordered = orderedIds
        .filter(id => contentMap[id])
        .map((id, index) => ({ ...contentMap[id], order: index }));
    const missing = contents
        .filter(c => !orderedIds.includes(c.id))
        .map((c, i) => ({ ...c, order: reordered.length + i }));
    if (writeData(homeContentsFile, [...reordered, ...missing])) {
        res.json({ success: true });
    } else {
        res.status(500).json({ error: 'Failed to save order' });
    }
});

function mergeLanguageVariantsByField(autoVariants = [], userVariants = [], preferAutoFields = false) {
    const languages = new Set([
        ...autoVariants.map(variant => variant.language),
        ...userVariants.map(variant => variant.language)
    ]);

    return Array.from(languages).map(language => {
        const autoVariant = autoVariants.find(variant => variant.language === language) || {};
        const userVariant = userVariants.find(variant => variant.language === language) || {};

        return {
            ...autoVariant,
            ...userVariant,
            language,
            title: preferAutoFields ? (autoVariant.title || userVariant.title || '') : (userVariant.title || autoVariant.title || ''),
            description: preferAutoFields ? (autoVariant.description || userVariant.description || '') : (userVariant.description || autoVariant.description || ''),
            content: preferAutoFields ? (autoVariant.content || userVariant.content || '') : (userVariant.content || autoVariant.content || '')
        };
    });
}

app.post('/api/home-contents', authenticateToken, requirePermission('edit_home_content'), upload.array('file'), mongoSanitizeConfig(), xssConfig(), async (req, res) => {
    const newContent = req.body;

    // Parse JSON fields that might be strings
    if (typeof newContent.active === 'string') {
        newContent.active = newContent.active === 'true';
    }

    // Parse languageVariants if it's a JSON string
    if (typeof newContent.languageVariants === 'string') {
        try {
            newContent.languageVariants = JSON.parse(newContent.languageVariants);
        } catch (e) {
            console.warn('Failed to parse languageVariants:', e.message);
            newContent.languageVariants = [];
        }
    }

    // Handle multiple file uploads
    if (req.files && req.files.length > 0) {
        const imageUrls = req.files.map(file => `/uploads/${file.filename}`);
        newContent.images = imageUrls;
        // For backward compatibility, set content to first image
        newContent.content = imageUrls[0];
    }

    try {
        normalizeContentUrls(newContent);
    } catch (error) {
        return res.status(error.status || 400).json({ error: error.message });
    }

    if (typeof newContent.title === 'string') {
        newContent.title = sanitizeText(newContent.title);
    }
    if (typeof newContent.description === 'string') {
        newContent.description = sanitizeHtmlContent(newContent.description);
    }

    let contents = readData(homeContentsFile);
    newContent.id = Date.now().toString();

    // Preserve user-provided translations from frontend (instant translate buttons)
    const userProvidedVariants = newContent.languageVariants || [];

    // Automatically translate missing languages only
    try {
        const autoVariants = await updateLanguageVariants(newContent, userProvidedVariants);
        // Merge field-by-field so manual title/description does not block auto-translated content.
        newContent.languageVariants = mergeLanguageVariantsByField(autoVariants, userProvidedVariants, true);
        console.log('✅ Home content translated (user-provided + auto-translated missing languages)');
    } catch (error) {
        console.warn('⚠️  Auto-translation failed, but content will be created:', error.message);
        newContent.languageVariants = userProvidedVariants;
    }

    contents.push(newContent);

    // Cap at HOME_CONTENTS_LIMIT posts: adding one more removes the oldest (and its images).
    // The new post is never the one removed (it used to be, once posts had been reordered).
    const { kept, removed } = enforcePostLimit(contents, HOME_CONTENTS_LIMIT, newContent.id);
    contents = kept;

    if (writeData(homeContentsFile, contents)) {
        removed.forEach(deleteHomeContentImageFiles);
        res.setHeader('X-Removed-Old-Posts', String(removed.length));
        res.status(201).json(newContent);
    } else {
        res.status(500).json({
            error: 'Failed to save content'
        });
    }
});

app.put('/api/home-contents/:id', authenticateToken, requirePermission('edit_home_content'), upload.array('file'), mongoSanitizeConfig(), xssConfig(), async (req, res) => {
    const { id } = req.params;
    const updatedContent = req.body;
    const contents = readData(homeContentsFile);
    const index = contents.findIndex(c => c.id === id);

    if (index !== -1) {
        const existingContent = contents[index];
        const previousUploadUrls = getUploadedUrlsFromContent(existingContent);
        const hasNewFiles = Boolean(req.files && req.files.length > 0);

        // Parse languageVariants if it's a JSON string
        if (typeof updatedContent.languageVariants === 'string') {
            try {
                updatedContent.languageVariants = JSON.parse(updatedContent.languageVariants);
            } catch (e) {
                console.warn('Failed to parse languageVariants:', e.message);
                updatedContent.languageVariants = undefined;
            }
        }

        // Parse active flag if it's a string
        if (typeof updatedContent.active === 'string') {
            updatedContent.active = updatedContent.active === 'true';
        }

        // Handle file uploads - a new selection replaces the previous gallery.
        if (hasNewFiles) {
            const imageUrls = req.files.map(file => `/uploads/${file.filename}`);
            updatedContent.images = imageUrls;
            // For backward compatibility, set content to first image
            updatedContent.content = imageUrls[0];
        }

        // Handle existing images reordering only when no new files were uploaded.
        if (!hasNewFiles && typeof updatedContent.existingImages === 'string') {
            try {
                updatedContent.images = JSON.parse(updatedContent.existingImages);
            } catch (e) {
                console.warn('Failed to parse existingImages:', e.message);
            }
        }

        if (!hasNewFiles && Array.isArray(updatedContent.images) && updatedContent.images.length > 0) {
            updatedContent.content = updatedContent.images[0];
        }

        try {
            normalizeContentUrls(updatedContent);
        } catch (error) {
            return res.status(error.status || 400).json({ error: error.message });
        }

        if (typeof updatedContent.title === 'string') {
            updatedContent.title = sanitizeText(updatedContent.title);
        }
        if (typeof updatedContent.description === 'string') {
            updatedContent.description = sanitizeHtmlContent(updatedContent.description);
        }

        // Merge with existing content, preserving fields not being updated
        const mergedContent = {
            ...existingContent,
            ...updatedContent
        };

        // Re-translate if title, description, or text content changed
        const titleChanged = updatedContent.title !== undefined && updatedContent.title !== existingContent.title;
        const descriptionChanged = updatedContent.description !== undefined && updatedContent.description !== existingContent.description;
        const contentChanged = updatedContent.content !== undefined && updatedContent.content !== existingContent.content;

        if (titleChanged || descriptionChanged || contentChanged) {
            try {
                // Preserve user-provided translations (from instant translate buttons)
                const userProvidedVariants = updatedContent.languageVariants || mergedContent.languageVariants || [];
                const autoVariants = await updateLanguageVariants(mergedContent, userProvidedVariants);
                // Merge field-by-field so existing/manual fields do not block newly translated content.
                mergedContent.languageVariants = mergeLanguageVariantsByField(autoVariants, userProvidedVariants, true);
                console.log('✅ Home content translations updated (user-provided + auto-translated)');
            } catch (error) {
                console.warn('⚠️  Auto-translation update failed:', error.message);
            }
        }

        contents[index] = mergedContent;

        if (writeData(homeContentsFile, contents)) {
            deleteRemovedUploadedFiles(previousUploadUrls, getUploadedUrlsFromContent(mergedContent));
            res.json(mergedContent);
        } else {
            deleteRemovedUploadedFiles(getUploadedUrlsFromContent(updatedContent), previousUploadUrls);
            res.status(500).json({
                error: 'Failed to update content'
            });
        }
    } else {
        res.status(404).json({
            error: 'Content not found'
        });
    }
});

app.delete('/api/home-contents/:id', authenticateToken, requirePermission('edit_home_content'), (req, res) => {
    const {
        id
    } = req.params;
    const contents = readData(homeContentsFile);
    const contentToDelete = contents.find(c => c.id === id);

    if (!contentToDelete) {
        return res.status(404).json({ error: 'Content not found' });
    }

    // Delete all associated image files
    deleteHomeContentImageFiles(contentToDelete);

    const filteredContents = contents.filter(c => c.id !== id);
    if (writeData(homeContentsFile, filteredContents)) {
        res.status(204).send();
    } else {
        res.status(500).json({
            error: 'Failed to delete content'
        });
    }
});

// Routes for Lois et Decrets
app.get('/api/lois-decrets', (req, res) => {
    const lois = readData(loisDecretsFile);
    res.json(lois);
});

app.post('/api/lois-decrets', authenticateToken, requirePermission('edit_all_text'), (req, res) => {
    const newLoi = req.body;
    const lois = readData(loisDecretsFile);
    newLoi.id = Date.now().toString();
    lois.push(newLoi);
    if (writeData(loisDecretsFile, lois)) {
        res.status(201).json(newLoi);
    } else {
        res.status(500).json({
            error: 'Failed to save loi'
        });
    }
});

app.put('/api/lois-decrets/:id', authenticateToken, requirePermission('edit_all_text'), (req, res) => {
    const {
        id
    } = req.params;
    const updatedLoi = req.body;
    const lois = readData(loisDecretsFile);
    const index = lois.findIndex(l => l.id === id);
    if (index !== -1) {
        lois[index] = {
            ...lois[index],
            ...updatedLoi
        };
        if (writeData(loisDecretsFile, lois)) {
            res.json(lois[index]);
        } else {
            res.status(500).json({
                error: 'Failed to update loi'
            });
        }
    } else {
        res.status(404).json({
            error: 'Loi not found'
        });
    }
});

app.delete('/api/lois-decrets/:id', authenticateToken, requirePermission('edit_all_text'), (req, res) => {
    const {
        id
    } = req.params;
    const lois = readData(loisDecretsFile);
    const filteredLois = lois.filter(l => l.id !== id);
    if (writeData(loisDecretsFile, filteredLois)) {
        res.status(204).send();
    } else {
        res.status(500).json({
            error: 'Failed to delete loi'
        });
    }
});

// Routes for Mediatheque
app.get('/api/mediatheque', (req, res) => {
    const mediatheque = readData(mediathequeFile);
    res.json(mediatheque);
});

app.post('/api/mediatheque', authenticateToken, requirePermission('mediatheque'), mediathequeUpload.single('file'), (req, res) => {
    const {
        type,
        title,
        description,
        category
    } = req.body;

    if (!req.file || !type || !title) {
        return res.status(400).json({
            error: 'Missing required fields'
        });
    }

    const mediaItem = {
        id: Date.now().toString(),
        type: type,
        title: title,
        description: description || '',
        category: category || 'Général',
        filename: req.file.filename,
        url: `/uploads/mediatheque/${req.file.filename}`,
        uploadDate: new Date().toISOString(),
        size: (req.file.size / 1024).toFixed(2) + ' KB'
    };

    const mediatheque = readData(mediathequeFile);
    mediatheque.push(mediaItem);

    if (writeData(mediathequeFile, mediatheque)) {
        res.status(201).json(mediaItem);
    } else {
        res.status(500).json({
            error: 'Failed to save media'
        });
    }
});

app.put('/api/mediatheque/:id', authenticateToken, requirePermission('mediatheque'), (req, res) => {
    const {
        id
    } = req.params;
    const updatedMedia = req.body;
    const mediatheque = readData(mediathequeFile);
    const index = mediatheque.findIndex(m => m.id === id);

    if (index !== -1) {
        mediatheque[index] = {
            ...mediatheque[index],
            ...updatedMedia
        };
        if (writeData(mediathequeFile, mediatheque)) {
            res.json(mediatheque[index]);
        } else {
            res.status(500).json({
                error: 'Failed to update media'
            });
        }
    } else {
        res.status(404).json({
            error: 'Media not found'
        });
    }
});

app.delete('/api/mediatheque/:id', authenticateToken, requirePermission('mediatheque'), (req, res) => {
    const {
        id
    } = req.params;
    const mediatheque = readData(mediathequeFile);
    const media = mediatheque.find(m => m.id === id);

    if (!media) {
        return res.status(404).json({
            error: 'Media not found'
        });
    }

    // Delete file from disk
    if (media.url) {
        const filePath = path.join(__dirname, 'uploads', 'mediatheque', media.filename);
        if (fs.existsSync(filePath)) {
            fs.unlinkSync(filePath);
        }
    }

    const filteredMediatheque = mediatheque.filter(m => m.id !== id);
    if (writeData(mediathequeFile, filteredMediatheque)) {
        res.status(204).send();
    } else {
        res.status(500).json({
            error: 'Failed to delete media'
        });
    }
});

// Resource Documents endpoints
const resourceDocumentsFile = path.join(dataDir, 'resourceDocuments.json');

// Initialize resource documents file if it doesn't exist
if (!fs.existsSync(resourceDocumentsFile)) {
    fs.writeFileSync(resourceDocumentsFile, JSON.stringify([]));
}

// Category to folder mapping
const categoryFolderMap = {
    'Organisations Internationales': 'organisations-internationales',
    'organisations-internationales': 'organisations-internationales',
    'Coopération Bilatérale': 'cooperation-bilaterale',
    'cooperation-bilaterale': 'cooperation-bilaterale',
    'Partenariats Régionaux': 'partenariats-regionaux',
    'partenariats-regionaux': 'partenariats-regionaux',
    'Coopération Économique': 'cooperation-economique',
    'cooperation-economique': 'cooperation-economique',
    'Sécurité et Défense': 'securite-defense',
    'securite-defense': 'securite-defense',
    'Coopération Culturelle': 'cooperation-culturelle',
    'cooperation-culturelle': 'cooperation-culturelle'
};

// Multer storage for resource documents with category-based folders
const resourceStorage = multer.diskStorage({
    destination: (req, file, cb) => {
        const category = req.body.category || 'autres';
        const folderName = categoryFolderMap[category] || category.toLowerCase().replace(/\s+/g, '-');
        const uploadDir = path.join(__dirname, 'uploads', 'ressources', folderName);

        if (!fs.existsSync(uploadDir)) {
            fs.mkdirSync(uploadDir, {
                recursive: true
            });
        }
        cb(null, uploadDir);
    },
    filename: (req, file, cb) => {
        cb(null, generateSafeFilename(file.originalname));
    }
});

const resourceUpload = multer({
    defParamCharset: 'utf8',
    storage: resourceStorage,
    limits: {
        fileSize: 20 * 1024 * 1024
    },
    fileFilter: createFileFilter({
        groups: [DOCUMENT_MIME_EXTENSIONS],
        label: 'PDF documents'
    })
});

// Get all resource documents
app.get('/api/resource-documents', (req, res) => {
    const documents = readData(resourceDocumentsFile);
    res.json(documents);
});

// Get resource documents by category
app.get('/api/resource-documents/:category', (req, res) => {
    const {
        category
    } = req.params;
    const documents = readData(resourceDocumentsFile);
    const categoryDocuments = documents.filter(doc => {
        const docCategory = categoryFolderMap[doc.category] || doc.category.toLowerCase().replace(/\s+/g, '-');
        return docCategory === category;
    });
    res.json(categoryDocuments);
});

// Upload resource document
app.post('/api/resource-documents', authenticateToken, requirePermission('manage_resource_documents'), resourceUpload.single('file'), (req, res) => {
    try {
        const {
            title,
            description,
            category
        } = req.body;

        if (!req.file) {
            return res.status(400).json({
                error: 'No file uploaded'
            });
        }

        if (!title || !category) {
            return res.status(400).json({
                error: 'Missing title or category'
            });
        }

        if (req.file.mimetype !== 'application/pdf') {
            return res.status(400).json({
                error: 'Only PDF files are allowed'
            });
        }

        const folderName = categoryFolderMap[category] || category.toLowerCase().replace(/\s+/g, '-');

        const document = {
            id: Date.now().toString(),
            title: title,
            description: description || '',
            category: category,
            fileName: req.file.originalname,
            fileUrl: `/uploads/ressources/${folderName}/${req.file.filename}`,
            uploadDate: new Date().toISOString(),
            fileSize: req.file.size
        };

        const documents = readData(resourceDocumentsFile);
        documents.push(document);

        if (writeData(resourceDocumentsFile, documents)) {
            res.status(201).json(document);
        } else {
            res.status(500).json({
                error: 'Failed to save document'
            });
        }
    } catch (error) {
        console.error('Upload error:', error);
        res.status(500).json({
            error: 'Upload failed: ' + error.message
        });
    }
}, (err, req, res, next) => {
    // Multer error handler
    if (err) {
        console.error('Multer error:', err);
        return res.status(400).json({
            error: err.message || 'File upload failed'
        });
    }
    next();
});

// Update resource document
app.put('/api/resource-documents/:id', authenticateToken, requirePermission('manage_resource_documents'), (req, res) => {
    const {
        id
    } = req.params;
    const updatedDocument = req.body;
    const documents = readData(resourceDocumentsFile);
    const index = documents.findIndex(d => d.id === id);

    if (index !== -1) {
        documents[index] = {
            ...documents[index],
            ...updatedDocument
        };
        if (writeData(resourceDocumentsFile, documents)) {
            res.json(documents[index]);
        } else {
            res.status(500).json({
                error: 'Failed to update document'
            });
        }
    } else {
        res.status(404).json({
            error: 'Document not found'
        });
    }
});

// Delete resource document
app.delete('/api/resource-documents/:id', authenticateToken, requirePermission('manage_resource_documents'), (req, res) => {
    const {
        id
    } = req.params;
    const documents = readData(resourceDocumentsFile);
    const document = documents.find(d => d.id === id);

    if (!document) {
        return res.status(404).json({
            error: 'Document not found'
        });
    }

    // Delete file from disk
    if (document.fileUrl) {
        const filePath = path.join(__dirname, 'uploads', document.fileUrl.replace('/uploads/', ''));
        if (fs.existsSync(filePath)) {
            try {
                fs.unlinkSync(filePath);
            } catch (error) {
                console.error('Error deleting file:', error);
            }
        }
    }

    const filteredDocuments = documents.filter(d => d.id !== id);
    if (writeData(resourceDocumentsFile, filteredDocuments)) {
        res.status(204).send();
    } else {
        res.status(500).json({
            error: 'Failed to delete document'
        });
    }
});


// ====== OTP VERIFICATION ENDPOINTS ======

/**
 * POST /api/request-otp
 * Request an OTP code for password reset
 * Body: { email }
 */
// Password-reset codes, keyed by account email. Kept in memory (5-minute lifetime) so the flow works
// whether the account lives in MySQL or in users.json; a server restart simply invalidates pending codes.
const passwordResetCodes = new Map();
const PASSWORD_RESET_CODE_TTL_MS = 5 * 60 * 1000;
const findResetAccount = (identifier) => authServiceHybrid.findUser(
    identifier.includes('@') ? { email: identifier.toLowerCase() } : { username: identifier }
);

app.post('/api/request-otp', emailSendingRateLimiter, async (req, res) => {
    try {
        const identifier = String(req.body.email || '').trim();

        if (!identifier) {
            return res.status(400).json({ error: 'Email or username is required' });
        }

        // Same lookup as login (MySQL first, then users.json)
        const user = await findResetAccount(identifier);
        const email = String(user?.email || '').trim().toLowerCase();

        // Same answer whether or not the account exists, so this form cannot be used to list admin emails
        if (!user || user.role !== 'admin' || !email) {
            return res.json({ success: true, message: 'OTP sent to your email' });
        }

        const otp = crypto.randomInt(100000, 1000000).toString();
        passwordResetCodes.set(email, { code: otp, expiresAt: Date.now() + PASSWORD_RESET_CODE_TTL_MS, attempts: 0, verified: false });

        console.log(`\n🔐 OTP generated for ${email}`);

        // Try to send via email
        const mailOptions = {
            from: 'tchad@diplomatie.gouv.td',
            to: email,
            subject: 'Réinitialisation du mot de passe - Code OTP | Ministère Tchad',
            html: `
                <div style="font-family: Arial, sans-serif; background-color: #f5f5f5; padding: 20px;">
                    <div style="background-color: white; border-radius: 8px; padding: 30px; max-width: 600px; margin: 0 auto;">
                        <p style="color: #002D72; font-size: 40px; font-weight: bold; text-align: center; letter-spacing: 8px; font-family: 'Courier New', monospace; margin: 20px 0;">${otp}</p>
                        <p style="color: #666; font-size: 14px; text-align: center; margin: 20px 0;">Votre code expire dans 5 minutes</p>
                    </div>
                </div>
            `
        };

        try {
            await transporter.sendMail(mailOptions);
            console.log(`✅ OTP email sent to ${email}`);
        } catch (emailError) {
            console.log('⚠️  OTP email failed; code was not exposed in the response');
        }

        res.json({
            success: true,
            message: 'OTP sent to your email'
        });

    } catch (error) {
        console.error('Error requesting OTP:', error.message);
        res.status(500).json({ error: 'Failed to request OTP' });
    }
});

/**
 * POST /api/verify-otp
 * Verify OTP code before password reset
 * Body: { email, otp }
 */
app.post('/api/verify-otp', credentialRateLimiter, async (req, res) => {
    try {
        const identifier = String(req.body.email || '').trim();
        const otp = String(req.body.otp || '').trim();

        if (!identifier || !otp) {
            return res.status(400).json({ error: 'Email/username and OTP are required' });
        }

        const user = await findResetAccount(identifier);
        const email = String(user?.email || '').trim().toLowerCase();
        const entry = email ? passwordResetCodes.get(email) : null;

        if (!entry) {
            return res.status(400).json({ error: 'No OTP request found. Request OTP first.' });
        }

        if (Date.now() > entry.expiresAt) {
            passwordResetCodes.delete(email);
            return res.status(400).json({ error: 'OTP has expired. Request a new one.' });
        }

        entry.attempts += 1;
        if (entry.code !== otp) {
            console.log(`❌ Invalid OTP attempt for ${identifier}`);

            // Invalidate the code after 5 failed attempts
            if (entry.attempts >= 5) {
                passwordResetCodes.delete(email);
                return res.status(429).json({ error: 'Too many failed attempts. Request a new OTP.' });
            }

            return res.status(400).json({
                error: 'Code OTP invalide. Veuillez réessayer.',
                attempts: entry.attempts,
                remainingAttempts: 5 - entry.attempts
            });
        }

        entry.verified = true;
        entry.attempts = 0;

        console.log(`✅ OTP verified for ${email}`);

        res.json({
            success: true,
            message: 'OTP verified successfully',
            verified: true
        });

    } catch (error) {
        console.error('Error verifying OTP:', error.message);
        res.status(500).json({ error: 'Failed to verify OTP' });
    }
});

// Hybrid Auth Service (works with DB or JSON)
const authServiceHybrid = require('./services/authServiceHybrid');
const authMiddlewareHybrid = require('./middlewares/authMiddlewareHybrid');

const isTwoFactorRequiredForLogin = (user) => false;

const cleanupExpiredLogin2FA = () => {
    const now = Date.now();
    for (const [challengeId, challenge] of pendingLogin2FA.entries()) {
        if (!challenge.expiresAt || challenge.expiresAt <= now) {
            pendingLogin2FA.delete(challengeId);
        }
    }
};

const createLogin2FAChallenge = async (user) => {
    cleanupExpiredLogin2FA();

    if (!user?.email) {
        const error = new Error('Two-factor authentication requires an email address.');
        error.status = 400;
        throw error;
    }

    const challengeId = crypto.randomBytes(24).toString('hex');
    const otp = crypto.randomInt(100000, 1000000).toString();
    const expiresAt = Date.now() + LOGIN_2FA_TTL_MS;

    pendingLogin2FA.set(challengeId, {
        userId: String(user.id),
        email: String(user.email).toLowerCase(),
        otp,
        expiresAt,
        attempts: 0
    });

    const mailOptions = {
        from: '"MAE Sécurité" <tchad@diplomatie.gouv.td>',
        to: user.email,
        subject: 'Code de connexion administrateur | Ministère des Affaires Étrangères',
        html: `
            <div style="font-family: Arial, sans-serif; background-color: #f5f5f5; padding: 20px;">
                <div style="background-color: white; border-radius: 8px; padding: 30px; max-width: 600px; margin: 0 auto;">
                    <h2 style="color: #002D72; text-align: center;">Code de connexion administrateur</h2>
                    <p>Utilisez ce code pour terminer votre connexion. Il expire dans 5 minutes.</p>
                    <p style="color: #002D72; font-size: 40px; font-weight: bold; text-align: center; letter-spacing: 8px; font-family: 'Courier New', monospace; margin: 20px 0;">${otp}</p>
                    <p style="color: #666; font-size: 13px;">Si vous n'êtes pas à l'origine de cette tentative, changez votre mot de passe immédiatement.</p>
                </div>
            </div>
        `
    };

    try {
        await transporter.sendMail(mailOptions);
        console.log('✅ 2FA code sent to:', user.email);
    } catch (error) {
        console.warn('⚠️  Email sending failed:', error.message);
        // Handle Gmail authentication errors or development mode
        if (error.message.includes('Username and Password not accepted') ||
            error.message.includes('Invalid login') ||
            process.env.NODE_ENV !== 'production') {
            // Log OTP to console for development/testing
            console.log('🔑 [DEV] 2FA Code for admin:', otp);
            console.log('📧 [DEV] Email to:', user.email);
            console.log('⚠️  Email service unavailable, OTP logged to console for testing');
        } else {
            // In production with email configured, throw error
            pendingLogin2FA.delete(challengeId);
            const sendError = new Error('Unable to send 2FA code. Contact the website administrator.');
            sendError.status = 503;
            throw sendError;
        }
    }

    return {
        challengeId,
        expiresAt
    };
};

const finishLoginWithSession = (user, res) => {
    // One session per account: the newest login replaces the previous one, and the old browser
    // is signed out on its next request. Refusing the login instead locked the real owner out
    // whenever a tab was left open or closed without logging out.
    const session = sessionService.createSession(user);
    const { accessToken, refreshToken } = authServiceHybrid.generateTokens(user, session.id);
    const userJson = authServiceHybrid.userToJSON(user);

    res.cookie('refreshToken', refreshToken, {
        httpOnly: true,
        secure: process.env.NODE_ENV === 'production',
        sameSite: 'strict',
        maxAge: sessionService.SESSION_IDLE_TIMEOUT_MS
    });

    return {
        user: userJson,
        accessToken,
        refreshToken
    };
};

// --- Authentication endpoints (Hybrid - works with DB or JSON) ---
/**
 * Test endpoint to verify backend is working
 * POST /api/auth/test
 */
app.post('/api/auth/test', authenticateToken, requireAdmin, (req, res) => {
    console.error('🧪 TEST ENDPOINT CALLED!');
    res.json({ success: true, message: 'Test endpoint works!' });
});

/**
 * Login endpoint - Returns JWT token
 * POST /api/auth/login
 * Body: { email/username, password }
 */
app.post('/api/auth/login', credentialRateLimiter, async (req, res) => {
    try {
        // Strings only (objects would be injection attempts); emails often arrive with spaces or capitals from autofill
        const email = typeof req.body.email === 'string' ? req.body.email.trim().toLowerCase() : '';
        const username = typeof req.body.username === 'string' ? req.body.username.trim() : '';
        const password = typeof req.body.password === 'string' ? req.body.password : '';


        if (!password) {
            console.warn('⚠️  No password provided');
            return res.status(400).json({
                success: false,
                error: 'Password is required'
            });
        }

        if (!email && !username) {
            console.warn('⚠️  No email or username provided');
            return res.status(400).json({
                success: false,
                error: 'Email or username is required'
            });
        }

        // Find user (works with DB or JSON)
        console.log('🔍 Finding user...');
        const user = await authServiceHybrid.findUser(
            email ? { email } : { username }
        );

        if (!user) {
            console.warn('⚠️  User not found:', email || username);
            return res.status(401).json({
                success: false,
                error: 'Invalid email/username or password'
            });
        }

        console.log('✅ User found:', user.email);

        // Verify password
        console.log('🔑 Verifying password...');
        const isPasswordCorrect = await authServiceHybrid.comparePassword(password, user.password);

        if (!isPasswordCorrect) {
            console.warn('⚠️  Password incorrect for:', email || username);
            return res.status(401).json({
                success: false,
                error: 'Invalid email/username or password'
            });
        }

        console.log('✅ Password correct');

        const loginData = finishLoginWithSession(user, res);

        console.log('✅ User logged in successfully: ' + (email || username));

        const response = {
            success: true,
            message: 'Login successful',
            data: loginData
        };

        console.log('📤 Sending response:', JSON.stringify(response).substring(0, 200));
        res.json(response);
    } catch (error) {
        console.error('❌ Login error:', error.message);
        console.error('Stack:', error.stack);
        res.status(500).json({
            success: false,
            error: error.message || 'Login failed'
        });
    }
});

app.post('/api/auth/verify-login-2fa', credentialRateLimiter, async (req, res) => {
    try {
        const { challengeId, otp } = req.body;

        if (!challengeId || !otp) {
            return res.status(400).json({
                success: false,
                error: 'Challenge ID and OTP are required'
            });
        }

        cleanupExpiredLogin2FA();

        const challenge = pendingLogin2FA.get(String(challengeId));
        if (!challenge) {
            return res.status(400).json({
                success: false,
                error: '2FA challenge expired. Please login again.'
            });
        }

        challenge.attempts += 1;
        if (challenge.attempts > LOGIN_2FA_MAX_ATTEMPTS) {
            pendingLogin2FA.delete(String(challengeId));
            return res.status(429).json({
                success: false,
                error: 'Too many failed 2FA attempts. Please login again.'
            });
        }

        if (challenge.otp !== String(otp).trim()) {
            return res.status(400).json({
                success: false,
                error: 'Invalid 2FA code',
                remainingAttempts: LOGIN_2FA_MAX_ATTEMPTS - challenge.attempts
            });
        }

        const user = await authServiceHybrid.findUser({ email: challenge.email });
        if (!user || String(user.id) !== challenge.userId || !isTwoFactorRequiredForLogin(user)) {
            pendingLogin2FA.delete(String(challengeId));
            return res.status(401).json({
                success: false,
                error: '2FA challenge is no longer valid'
            });
        }

        pendingLogin2FA.delete(String(challengeId));
        const loginData = finishLoginWithSession(user, res);

        console.log('✅ Admin 2FA login completed:', challenge.email);
        res.json({
            success: true,
            message: 'Login successful',
            data: loginData
        });
    } catch (error) {
        console.error('❌ 2FA verification error:', error.message);
        res.status(error.status || 500).json({
            success: false,
            error: error.message || '2FA verification failed'
        });
    }
});

app.post('/api/auth/logout', authenticateToken, (req, res) => {
    try {
        sessionService.revokeSession(req.user.id, req.user.sessionId);
        res.clearCookie('refreshToken', {
            httpOnly: true,
            secure: process.env.NODE_ENV === 'production',
            sameSite: 'strict'
        });
        res.json({ success: true, message: 'Logged out' });
    } catch (error) {
        console.warn('[Logout] Could not revoke session:', error.message);
        res.status(200).json({ success: true, message: 'Logged out locally' });
    }
});

/**
 * Get current user profile
 * GET /api/auth/profile
 * Headers: Authorization: Bearer <token>
 */
app.get('/api/auth/profile', authenticateToken, async (req, res) => {
    try {
        if (!req.user || !req.user.email) {
            return res.status(401).json({
                success: false,
                error: 'Not authenticated'
            });
        }

        const user = await authServiceHybrid.findUser({ email: req.user.email });

        if (!user) {
            return res.status(404).json({
                success: false,
                error: 'User not found'
            });
        }

        res.json({
            success: true,
            data: authServiceHybrid.userToJSON(user)
        });
    } catch (error) {
        console.error('Profile fetch error:', error);
        res.status(500).json({
            success: false,
            error: 'Failed to fetch profile'
        });
    }
});

/**
 * Update user profile
 * PUT /api/auth/profile
 * Headers: Authorization: Bearer <token>
 */
app.put('/api/auth/profile', authenticateToken, async (req, res) => {
    try {
        if (!req.user || !req.user.email) {
            return res.status(401).json({
                success: false,
                error: 'Not authenticated'
            });
        }

        const user = await authServiceHybrid.findUser({ email: req.user.email });

        if (!user) {
            return res.status(404).json({
                success: false,
                error: 'User not found'
            });
        }

        res.json({
            success: true,
            data: authServiceHybrid.userToJSON(user)
        });
    } catch (error) {
        console.error('Profile update error:', error);
        res.status(500).json({
            success: false,
            error: 'Failed to update profile'
        });
    }
});

/**
 * Change password endpoint
 * POST /api/auth/change-password
 * Headers: Authorization: Bearer <token>
 */
app.post('/api/auth/change-password', authenticateToken, async (req, res) => {
    try {
        if (!req.user || !req.user.email) {
            return res.status(401).json({
                success: false,
                error: 'Not authenticated'
            });
        }

        const { currentPassword, newPassword } = req.body;

        if (!currentPassword || !newPassword) {
            return res.status(400).json({
                success: false,
                error: 'Current and new passwords are required'
            });
        }

        const strength = validatePassword(String(newPassword));
        if (!strength.valid) {
            return res.status(400).json({
                success: false,
                error: strength.message
            });
        }

        const user = await authServiceHybrid.findUser({ email: req.user.email });

        if (!user) {
            return res.status(404).json({
                success: false,
                error: 'User not found'
            });
        }

        // Verify current password
        const isPasswordCorrect = await authServiceHybrid.comparePassword(currentPassword, user.password);

        if (!isPasswordCorrect) {
            return res.status(401).json({
                success: false,
                error: 'Current password is incorrect'
            });
        }

        // ✅ FIXED: Actually update the password in database/JSON
        await authServiceHybrid.updateUser(req.user.email, { password: newPassword });

        console.log(`✅ Password successfully changed for user: ${user.email}`);

        res.json({
            success: true,
            message: 'Password changed successfully'
        });
    } catch (error) {
        console.error('❌ Password change error:', error);
        res.status(500).json({
            success: false,
            error: error.message || 'Failed to change password'
        });
    }
});

/**
 * Reset password endpoint
 * POST /api/auth/reset-password
 */
app.post('/api/auth/reset-password', emailSendingRateLimiter, async (req, res) => {
    try {
        const identifier = String(req.body.email || '').trim();
        const newPassword = String(req.body.newPassword || '').trim();

        if (!identifier || !newPassword) {
            return res.status(400).json({
                success: false,
                error: 'Email/username and new password are required'
            });
        }

        const user = await findResetAccount(identifier);
        const email = String(user?.email || '').trim().toLowerCase();
        const entry = email ? passwordResetCodes.get(email) : null;

        if (!entry?.verified) {
            return res.status(403).json({
                success: false,
                error: 'OTP not verified. Please verify OTP first.'
            });
        }

        if (Date.now() > entry.expiresAt) {
            passwordResetCodes.delete(email);
            return res.status(400).json({
                success: false,
                error: 'OTP has expired. Request a new one.'
            });
        }

        const strength = validatePassword(newPassword);
        if (!strength.valid) {
            return res.status(400).json({
                success: false,
                error: strength.message
            });
        }

        // Saved where login reads it (MySQL if the account is there, otherwise users.json)
        await authServiceHybrid.updateUser(user.email, { password: newPassword });
        passwordResetCodes.delete(email);

        console.log(`✅ Password reset successfully for user: ${user.email || user.username}`);

        res.json({
            success: true,
            message: 'Password changed successfully'
        });
    } catch (error) {
        console.error('❌ Password reset error:', error);
        res.status(500).json({
            success: false,
            error: error.message || 'Password reset failed'
        });
    }
});

// --- Admin users endpoints (protected by JWT authentication) ---
app.get('/api/admin/users-test', authenticateToken, requireAdmin, async (req, res) => {
    try {
        console.log('\n📊 [GET /api/admin/users-test] Fetching users from JSON');

        const jsonUsers = readData(usersFile);

        // Remove passwords and sensitive data
        const users = jsonUsers.map(user => {
            const { password, otpCode, otpExpiry, otpAttempts, otpVerified, ...sanitized } = user;
            return sanitized;
        });

        console.log(`✅ Loaded ${users.length} users from JSON file`);
        res.json(users);
    } catch (error) {
        console.error('❌ Error fetching users:', error);
        res.status(500).json({
            success: false,
            error: 'Failed to fetch users',
            details: error.message
        });
    }
});

// Get all users from JSON file
app.get('/api/admin/users', authenticateToken, requireAdmin, async (req, res) => {
    try {
        console.log('\n📊 [GET /api/admin/users] Fetching users from JSON');

        const jsonUsers = readData(usersFile);

        // Remove passwords and sensitive data
        const users = jsonUsers.map(user => {
            const { password, otpCode, otpExpiry, otpAttempts, otpVerified, ...sanitized } = user;
            return sanitized;
        });

        console.log(`✅ Loaded ${users.length} users from JSON file`);
        res.json(users);
    } catch (error) {
        console.error('❌ Error fetching users:', error);
        res.status(500).json({
            success: false,
            error: 'Failed to fetch users',
            details: error.message
        });
    }
});

// Create user in JSON file
app.post('/api/admin/users', authenticateToken, requireAdmin, async (req, res) => {
    try {
        console.log('\n📝 [POST /api/admin/users] Creating new user in JSON');
        const { email, name, role, permissions, password } = req.body;

        if (!email) {
            return res.status(400).json({
                success: false,
                error: 'Email is required'
            });
        }
        if (!password) {
            return res.status(400).json({
                success: false,
                error: 'Password is required'
            });
        }

        // Validate password strength
        const validation = validatePassword(password);
        if (!validation.valid) {
            return res.status(400).json({
                success: false,
                error: validation.message
            });
        }

        // Check if user already exists
        const jsonUsers = readData(usersFile);
        const existingUser = jsonUsers.find(u => u.email === email);
        if (existingUser) {
            return res.status(400).json({
                success: false,
                error: 'User already exists'
            });
        }

        // Hash password
        const hashedPassword = await hashPassword(password);
        console.log('✅ Password hashed');

        // Create new user object
        const newUser = {
            id: Date.now().toString(),
            email,
            name: name || '',
            password: hashedPassword,
            role: role || 'editor',
            status: 'active',
            permissions: permissions || {},
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString()
        };

        // Add to JSON file
        jsonUsers.push(newUser);
        if (!writeData(usersFile, jsonUsers)) {
            return res.status(500).json({
                success: false,
                error: 'Failed to save user to file'
            });
        }

        console.log(`✅ User created in JSON: ${email}`);

        // Send credentials email to the shared admin mailbox (all accounts route through it)
        console.log(`📧 Sending credentials email to ${ADMIN_NOTIFY_EMAIL} for new user ${email}`);
        const mailOptions = {
            from: `"MAE (Ministere des affaires etrangers)" <${MAIL_FROM}>`,
            to: ADMIN_NOTIFY_EMAIL,
            subject: 'Nouveau compte créé - Identifiants | Ministère des Affaires Étrangères',
            html: `
                <div style="font-family: Arial, sans-serif; background-color: #f5f5f5; padding: 20px;">
                    <div style="background-color: white; border-radius: 8px; padding: 30px; max-width: 600px; margin: 0 auto;">
                        <h2 style="color: #002D72; text-align: center;">Nouveau compte créé</h2>
                        <p>Un nouveau compte a été créé avec les identifiants suivants :</p>
                        <div style="background-color: #f8f9fa; padding: 15px; margin: 20px 0; border-radius: 5px;">
                            <p><strong>Nom:</strong> ${name || 'N/A'}</p>
                            <p><strong>Email / identifiant:</strong> ${email}</p>
                            <p><strong>Mot de passe:</strong> ${password}</p>
                        </div>
                        <p style="color: #dc3545;"><strong>⚠️ Conservez ces informations en lieu sûr.</strong></p>
                    </div>
                </div>
            `
        };

        try {
            await transporter.sendMail(mailOptions);
            console.log(`✅ Credentials email sent to ${ADMIN_NOTIFY_EMAIL}`);
        } catch (emailError) {
            console.warn(`⚠️ Failed to send email to ${ADMIN_NOTIFY_EMAIL}: ${emailError.message}`);
        }

        // Return user without password
        const { password: _, ...userResponse } = newUser;

        res.status(201).json({
            success: true,
            message: `User ${email} created successfully`,
            data: userResponse
        });
    } catch (error) {
        console.error('❌ Error creating user:', error);
        res.status(500).json({
            success: false,
            error: 'Error creating user',
            details: error.message
        });
    }
});

// Update user in JSON file
app.put('/api/admin/users/:id', authenticateToken, requireAdmin, async (req, res) => {
    try {
        console.log('\n📝 [PUT /api/admin/users/:id] Updating user in JSON');
        const { id } = req.params;
        const updated = req.body;

        const jsonUsers = readData(usersFile);
        const userIndex = jsonUsers.findIndex(u => u.id === id || u.email === id);

        if (userIndex === -1) {
            return res.status(404).json({
                success: false,
                error: 'User not found'
            });
        }

        const user = jsonUsers[userIndex];

        // If updating password, hash it
        const plainNewPassword = updated.password;
        if (updated.password) {
            const validation = validatePassword(updated.password);
            if (!validation.valid) {
                return res.status(400).json({
                    success: false,
                    error: validation.message
                });
            }
            updated.password = await hashPassword(updated.password);
            console.log('🔐 Password updated and hashed');
        }

        // Update user object
        const updatedUser = {
            ...user,
            ...updated,
            updatedAt: new Date().toISOString()
        };

        jsonUsers[userIndex] = updatedUser;

        if (!writeData(usersFile, jsonUsers)) {
            return res.status(500).json({
                success: false,
                error: 'Failed to update user'
            });
        }

        console.log(`✅ User ${id} updated successfully`);

        // Notify the shared admin mailbox whenever an admin sets a new password for a user
        if (plainNewPassword) {
            const mailOptions = {
                from: `"MAE (Ministere des affaires etrangers)" <${MAIL_FROM}>`,
                to: ADMIN_NOTIFY_EMAIL,
                subject: 'Mot de passe modifié - Identifiants | Ministère des Affaires Étrangères',
                html: `
                    <div style="font-family: Arial, sans-serif; background-color: #f5f5f5; padding: 20px;">
                        <div style="background-color: white; border-radius: 8px; padding: 30px; max-width: 600px; margin: 0 auto;">
                            <h2 style="color: #002D72; text-align: center;">Mot de passe modifié</h2>
                            <p>Le mot de passe d'un compte a été modifié par un administrateur :</p>
                            <div style="background-color: #f8f9fa; padding: 15px; margin: 20px 0; border-radius: 5px;">
                                <p><strong>Nom:</strong> ${updatedUser.name || 'N/A'}</p>
                                <p><strong>Email / identifiant:</strong> ${updatedUser.email || id}</p>
                                <p><strong>Nouveau mot de passe:</strong> ${plainNewPassword}</p>
                            </div>
                            <p style="color: #dc3545;"><strong>⚠️ Conservez ces informations en lieu sûr.</strong></p>
                        </div>
                    </div>
                `
            };

            try {
                await transporter.sendMail(mailOptions);
                console.log(`✅ Password-change email sent to ${ADMIN_NOTIFY_EMAIL} for user ${updatedUser.email || id}`);
            } catch (emailError) {
                console.warn(`⚠️ Failed to send password-change email to ${ADMIN_NOTIFY_EMAIL}: ${emailError.message}`);
            }
        }

        // Return user without password
        const { password, otpCode, otpExpiry, otpAttempts, otpVerified, ...userResponse } = updatedUser;

        res.json({
            success: true,
            message: `User ${id} updated successfully`,
            data: userResponse
        });
    } catch (error) {
        console.error('❌ Error updating user:', error);
        res.status(500).json({
            success: false,
            error: 'Error updating user',
            details: error.message
        });
    }
});

// Delete user from JSON file
app.delete('/api/admin/users/:id', authenticateToken, requireAdmin, async (req, res) => {
    try {
        console.log('\n🗑️ [DELETE /api/admin/users/:id] Deleting user from JSON');
        const { id } = req.params;

        const jsonUsers = readData(usersFile);
        const userIndex = jsonUsers.findIndex(u => u.id === id || u.email === id);

        if (userIndex === -1) {
            return res.status(404).json({
                success: false,
                error: 'User not found'
            });
        }

        // Remove user from array
        const deletedUser = jsonUsers.splice(userIndex, 1)[0];

        if (!writeData(usersFile, jsonUsers)) {
            return res.status(500).json({
                success: false,
                error: 'Failed to delete user'
            });
        }

        console.log(`✅ User ${id} deleted successfully`);

        res.json({
            success: true,
            message: `User ${id} deleted successfully`
        });
    } catch (error) {
        console.error('❌ Error deleting user:', error);
        res.status(500).json({
            success: false,
            error: 'Error deleting user',
            details: error.message
        });
    }
});

// Send invite (generate OTP and email)
app.post('/api/admin/send-invite', authenticateToken, requireAdmin, async (req, res) => {
    try {
        const {
            email
        } = req.body;
        if (!email) return res.status(400).json({
            error: 'Email required'
        });

        const otp = crypto.randomInt(100000, 1000000).toString();

        // Reuse email template
        const mailOptions = {
            from: 'tchad@diplomatie.gouv.td',
            to: email,
            subject: 'Invitation - Espace Administrateur | Ministère Tchad',
            html: `<p>Vous avez été invité à rejoindre l'espace administrateur. Votre code OTP: <strong>${otp}</strong></p>`
        };

        try {
            await transporter.sendMail(mailOptions);
            console.log(`✓ Invite OTP sent to ${email}`);
            return res.json({
                success: true,
                message: 'Invite sent'
            });
        } catch (e) {
            console.log('📧 DEMO MODE - Invite email failed, returning OTP in response');
            return res.json({
                success: true,
                message: 'Invite (demo mode)',
                demoOtp: otp
            });
        }
    } catch (error) {
        console.error('Error sending invite:', error);
        res.status(500).json({
            error: 'Error sending invite'
        });
    }
});

// Initialize default admin account
async function initializeAdminAccount(dbResult) {
    try {
        const adminEmail = 'admin@diplomatie.td';
        const adminName = 'Administrateur MAE';

        console.log('🔧 Checking admin account...');

        const existingAdmin = await authServiceHybrid.findUser({ email: adminEmail });

        if (!existingAdmin) {
            console.log('📝 Creating default admin account...');

            // No password in the source code: take ADMIN_INITIAL_PASSWORD from .env, or generate one
            // and store it in a private file (data/ is git-ignored) instead of printing it to the logs.
            const envPassword = process.env.ADMIN_INITIAL_PASSWORD || '';
            const initialPassword = validatePassword(envPassword).valid
                ? envPassword
                : `Adm-${crypto.randomBytes(12).toString('base64url')}7a!`;

            // Create admin user - works with both DB and JSON
            await authServiceHybrid.createUser({
                id: 'admin-' + Date.now(),
                email: adminEmail,
                name: adminName,
                password: initialPassword,
                role: 'admin',
                status: 'active',
                permissions: {}
            });

            console.log('✅ Default admin account created');
            console.log(`   Email: ${adminEmail}`);
            if (initialPassword !== envPassword) {
                const passwordFile = path.join(dataDir, 'initial-admin-password.txt');
                fs.writeFileSync(passwordFile, `${adminEmail}\n${initialPassword}\n`, { mode: 0o600 });
                console.log(`   Password: written to ${passwordFile} (readable by the server account only)`);
            } else {
                console.log('   Password: ADMIN_INITIAL_PASSWORD from .env');
            }
            console.log('   ⚠️  Please change the password after first login\n');
        } else {
            console.log('✅ Admin account already exists\n');
        }
    } catch (error) {
        console.error('❌ Error initializing admin account:', error);
    }
}

// YouTube latest videos endpoint with caching and fallback
const youtubeCacheFile = path.join(dataDir, 'youtubeCache.json');
const YT_CACHE_TTL_MS = 30 * 60 * 1000; // 30 minutes

function readJsonSafe(file, fallback = {}) {
    try {
        if (!fs.existsSync(file)) return fallback;
        const raw = fs.readFileSync(file, 'utf8');
        return JSON.parse(raw || 'null') || fallback;
    } catch (e) {
        return fallback;
    }
}

function writeJsonSafe(file, data) {
    try {
        writeJsonAtomic(file, data);
    } catch (e) {
        console.error('Failed to write cache:', e.message);
    }
}

async function fetchYouTubeViaAPI(channelId, maxResults) {
    const API_KEY = process.env.YOUTUBE_API_KEY;
    if (!API_KEY) return null;
    // Step 1: get channel details to find uploads playlistId
    const channelResp = await fetch(`https://www.googleapis.com/youtube/v3/channels?part=contentDetails&id=${channelId}&key=${API_KEY}`);
    if (!channelResp.ok) throw new Error('YouTube API channel error');
    const channelData = await channelResp.json();
    const uploadsId = channelData.items?.[0]?.contentDetails?.relatedPlaylists?.uploads;
    if (!uploadsId) throw new Error('Uploads playlist not found');

    // Step 2: fetch latest playlist items
    const listResp = await fetch(`https://www.googleapis.com/youtube/v3/playlistItems?part=snippet&playlistId=${uploadsId}&maxResults=${maxResults}&key=${API_KEY}`);
    if (!listResp.ok) throw new Error('YouTube API playlistItems error');
    const listData = await listResp.json();

    return (listData.items || []).map(it => ({
        videoId: it.snippet?.resourceId?.videoId,
        title: it.snippet?.title,
        publishedAt: it.snippet?.publishedAt,
        thumbnails: it.snippet?.thumbnails || {},
        channelTitle: it.snippet?.channelTitle
    })).filter(v => v.videoId);
}

async function fetchYouTubeViaRSS(channelId, maxResults) {
    // RSS fallback (no API key). Requires channelId.
    const rssUrl = `https://www.youtube.com/feeds/videos.xml?channel_id=${channelId}`;
    const resp = await fetch(rssUrl, {
        headers: {
            'User-Agent': 'Mozilla/5.0'
        }
    });
    if (!resp.ok) throw new Error('RSS fetch failed');
    const xml = await resp.text();
    // Simple XML extraction for <yt:videoId>, <title>, <published>
    const entries = [];
    const entryRegex = /<entry>[\s\S]*?<yt:videoId>(.*?)<\/yt:videoId>[\s\S]*?<title>([\s\S]*?)<\/title>[\s\S]*?<published>(.*?)<\/published>[\s\S]*?<\/entry>/g;
    let m;
    while ((m = entryRegex.exec(xml)) && entries.length < maxResults) {
        const videoId = m[1];
        const title = m[2].replace(/<!\[CDATA\[|\]\]>/g, '');
        const publishedAt = m[3];
        entries.push({
            videoId,
            title,
            publishedAt,
            thumbnails: {
                medium: {
                    url: `https://i.ytimg.com/vi/${videoId}/mqdefault.jpg`
                }
            }
        });
    }
    return entries;
}

// Known channelId for @tchaddiplomatie
const TCHAD_DIPLO_CHANNEL_ID = 'UC4cAPi2PHj6x7FAe1QAUp7w';

app.get('/api/youtube/latest', async (req, res) => {
    try {
        const max = Math.min(parseInt(req.query.max || '10', 10) || 10, 20);
        const now = Date.now();
        const cache = readJsonSafe(youtubeCacheFile, {
            lastFetched: 0,
            items: []
        });
        if (cache.lastFetched && (now - cache.lastFetched) < YT_CACHE_TTL_MS && Array.isArray(cache.items) && cache.items.length) {
            return res.json({
                items: cache.items.slice(0, max),
                cached: true
            });
        }

        let items = null;
        try {
            items = await fetchYouTubeViaAPI(TCHAD_DIPLO_CHANNEL_ID, max);
        } catch (e) {
            console.warn('YouTube API error, will try RSS fallback:', e.message);
        }

        if (!items || !items.length) {
            try {
                items = await fetchYouTubeViaRSS(TCHAD_DIPLO_CHANNEL_ID, max);
            } catch (e) {
                console.error('YouTube RSS fallback failed:', e.message);
            }
        }

        if (items && items.length) {
            const payload = {
                lastFetched: now,
                items
            };
            writeJsonSafe(youtubeCacheFile, payload);
            return res.json({
                items,
                cached: false
            });
        }

        // Final fallback to existing cache even if stale
        if (Array.isArray(cache.items) && cache.items.length) {
            return res.json({
                items: cache.items.slice(0, max),
                cached: true,
                stale: true
            });
        }
        return res.status(503).json({
            error: 'Failed to fetch YouTube videos'
        });
    } catch (err) {
        console.error('YouTube latest endpoint error:', err.message);
        return res.status(500).json({
            error: 'Internal server error'
        });
    }
});

// ===== USER MANAGEMENT ROUTES =====
/**
 * Mount user management routes
 * Endpoints: POST /api/users/create, GET /api/users, PUT /api/users/:id, etc.
 */
const userRoutes = require('./api/users.routes');
app.use('/api/users', userRoutes);

// ===== ADMIN-INITIATED PASSWORD RESET =====
/**
 * Admin initiates password reset for another user
 * POST /api/auth/admin/reset-password
 * Headers: Authorization: Bearer <admin-token>
 * Body: { targetEmail }
 */
app.post('/api/auth/admin/reset-password', authenticateToken, async (req, res) => {
    try {
        const { targetEmail } = req.body;

        if (!targetEmail) {
            return res.status(400).json({
                success: false,
                error: 'Target email is required'
            });
        }

        // req.user comes from the session-checked token (MySQL or users.json account)
        if (!req.user || req.user.role !== 'admin') {
            return res.status(403).json({
                success: false,
                error: 'Only admin users can initiate password reset for others'
            });
        }

        // Find target user (same lookup as login)
        const targetUser = await findResetAccount(String(targetEmail).trim());
        if (!targetUser) {
            return res.status(404).json({
                success: false,
                error: 'Target user not found'
            });
        }

        // Generate OTP for the target account
        const otp = crypto.randomInt(100000, 1000000).toString();
        passwordResetCodes.set(String(targetUser.email).toLowerCase(), { code: otp, expiresAt: Date.now() + PASSWORD_RESET_CODE_TTL_MS, attempts: 0, verified: false });

        // Send OTP to ADMIN email, not the target user
        const mailOptions = {
            from: 'tchad@diplomatie.gouv.td',
            to: req.user.email, // Send to admin who initiated the reset
            subject: 'Réinitialisation du mot de passe - Code OTP | Ministère Tchad',
            html: `
                <div style="font-family: Arial, sans-serif; background-color: #f5f5f5; padding: 20px;">
                    <div style="background-color: white; border-radius: 8px; padding: 30px; max-width: 600px; margin: 0 auto;">
                        <div style="text-align: center; margin-bottom: 30px;">
                            <h2 style="color: #002D72; margin: 0;">Réinitialisation du mot de passe</h2>
                        </div>
                        
                        <p style="color: #333; font-size: 16px; margin: 20px 0;">
                            Bonjour ${req.user.name || req.user.email},
                        </p>
                        
                        <p style="color: #333; font-size: 16px; margin: 20px 0;">
                            Vous avez initié une réinitialisation de mot de passe pour l'utilisateur: <strong>${targetEmail}</strong>
                        </p>
                        
                        <p style="color: #666; font-size: 14px; margin: 20px 0;">
                            Le code de vérification OTP ci-dessous est valide pendant <strong>5 minutes</strong>.
                        </p>
                        
                        <div style="background-color: #f0f0f0; border: 3px solid #002D72; border-radius: 8px; padding: 25px; text-align: center; margin: 30px 0;">
                            <p style="color: #666; font-size: 13px; margin: 0 0 15px 0; font-weight: bold;">CODE OTP POUR ${targetEmail}</p>
                            <p style="color: #002D72; font-size: 40px; font-weight: bold; margin: 0; letter-spacing: 8px; font-family: 'Courier New', monospace;">${otp}</p>
                        </div>
                        
                        <div style="background-color: #fff3cd; border-left: 4px solid #ffc107; padding: 15px; margin: 20px 0;">
                            <p style="color: #856404; font-size: 13px; margin: 0;">
                                ⚠️ <strong>Sécurité:</strong> Seul l'utilisateur ou l'administrateur peut utiliser ce code pour réinitialiser le mot de passe.
                            </p>
                        </div>
                        
                        <hr style="border: none; border-top: 1px solid #ddd; margin: 30px 0;">
                        
                        <p style="color: #999; font-size: 12px; margin: 20px 0; text-align: center;">
                            © 2026 Ministère des Affaires Étrangères du Tchad
                        </p>
                    </div>
                </div>
            `
        };

        try {
            await transporter.sendMail(mailOptions);
            console.log(`✅ Password reset OTP sent to admin ${req.user.email} for user ${targetEmail}`);
            res.json({
                success: true,
                message: `Password reset OTP sent to your email for user: ${targetEmail}`
            });
        } catch (emailError) {
            console.log(`⚠️ Email failed, but OTP generated for ${targetEmail}: ${otp}`);
            res.json({
                success: true,
                message: 'OTP generated (email sending failed)',
                demoMode: true,
                demoOtp: otp,
                targetEmail: targetEmail
            });
        }
    } catch (error) {
        console.error('Error in admin password reset:', error.message);
        res.status(500).json({
            success: false,
            error: error.message
        });
    }
});

/**
 * Verify that admin can reset password for target user
 * GET /api/auth/admin/can-reset/:targetEmail
 * Headers: Authorization: Bearer <admin-token>
 */
app.get('/api/auth/admin/can-reset/:targetEmail', authenticateToken, async (req, res) => {
    try {
        const { targetEmail } = req.params;

        // req.user comes from the session-checked token (MySQL or users.json account)
        if (!req.user || req.user.role !== 'admin') {
            return res.status(403).json({
                success: false,
                error: 'Only admins can reset passwords'
            });
        }

        // Check if target user exists (same lookup as login)
        const targetUser = await findResetAccount(String(targetEmail).trim());
        if (!targetUser) {
            return res.status(404).json({
                success: false,
                error: 'Target user not found'
            });
        }

        res.json({
            success: true,
            canReset: true,
            targetUser: {
                email: targetUser.email,
                name: targetUser.name,
                role: targetUser.role
            }
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            error: error.message
        });
    }
});

// Start server
const server = app.listen(PORT, () => {
    console.log(`\n📗 Server running on port ${PORT}`);
    console.log(`📍 Frontend: ${process.env.FRONTEND_URL || 'Not set'}`);
    console.log(`🔧 Environment: ${process.env.NODE_ENV}`);
    console.log('✅ Server is ready to accept requests immediately\n');
});

// Backup archives can take several minutes to upload and restore.
server.timeout = 30 * 60 * 1000;

setupDailyDataBackup();

// Initialize services asynchronously without blocking
(async () => {
    // Connect to database
    const dbResult = await connectDB();
    if (dbResult.success) {
        console.log('[Services] ✅ Database connected');

        // Run data migration from JSON files to database
        try {
            const migration = new DataMigration({
                HomeContent,
                SyntheseActualite,
                Recrutement,
                LoiDecret,
                Mediatheque,
                ResourceDocument
            });
            await migration.runAll();
        } catch (error) {
            console.warn('[Services] ⚠️ Data migration error:', error.message);
        }
    } else {
        console.log('[Services] ℹ️  Running in JSON mode (no database)');
    }

    // Initialize admin
    try {
        await initializeAdminAccount(dbResult);
        console.log('[Services] ✅ Admin account initialized');
    } catch (error) {
        console.warn('[Services] ⚠️ Admin init error:', error.message);
    }

    // Initialize data sync (non-blocking)
    setTimeout(async () => {
        try {
            console.log('[Services] Initializing data sync...');
            await syncOnStartup();
            setupPeriodicSync();
            console.log('[Services] ✅ Data sync initialized');
        } catch (err) {
            console.warn('[Services] ⚠️ Data sync error:', err.message);
        }
    }, 1000);
})();
