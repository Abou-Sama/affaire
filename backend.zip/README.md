# Ministere Tchad Backend

Backend API for the Ministere Tchad website to make content management dynamic.

## Installation

```bash
cd backend
npm install
```

## Running the Server

```bash
npm start
```

For development with auto-restart:

```bash
npm run dev
```

The server will run on http://localhost:3002

## API Endpoints

### Home Contents
- `GET /api/home-contents` - Get all home contents
- `POST /api/home-contents` - Create new home content
- `PUT /api/home-contents/:id` - Update home content
- `DELETE /api/home-contents/:id` - Delete home content

### Lois et Decrets
- `GET /api/lois-decrets` - Get all documents
- `POST /api/lois-decrets` - Create new document
- `PUT /api/lois-decrets/:id` - Update document
- `DELETE /api/lois-decrets/:id` - Delete document

## Data Storage

Data is stored in JSON files in the `data/` directory:
- `homeContents.json` - Home page contents
- `loisDecrets.json` - Documents

## Deployment

To deploy, make sure to:
1. Start the backend server
2. Update the frontend API URLs if needed
3. Ensure CORS is properly configured for production

For production, consider using a database like MongoDB instead of JSON files.