const mongoose = require('mongoose');

/**
 * Video Schema for YouTube Videos
 * Stores official YouTube videos with ordering capability
 */
const videoSchema = new mongoose.Schema(
    {
        // YouTube video ID (extracted from URL)
        youtubeId: {
            type: String,
            required: true,
            unique: true,
            index: true,
            trim: true
        },

        // Video title (from YouTube oEmbed)
        title: {
            type: String,
            required: true,
            trim: true
        },

        // Position in the container (0 = top, determines display order)
        position: {
            type: Number,
            default: 0,
            index: true
        },

        // Date when video was added
        addedAt: {
            type: Date,
            default: Date.now,
            index: true
        }
    },
    {
        timestamps: true, // Adds createdAt and updatedAt
        collection: 'videos'
    }
);

// Indexes for optimal querying
videoSchema.index({ addedAt: -1 }); // For finding oldest videos

module.exports = mongoose.model('Video', videoSchema);
