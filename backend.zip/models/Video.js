const mongoose = require('mongoose');

/**
 * Video Schema
 * Stores YouTube videos fetched from the channel
 */
const videoSchema = new mongoose.Schema({
    // YouTube video ID (unique identifier)
    youtubeId: {
        type: String,
        required: true,
        unique: true,
        index: true
    },
    
    // Video title
    title: {
        type: String,
        required: true
    },
    
    // Video description
    description: {
        type: String,
        default: ''
    },
    
    // Publication date from YouTube
    publishedAt: {
        type: Date,
        required: true,
        index: true  // Index for sorting by date
    },
    
    // Thumbnail URL (high quality)
    thumbnailUrl: {
        type: String,
        required: true
    },
    
    // Full video URL (constructed from YouTube ID)
    videoUrl: {
        type: String,
        required: true
    },
    
    // Channel ID (for future use if needed)
    channelId: {
        type: String,
        default: ''
    },
    
    // Channel title
    channelTitle: {
        type: String,
        default: ''
    }
}, {
    timestamps: true  // Automatically adds createdAt and updatedAt
});

// Indexes
videoSchema.index({ publishedAt: -1 });  // For sorting by newest first
videoSchema.index({ youtubeId: 1 }, { unique: true });  // Ensure uniqueness

// Virtual property to get embed URL
videoSchema.virtual('embedUrl').get(function() {
    return `https://www.youtube.com/embed/${this.youtubeId}`;
});

// Ensure virtuals are included in JSON
videoSchema.set('toJSON', {
    virtuals: true
});

const Video = mongoose.model('Video', videoSchema);

module.exports = Video;
