const jwt = require('jsonwebtoken');
const crypto = require('crypto');
const { User } = require('../models-sequelize');
const logger = require('../config/logger');

/**
 * Authentication Service
 * Handles JWT token generation, validation, and refresh tokens
 */

class AuthService {
    /**
     * Generate Access Token (short-lived)
     * @param {Object} user - User object
     * @returns {String} JWT access token
     */
    static generateAccessToken(user) {
        const payload = {
            id: user._id || user.id,
            email: user.email,
            role: user.role,
            type: 'access'
        };

        return jwt.sign(
            payload,
            process.env.JWT_SECRET,
            {
                expiresIn: process.env.JWT_EXPIRES_IN || '15m',
                issuer: 'ministere-tchad',
                audience: 'ministere-tchad-api'
            }
        );
    }

    /**
     * Generate Refresh Token (long-lived)
     * @param {Object} user - User object
     * @returns {String} JWT refresh token
     */
    static generateRefreshToken(user) {
        const payload = {
            id: user._id || user.id,
            email: user.email,
            type: 'refresh',
            tokenId: crypto.randomBytes(16).toString('hex') // Unique token ID
        };

        return jwt.sign(
            payload,
            process.env.REFRESH_TOKEN_SECRET,
            {
                expiresIn: process.env.REFRESH_TOKEN_EXPIRES_IN || '7d',
                issuer: 'ministere-tchad',
                audience: 'ministere-tchad-api'
            }
        );
    }

    /**
     * Generate both access and refresh tokens
     * @param {Object} user - User object
     * @returns {Object} { accessToken, refreshToken }
     */
    static async generateTokens(user) {
        const accessToken = this.generateAccessToken(user);
        const refreshToken = this.generateRefreshToken(user);

        // Store refresh token in database
        try {
            const userDoc = await User.findById(user._id || user.id);
            if (userDoc) {
                userDoc.refreshTokens.push({
                    token: refreshToken,
                    createdAt: new Date()
                });

                // Limit to 5 refresh tokens per user
                if (userDoc.refreshTokens.length > 5) {
                    userDoc.refreshTokens = userDoc.refreshTokens.slice(-5);
                }

                await userDoc.save();
            }
        } catch (error) {
            logger.error('Error storing refresh token:', error);
        }

        return { accessToken, refreshToken };
    }

    /**
     * Verify Access Token
     * @param {String} token - JWT access token
     * @returns {Object} Decoded token payload
     */
    static verifyAccessToken(token) {
        try {
            return jwt.verify(token, process.env.JWT_SECRET, {
                issuer: 'ministere-tchad',
                audience: 'ministere-tchad-api'
            });
        } catch (error) {
            if (error.name === 'TokenExpiredError') {
                throw new Error('Access token expired');
            }
            if (error.name === 'JsonWebTokenError') {
                throw new Error('Invalid access token');
            }
            throw error;
        }
    }

    /**
     * Verify Refresh Token
     * @param {String} token - JWT refresh token
     * @returns {Object} Decoded token payload
     */
    static verifyRefreshToken(token) {
        try {
            return jwt.verify(token, process.env.REFRESH_TOKEN_SECRET, {
                issuer: 'ministere-tchad',
                audience: 'ministere-tchad-api'
            });
        } catch (error) {
            if (error.name === 'TokenExpiredError') {
                throw new Error('Refresh token expired');
            }
            if (error.name === 'JsonWebTokenError') {
                throw new Error('Invalid refresh token');
            }
            throw error;
        }
    }

    /**
     * Refresh access token using refresh token
     * @param {String} refreshToken - Refresh token
     * @returns {Object} { accessToken, refreshToken }
     */
    static async refreshAccessToken(refreshToken) {
        try {
            // Verify refresh token
            const decoded = this.verifyRefreshToken(refreshToken);

            // Check if refresh token exists in database
            const user = await User.findById(decoded.id).select('+refreshTokens');
            if (!user) {
                throw new Error('User not found');
            }

            const tokenExists = user.refreshTokens.some(rt => rt.token === refreshToken);
            if (!tokenExists) {
                logger.warn(`Invalid refresh token used for user: ${user.email}`);
                throw new Error('Invalid refresh token');
            }

            // Generate new tokens
            return await this.generateTokens(user);
        } catch (error) {
            logger.error('Token refresh error:', error);
            throw error;
        }
    }

    /**
     * Revoke refresh token
     * @param {String} userId - User ID
     * @param {String} refreshToken - Refresh token to revoke
     */
    static async revokeRefreshToken(userId, refreshToken) {
        try {
            const user = await User.findById(userId);
            if (user) {
                user.refreshTokens = user.refreshTokens.filter(rt => rt.token !== refreshToken);
                await user.save();
                logger.info(`Refresh token revoked for user: ${user.email}`);
            }
        } catch (error) {
            logger.error('Error revoking refresh token:', error);
            throw error;
        }
    }

    /**
     * Revoke all refresh tokens for a user
     * @param {String} userId - User ID
     */
    static async revokeAllRefreshTokens(userId) {
        try {
            const user = await User.findById(userId);
            if (user) {
                user.refreshTokens = [];
                await user.save();
                logger.info(`All refresh tokens revoked for user: ${user.email}`);
            }
        } catch (error) {
            logger.error('Error revoking all refresh tokens:', error);
            throw error;
        }
    }
}

module.exports = AuthService;
