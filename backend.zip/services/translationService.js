/**
 * Translation Service - automatically translates post text to all supported languages.
 * Long text is split into API-sized chunks while preserving source paragraph breaks.
 */

const fetch = (...args) => import('node-fetch').then(({ default: fetch }) => fetch(...args));

const SUPPORTED_LANGUAGES = {
    fr: 'French',
    en: 'English',
    ar: 'Arabic'
};

const LANGUAGE_CODES = {
    fr: 'fr',
    en: 'en',
    ar: 'ar'
};

const translationCache = new Map();
const CACHE_DURATION = 24 * 60 * 60 * 1000;
const MAX_CHUNK_SIZE = 450;

function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

function pushSizedText(chunks, value, maxSize) {
    const text = String(value || '').trim();
    if (!text) return;

    if (text.length <= maxSize) {
        chunks.push(text);
        return;
    }

    for (let i = 0; i < text.length; i += maxSize) {
        chunks.push(text.slice(i, i + maxSize));
    }
}

function splitParagraphIntoChunks(text, maxSize = MAX_CHUNK_SIZE) {
    const source = String(text || '').trim();
    if (!source) return [];

    const chunks = [];
    const sentences = source.split(/(?<=[.!?;:])\s+/).filter(Boolean);
    let current = '';

    const pushCurrent = () => {
        pushSizedText(chunks, current, maxSize);
        current = '';
    };

    for (const sentence of sentences) {
        if (sentence.length > maxSize) {
            pushCurrent();
            const words = sentence.split(/\s+/).filter(Boolean);

            for (const word of words) {
                if (word.length > maxSize) {
                    pushCurrent();
                    pushSizedText(chunks, word, maxSize);
                    continue;
                }

                if ((current + ' ' + word).trim().length > maxSize) {
                    pushCurrent();
                }
                current = `${current} ${word}`.trim();
            }
            continue;
        }

        if ((current + ' ' + sentence).trim().length > maxSize) {
            pushCurrent();
        }
        current = `${current} ${sentence}`.trim();
    }

    pushCurrent();
    return chunks;
}

function splitLongText(text, maxSize = MAX_CHUNK_SIZE) {
    const source = String(text || '').trim();
    if (!source) return [];

    return source
        .split(/\n{2,}/)
        .map(paragraph => splitParagraphIntoChunks(paragraph, maxSize))
        .filter(chunks => chunks.length > 0);
}

async function translateChunkWithRetry(text, targetLang, retries = 4) {
    const cacheKey = `fr|${targetLang}|${text}`;
    const cached = translationCache.get(cacheKey);
    if (cached && Date.now() - cached.timestamp < CACHE_DURATION) {
        return cached.translation;
    }

    for (let attempt = 1; attempt <= retries; attempt += 1) {
        try {
            const url = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=fr&tl=${LANGUAGE_CODES[targetLang]}&dt=t&q=${encodeURIComponent(text)}`;
            const controller = new AbortController();
            const timeoutId = setTimeout(() => controller.abort(), 20000);

            const response = await fetch(url, {
                method: 'GET',
                headers: { Accept: 'application/json' },
                signal: controller.signal
            });
            clearTimeout(timeoutId);

            const data = await response.json();
            const translation = Array.isArray(data?.[0])
                ? data[0].map(part => part?.[0] || '').join('')
                : '';

            if (response.ok && translation) {
                translationCache.set(cacheKey, { translation, timestamp: Date.now() });
                return translation;
            }

            console.warn(`[Translation] Google ${targetLang} attempt ${attempt} failed with status ${response.status}`);
        } catch (error) {
            console.warn(`[Translation] Google ${targetLang} attempt ${attempt} failed: ${error.message}`);
        }

        try {
            const url = `https://api.mymemory.translated.net/get?q=${encodeURIComponent(text)}&langpair=fr|${LANGUAGE_CODES[targetLang]}`;
            const response = await fetch(url, {
                method: 'GET',
                headers: { Accept: 'application/json' }
            });
            const data = await response.json();
            const translation = data?.responseData?.translatedText;

            if (response.ok && data.responseStatus === 200 && translation) {
                translationCache.set(cacheKey, { translation, timestamp: Date.now() });
                return translation;
            }

            console.warn(`[Translation] MyMemory ${targetLang} attempt ${attempt} failed with status ${response.status}/${data.responseStatus}`);
        } catch (error) {
            console.warn(`[Translation] MyMemory ${targetLang} attempt ${attempt} failed: ${error.message}`);
        }

        if (attempt < retries) {
            await sleep(attempt * 1000);
        }
    }

    throw new Error(`Unable to translate text to ${targetLang}`);
}

async function translateParagraph(chunks, targetLang, retries) {
    const translatedChunks = [];

    for (const chunk of chunks) {
        translatedChunks.push(await translateChunkWithRetry(chunk, targetLang, retries));
        await sleep(250);
    }

    return translatedChunks
        .map(chunk => String(chunk || '').trim())
        .filter(Boolean)
        .join(' ');
}

async function translateTextWithRetry(text, targetLang, retries = 4) {
    if (!text || !String(text).trim()) return '';
    if (targetLang === 'fr') return text;

    const paragraphs = splitLongText(text);
    const translatedParagraphs = [];

    for (const paragraphChunks of paragraphs) {
        translatedParagraphs.push(await translateParagraph(paragraphChunks, targetLang, retries));
    }

    return translatedParagraphs.join('\n\n');
}

async function updateLanguageVariants(post, existingVariants = []) {
    if (!post.title && !post.description && !post.content) {
        console.warn('[TranslationService] No text to translate');
        return existingVariants;
    }

    const variants = existingVariants || [];

    const enTitle = await translateTextWithRetry(post.title || '', 'en');
    const enDescription = await translateTextWithRetry(post.description || '', 'en');
    const enContent = await translateTextWithRetry(post.content || '', 'en');

    const arTitle = await translateTextWithRetry(post.title || '', 'ar');
    const arDescription = await translateTextWithRetry(post.description || '', 'ar');
    const arContent = await translateTextWithRetry(post.content || '', 'ar');

    const enVariant = {
        language: 'en',
        title: enTitle,
        description: enDescription,
        ...(enContent && { content: enContent })
    };

    const arVariant = {
        language: 'ar',
        title: arTitle,
        description: arDescription,
        ...(arContent && { content: arContent })
    };

    const enIndex = variants.findIndex(v => v.language === 'en');
    if (enIndex >= 0) variants[enIndex] = enVariant;
    else variants.push(enVariant);

    const arIndex = variants.findIndex(v => v.language === 'ar');
    if (arIndex >= 0) variants[arIndex] = arVariant;
    else variants.push(arVariant);

    return variants;
}

module.exports = {
    updateLanguageVariants,
    translateTextWithRetry,
    SUPPORTED_LANGUAGES,
    LANGUAGE_CODES
};
