const fs = require('fs');
const path = require('path');

const DATA_DIR = path.join(__dirname, '..', 'data');
const BACKUP_DIR = path.join(__dirname, '..', 'backups', 'data');
const KEEP_DAYS = Number(process.env.DATA_BACKUP_KEEP_DAYS || 30);
const CHECK_INTERVAL_MS = 6 * 60 * 60 * 1000;

// Runtime or cache files that do not need a copy
const SKIPPED_FILES = new Set([
    'sessions.json',
    'youtubeCache.json',
    'tweetsCache.json',
    'facebookCache.json',
    'instagramCache.json'
]);

function todayFolderName() {
    return new Date().toISOString().slice(0, 10);
}

function backupDataOnce() {
    const target = path.join(BACKUP_DIR, todayFolderName());
    if (fs.existsSync(target)) return false;

    fs.mkdirSync(target, { recursive: true });
    const files = fs.readdirSync(DATA_DIR).filter(file => file.endsWith('.json') && !SKIPPED_FILES.has(file));
    files.forEach(file => fs.copyFileSync(path.join(DATA_DIR, file), path.join(target, file)));
    console.log(`[DataBackup] Saved ${files.length} data file(s) to backups/data/${todayFolderName()}`);
    return true;
}

function pruneOldBackups() {
    if (!fs.existsSync(BACKUP_DIR)) return;
    const folders = fs.readdirSync(BACKUP_DIR).filter(name => /^\d{4}-\d{2}-\d{2}$/.test(name)).sort();
    folders.slice(0, Math.max(0, folders.length - KEEP_DAYS)).forEach(name => {
        fs.rmSync(path.join(BACKUP_DIR, name), { recursive: true, force: true });
    });
}

function runBackup() {
    try {
        backupDataOnce();
        pruneOldBackups();
    } catch (error) {
        console.error('[DataBackup] Backup failed:', error.message);
    }
}

// One copy per day of backend/data, kept for KEEP_DAYS days
function setupDailyDataBackup() {
    runBackup();
    const timer = setInterval(runBackup, CHECK_INTERVAL_MS);
    if (timer.unref) timer.unref();
}

module.exports = { setupDailyDataBackup, runBackup };
