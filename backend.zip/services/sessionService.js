const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const { writeJsonAtomic } = require('../utils/atomicJson');

const dataDir = path.join(__dirname, '../data');
const sessionsFile = path.join(dataDir, 'sessions.json');
const SESSION_IDLE_TIMEOUT_MS = 5 * 60 * 1000;

function ensureStore() {
    if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
    }

    if (!fs.existsSync(sessionsFile)) {
        fs.writeFileSync(sessionsFile, JSON.stringify({}, null, 2));
    }
}

function readSessions() {
    ensureStore();

    try {
        return JSON.parse(fs.readFileSync(sessionsFile, 'utf8') || '{}');
    } catch (error) {
        console.warn(`[Session] Could not read sessions: ${error.message}`);
        return {};
    }
}

function writeSessions(sessions) {
    ensureStore();
    writeJsonAtomic(sessionsFile, sessions);
}

function pruneExpiredSessions(sessions = readSessions()) {
    const now = Date.now();
    let changed = false;

    for (const [userId, session] of Object.entries(sessions)) {
        if (!session?.expiresAt || new Date(session.expiresAt).getTime() <= now) {
            delete sessions[userId];
            changed = true;
        }
    }

    if (changed) {
        writeSessions(sessions);
    }

    return sessions;
}

function getActiveSession(userId) {
    const sessions = pruneExpiredSessions();
    return sessions[String(userId)] || null;
}

function hasActiveSession(userId) {
    return Boolean(getActiveSession(userId));
}

function createSession(user) {
    const sessions = pruneExpiredSessions();
    const now = Date.now();
    const userId = String(user.id);
    const sessionId = crypto.randomBytes(32).toString('hex');

    sessions[userId] = {
        id: sessionId,
        userId,
        email: user.email,
        createdAt: new Date(now).toISOString(),
        lastSeenAt: new Date(now).toISOString(),
        expiresAt: new Date(now + SESSION_IDLE_TIMEOUT_MS).toISOString()
    };

    writeSessions(sessions);
    return sessions[userId];
}

function validateSession(userId, sessionId) {
    if (!userId || !sessionId) {
        return { valid: false, reason: 'missing_session' };
    }

    const sessions = pruneExpiredSessions();
    const session = sessions[String(userId)];

    if (!session || session.id !== sessionId) {
        return { valid: false, reason: 'session_not_active' };
    }

    const now = Date.now();
    if (new Date(session.expiresAt).getTime() <= now) {
        delete sessions[String(userId)];
        writeSessions(sessions);
        return { valid: false, reason: 'session_expired' };
    }

    session.lastSeenAt = new Date(now).toISOString();
    session.expiresAt = new Date(now + SESSION_IDLE_TIMEOUT_MS).toISOString();
    sessions[String(userId)] = session;
    writeSessions(sessions);

    return { valid: true, session };
}

function revokeSession(userId, sessionId) {
    const sessions = readSessions();
    const session = sessions[String(userId)];

    if (session && (!sessionId || session.id === sessionId)) {
        delete sessions[String(userId)];
        writeSessions(sessions);
    }
}

module.exports = {
    SESSION_IDLE_TIMEOUT_MS,
    createSession,
    hasActiveSession,
    validateSession,
    revokeSession,
    pruneExpiredSessions
};
