const fs = require('fs');
const path = require('path');
const fetch = require('node-fetch');

/**
 * Data Sync Service
 * Pre-fetches YouTube and Twitter data on server startup
 * and periodically refreshes it
 */

const DATA_DIR = path.join(__dirname, '../data');
const YOUTUBE_CACHE = path.join(DATA_DIR, 'youtubeCache.json');
const TWEETS_CACHE = path.join(DATA_DIR, 'tweetsCache.json');

// Ensure data directory exists
if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
}

/**
 * Fetch YouTube data via RSS
 */
async function syncYouTubeData() {
    try {
        console.log('[DataSync] 📺 Starting YouTube data sync...');

        const channel = 'TchadDiplomatie';
        const channelPageUrl = `https://www.youtube.com/@${channel}`;

        // Get channel ID from YouTube
        const channelPageResp = await fetch(channelPageUrl, {
            headers: {
                'User-Agent': 'Mozilla/5.0'
            },
            timeout: 15000
        });

        if (!channelPageResp.ok) {
            console.log('[DataSync] ⚠️ Could not fetch YouTube channel page');
            return false;
        }

        const channelHtml = await channelPageResp.text();
        const channelIdMatch = channelHtml.match(/\"externalId\":\"(UC[^\"]+)\"/);

        if (!channelIdMatch || !channelIdMatch[1]) {
            console.log('[DataSync] ⚠️ Could not extract YouTube channel ID');
            return false;
        }

        const channelId = channelIdMatch[1];

        // Fetch RSS feed
        const rssUrl = `https://www.youtube.com/feeds/videos.xml?channel_id=${channelId}`;
        const rssResp = await fetch(rssUrl, {
            headers: {
                'User-Agent': 'Mozilla/5.0'
            },
            timeout: 15000
        });

        if (!rssResp.ok) {
            console.log('[DataSync] ⚠️ Could not fetch YouTube RSS feed');
            return false;
        }

        const rssText = await rssResp.text();

        // Parse RSS (simplified version)
        const videos = [];
        const entryRegex = /<entry>([\s\S]*?)<\/entry>/g;
        let match;
        let count = 0;

        while ((match = entryRegex.exec(rssText)) && count < 12) {
            const entry = match[1];
            const idMatch = /yt:video:([a-zA-Z0-9_-]+)/.exec(entry);
            const titleMatch = /<media:title>([^<]+)<\/media:title>/.exec(entry);
            const descMatch = /<media:description>([^<]+)<\/media:description>/.exec(entry);
            const thumbMatch = /<media:thumbnail url='([^']+)'/.exec(entry);
            const publishMatch = /<published>([^<]+)<\/published>/.exec(entry);

            if (idMatch) {
                videos.push({
                    id: idMatch[1],
                    title: titleMatch ? titleMatch[1] : 'Untitled',
                    description: descMatch ? descMatch[1] : '',
                    thumbnail: thumbMatch ? thumbMatch[1] : `https://i.ytimg.com/vi/${idMatch[1]}/sddefault.jpg`,
                    link: `https://www.youtube.com/watch?v=${idMatch[1]}`,
                    publishedAt: publishMatch ? publishMatch[1] : new Date().toISOString(),
                    channelName: channel
                });
                count++;
            }
        }

        if (videos.length > 0) {
            fs.writeFileSync(YOUTUBE_CACHE, JSON.stringify({
                videos,
                timestamp: Date.now(),
                syncedAt: new Date().toISOString()
            }, null, 2));

            console.log(`[DataSync] ✅ YouTube sync successful (${videos.length} videos)`);
            return true;
        } else {
            console.log('[DataSync] ⚠️ No videos found in RSS feed');
            return false;
        }

    } catch (err) {
        console.error('[DataSync] ❌ YouTube sync failed:', err.message);
        return false;
    }
}

/**
 * Fetch Twitter/Nitter data
 */
async function syncTwitterData() {
    try {
        console.log('[DataSync] 🐦 Starting Twitter data sync...');

        const username = 'MAE_Tchad';
        const nitterInstances = [
            'https://nitter.net',
            'https://nitter.1d4.us',
            'https://nitter.kavin.rocks'
        ];

        for (const instance of nitterInstances) {
            try {
                const url = `${instance}/${username}/rss`;
                console.log(`[DataSync] Trying ${instance}...`);

                const res = await fetch(url, {
                    timeout: 15000,
                    headers: {
                        'User-Agent': 'Mozilla/5.0'
                    }
                });

                if (!res.ok) {
                    console.log(`[DataSync] ⚠️ ${instance} returned ${res.status}`);
                    continue;
                }

                const rssText = await res.text();

                // Parse tweets
                const tweets = [];
                const itemRegex = /<item>([\s\S]*?)<\/item>/g;
                let match;
                let count = 0;

                while ((match = itemRegex.exec(rssText)) && count < 15) {
                    const item = match[1];
                    const titleMatch = /<title>([\s\S]*?)<\/title>/.exec(item);
                    const linkMatch = /<link>([\s\S]*?)<\/link>/.exec(item);
                    const dateMatch = /<pubDate>([\s\S]*?)<\/pubDate>/.exec(item);

                    if (titleMatch) {
                        tweets.push({
                            id: Math.random().toString(36).slice(2),
                            text: titleMatch[1].trim(),
                            author: username,
                            date: dateMatch ? dateMatch[1] : new Date().toISOString(),
                            url: linkMatch ? linkMatch[1] : ''
                        });
                        count++;
                    }
                }

                if (tweets.length > 0) {
                    fs.writeFileSync(TWEETS_CACHE, JSON.stringify({
                        tweets,
                        timestamp: Date.now(),
                        source: instance,
                        syncedAt: new Date().toISOString()
                    }, null, 2));

                    console.log(`[DataSync] ✅ Twitter sync successful from ${instance} (${tweets.length} tweets)`);
                    return true;
                }

            } catch (err) {
                console.log(`[DataSync] ⚠️ ${instance} failed: ${err.message}`);
                continue;
            }
        }

        console.log('[DataSync] ⚠️ Could not sync from any Nitter instance');
        return false;

    } catch (err) {
        console.error('[DataSync] ❌ Twitter sync failed:', err.message);
        return false;
    }
}

/**
 * Run sync on startup
 */
async function syncOnStartup() {
    console.log('\n');
    console.log('═══════════════════════════════════════════');
    console.log('  Starting Data Sync Service');
    console.log('═══════════════════════════════════════════\n');

    const youtubeOk = await syncYouTubeData();
    const twitterOk = await syncTwitterData();

    console.log('\n═══════════════════════════════════════════');
    console.log(`  Sync Results: YouTube=${youtubeOk ? '✅' : '⚠️'} Twitter=${twitterOk ? '✅' : '⚠️'}`);
    console.log('═══════════════════════════════════════════\n');

    return { youtubeOk, twitterOk };
}

/**
 * Setup periodic sync (every 6 hours)
 */
function setupPeriodicSync() {
    const SIX_HOURS = 6 * 60 * 60 * 1000;

    setInterval(async () => {
        console.log('[DataSync] ⏰ Running periodic sync...');
        await syncYouTubeData();
        await syncTwitterData();
    }, SIX_HOURS);

    console.log('[DataSync] ⏰ Periodic sync scheduled every 6 hours');
}

module.exports = {
    syncOnStartup,
    setupPeriodicSync,
    syncYouTubeData,
    syncTwitterData
};