/**
 * Hybrid Authentication Service
 * Works with both SQL Database (Sequelize) and JSON files (fallback)
 * Perfect for Hostinger and other environments
 */

const fs = require('fs');
const path = require('path');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

const dataDir = path.join(__dirname, '../data');
const usersFile = path.join(dataDir, 'users.json');

function getJwtSecret() {
    const secret = process.env.JWT_SECRET || (process.env.NODE_ENV === 'production' ? undefined : 'your-secret-key-change-in-production');
    if (!secret) {
        throw new Error('JWT_SECRET is required');
    }

    return secret;
}

/**
 * Read users from JSON file
 */
function readUsersFromFile() {
    try {
        if (!fs.existsSync(usersFile)) {
            return [];
        }
        const data = fs.readFileSync(usersFile, 'utf8');
        return JSON.parse(data || '[]');
    } catch (error) {
        console.error('Error reading users file:', error);
        return [];
    }
}

/**
 * Write users to JSON file
 */
function writeUsersToFile(users) {
    try {
        if (!fs.existsSync(dataDir)) {
            fs.mkdirSync(dataDir, { recursive: true });
        }
        require('../utils/atomicJson').writeJsonAtomic(usersFile, users);
        return true;
    } catch (error) {
        console.error('Error writing users file:', error);
        return false;
    }
}

/**
 * Find user in database or JSON
 */
async function findUser(searchCriteria, useDatabase = true) {
    console.log('🔍 findUser called with:', searchCriteria);

    // Also log to file for debugging
    const fs = require('fs');
    const logMsg = `[${new Date().toISOString()}] findUser called with: ${JSON.stringify(searchCriteria)}\n`;
    try {
        fs.appendFileSync(path.join(__dirname, '../logs/auth.log'), logMsg);
    } catch (e) {
        // Ignore file logging errors
    }

    // Try database first if enabled
    if (useDatabase) {
        try {
            const { User } = require('../models-sequelize');
            if (User) {
                console.log('📊 Searching database...');
                if (searchCriteria.email) {
                    // Accounts created with an email typed as the username are matched on username too
                    const dbUser = await User.findOne({ where: { email: searchCriteria.email } })
                        || await User.findOne({ where: { username: searchCriteria.email } });
                    if (dbUser) {
                        console.log('✅ User found in database:', dbUser.email);
                        return dbUser;
                    }
                } else if (searchCriteria.username) {
                    // Search by username field
                    const dbUser = await User.findOne({ where: { username: searchCriteria.username } });
                    if (dbUser) {
                        console.log('✅ User found in database:', dbUser.username);
                        return dbUser;
                    }
                }
                console.log('❌ User not found in database, falling back to JSON');
            }
        } catch (dbError) {
            console.warn('⚠️  Database query failed, falling back to JSON:', dbError.message);
        }
    }

    // Fallback to JSON
    console.log('📄 Searching JSON file...');
    const users = readUsersFromFile();
    console.log('📄 Total users in file:', users.length);
    console.log('📄 Available users:', users.map(u => ({ username: u.username, email: u.email })));

    let foundUser = null;
    if (searchCriteria.email) {
        console.log('📄 Searching by email:', searchCriteria.email);
        const wanted = searchCriteria.email.toLowerCase();
        foundUser = users.find(u => u.email?.toLowerCase() === wanted)
            || users.find(u => u.username?.toLowerCase() === wanted);
    } else if (searchCriteria.username) {
        console.log('📄 Searching by username:', searchCriteria.username);
        foundUser = users.find(u =>
            u.username?.toLowerCase() === searchCriteria.username.toLowerCase() ||
            u.email?.toLowerCase() === searchCriteria.username.toLowerCase()
        );

        // Log detailed search info
        const logMsg = `[${new Date().toISOString()}] Searching for username: ${searchCriteria.username}\n`;
        const detailMsg = `Users checked: ${users.map(u => `${u.username}/${u.email}`).join(' | ')}\n`;
        const foundMsg = `Found: ${foundUser ? 'YES' : 'NO'}\n---\n`;
        try {
            fs.appendFileSync(path.join(__dirname, '../logs/auth.log'), logMsg + detailMsg + foundMsg);
        } catch (e) {
            // Ignore
        }

        if (!foundUser) {
            console.log('📄 Search details:');
            users.forEach(u => {
                console.log(`  - User: ${u.username} / ${u.email}`);
                console.log(`    Matches username? ${u.username?.toLowerCase()} === ${searchCriteria.username.toLowerCase()} = ${u.username?.toLowerCase() === searchCriteria.username.toLowerCase()}`);
                console.log(`    Matches email? ${u.email?.toLowerCase()} === ${searchCriteria.username.toLowerCase()} = ${u.email?.toLowerCase() === searchCriteria.username.toLowerCase()}`);
            });
        }
    }

    if (foundUser) {
        console.log('✅ User found in JSON:', foundUser.email || foundUser.username);
    } else {
        console.log('❌ User not found in JSON');
    }

    return foundUser;
}

/**
 * Create user in database or JSON
 */
async function createUser(userData, useDatabase = true) {
    // Hash password
    const salt = await bcrypt.genSalt(12);
    const hashedPassword = await bcrypt.hash(userData.password, salt);

    const newUser = {
        id: userData.id || 'user-' + Date.now(),
        email: userData.email.toLowerCase(),
        name: userData.name,
        password: hashedPassword,
        role: userData.role || 'user',
        status: userData.status || 'active',
        permissions: userData.permissions || {},
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
    };

    // Try database first if enabled
    if (useDatabase) {
        try {
            const { User } = require('../models-sequelize');
            if (User) {
                return await User.create({
                    email: newUser.email,
                    name: newUser.name,
                    password: userData.password, // Will be hashed by beforeCreate hook
                    role: newUser.role,
                    status: newUser.status,
                    permissions: newUser.permissions
                });
            }
        } catch (dbError) {
            console.warn('Database create failed, falling back to JSON:', dbError.message);
        }
    }

    // Fallback to JSON
    const users = readUsersFromFile();
    users.push(newUser);
    writeUsersToFile(users);
    return newUser;
}

/**
 * Compare password
 */
async function comparePassword(plainPassword, hashedPassword) {
    try {
        console.log('🔑 Comparing password...');
        if (!hashedPassword) {
            console.error('❌ No hashed password found');
            return false;
        }
        const result = await bcrypt.compare(plainPassword, hashedPassword);
        if (result) {
            console.log('✅ Password matches');
        } else {
            console.log('❌ Password does not match');
        }
        return result;
    } catch (error) {
        console.error('❌ Password comparison error:', error.message);
        throw new Error('Password comparison failed');
    }
}

/**
 * Generate JWT tokens
 */
function generateTokens(user, sessionId = null) {
    console.log('🎟️  Generating JWT tokens for user:', user?.email || 'unknown');

    if (!user || !user.id || !user.email) {
        console.error('❌ Invalid user data for token generation:', user);
        throw new Error('Invalid user data for token generation');
    }

    const effectiveSessionId = sessionId || `session-${Date.now()}-${Math.random().toString(16).slice(2)}`;
    const jwtSecret = getJwtSecret();

    const accessToken = jwt.sign(
        {
            id: user.id,
            email: user.email,
            role: user.role,
            sid: effectiveSessionId
        },
        jwtSecret,
        { expiresIn: '8h' }
    );

    console.log('✅ Access token generated');

    const refreshToken = jwt.sign(
        {
            id: user.id,
            email: user.email,
            type: 'refresh',
            sid: effectiveSessionId
        },
        jwtSecret,
        { expiresIn: '8h' }
    );

    console.log('✅ Refresh token generated');

    return { accessToken, refreshToken };
}

/**
 * Verify JWT token
 */
function verifyToken(token) {
    try {
        return jwt.verify(token, getJwtSecret());
    } catch (error) {
        throw new Error('Invalid token');
    }
}

/**
 * User to JSON representation
 */
function userToJSON(user) {
    console.log('👤 Converting user to JSON...');

    if (!user) {
        console.error('❌ User is null or undefined');
        return null;
    }

    // Handle Sequelize model instances
    const obj = user.toJSON ? user.toJSON() : user;

    if (!obj) {
        console.error('❌ Failed to convert user object');
        return null;
    }

    // Remove sensitive data and hidden admin fields
    delete obj.password;
    delete obj.passwordResetToken;
    delete obj.passwordResetExpires;
    delete obj.adminEmail;  // Hide admin email from regular users

    console.log('✅ User converted, returning:', { id: obj.id, email: obj.email, role: obj.role });

    return obj;
}

/**
 * Update user in database or JSON file
 */
async function updateUser(userEmail, updates, useDatabase = true) {
    // Try database first if enabled
    if (useDatabase) {
        try {
            const { User } = require('../models-sequelize');
            if (User) {
                const user = await User.findOne({ where: { email: userEmail } });
                if (user) {
                    // Pass the plain password: the model's beforeUpdate hook hashes it.
                    // Hashing here too stored hash(hash(password)) and locked the account out.
                    await user.update({ ...updates });
                    console.log(`✅ User updated in database: ${userEmail}`);
                    return user;
                }
            }
        } catch (dbError) {
            console.warn('⚠️  Database update failed, falling back to JSON:', dbError.message);
        }
    }

    // Fallback to JSON
    const users = readUsersFromFile();
    const userIndex = users.findIndex(u => u.email?.toLowerCase() === userEmail.toLowerCase());

    if (userIndex === -1) {
        throw new Error('User not found');
    }

    // Hash password if it's being updated (JSON has no model hook)
    const jsonUpdates = { ...updates };
    if (jsonUpdates.password) {
        jsonUpdates.password = await bcrypt.hash(jsonUpdates.password, 12);
    }

    // Update user
    users[userIndex] = { ...users[userIndex], ...jsonUpdates };
    writeUsersToFile(users);
    console.log(`✅ User updated in JSON file: ${userEmail}`);
    return users[userIndex];
}

module.exports = {
    findUser,
    createUser,
    comparePassword,
    generateTokens,
    verifyToken,
    userToJSON,
    readUsersFromFile,
    writeUsersToFile,
    updateUser
};
