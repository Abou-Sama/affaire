const fs = require('fs').promises;
const path = require('path');

/**
 * Automatic Data Migration Service
 * Migrates data from JSON files to MySQL database on first connection
 */

class DataMigration {
    constructor(models) {
        this.models = models;
        this.dataDir = path.join(__dirname, '../data');
    }

    /**
     * Read JSON file safely
     */
    async readJsonFile(filename) {
        try {
            const filepath = path.join(this.dataDir, filename);
            const data = await fs.readFile(filepath, 'utf-8');
            return JSON.parse(data || '[]');
        } catch (error) {
            console.warn(`[Migration] Could not read ${filename}:`, error.message);
            return [];
        }
    }

    /**
     * Migrate HomeContents from JSON to database
     */
    async migrateHomeContents() {
        try {
            const homeContents = await this.readJsonFile('homeContents.json');

            if (!homeContents || homeContents.length === 0) {
                console.log('[Migration] No home contents to migrate');
                return;
            }

            // Check if data already exists
            const count = await this.models.HomeContent.count();
            if (count > 0) {
                console.log(`[Migration] ✅ HomeContent already migrated (${count} records)`);
                return;
            }

            // Migrate each record
            for (const item of homeContents) {
                await this.models.HomeContent.findOrCreate({
                    where: { id: item.id },
                    defaults: {
                        id: item.id,
                        type: item.type || 'text',
                        title: item.title,
                        description: item.description || '',
                        content: item.content,
                        publishDate: item.publishDate ? new Date(item.publishDate) : new Date(),
                        active: item.active !== undefined ? item.active : true
                    }
                });
            }

            console.log(`[Migration] ✅ Migrated ${homeContents.length} home contents`);
        } catch (error) {
            console.error('[Migration] Error migrating home contents:', error.message);
        }
    }

    /**
     * Migrate SyntheseActualite from JSON to database
     */
    async migrateSyntheseActualite() {
        try {
            const syntheseItems = await this.readJsonFile('syntheseActualite.json');

            if (!syntheseItems || syntheseItems.length === 0) {
                console.log('[Migration] No synthese items to migrate');
                return;
            }

            // Check if data already exists
            const count = await this.models.SyntheseActualite.count();
            if (count > 0) {
                console.log(`[Migration] ✅ SyntheseActualite already migrated (${count} records)`);
                return;
            }

            // Migrate each record
            for (const item of syntheseItems) {
                await this.models.SyntheseActualite.findOrCreate({
                    where: { id: item.id },
                    defaults: {
                        id: item.id,
                        type: item.type || 'text',
                        title: item.title,
                        description: item.description || '',
                        content: item.content,
                        publishDate: item.publishDate ? new Date(item.publishDate) : new Date(),
                        active: item.active !== undefined ? item.active : true
                    }
                });
            }

            console.log(`[Migration] ✅ Migrated ${syntheseItems.length} synthese items`);
        } catch (error) {
            console.error('[Migration] Error migrating synthese items:', error.message);
        }
    }

    /**
     * Migrate Recrutement from JSON to database
     */
    async migrateRecrutement() {
        try {
            const recrutementItems = await this.readJsonFile('recrutement.json');

            if (!recrutementItems || recrutementItems.length === 0) {
                console.log('[Migration] No recrutement items to migrate');
                return;
            }

            // Check if data already exists
            const count = await this.models.Recrutement.count();
            if (count > 0) {
                console.log(`[Migration] ✅ Recrutement already migrated (${count} records)`);
                return;
            }

            // Migrate each record
            for (const item of recrutementItems) {
                await this.models.Recrutement.findOrCreate({
                    where: { id: item.id },
                    defaults: {
                        id: item.id,
                        title: item.title,
                        description: item.description || '',
                        position: item.position || '',
                        department: item.department,
                        location: item.location,
                        salary: item.salary,
                        contractType: item.contractType,
                        deadline: item.deadline ? new Date(item.deadline) : null,
                        publishDate: item.publishDate ? new Date(item.publishDate) : new Date(),
                        active: item.active !== undefined ? item.active : true
                    }
                });
            }

            console.log(`[Migration] ✅ Migrated ${recrutementItems.length} recrutement items`);
        } catch (error) {
            console.error('[Migration] Error migrating recrutement items:', error.message);
        }
    }

    /**
     * Migrate LoiDecret from JSON to database
     */
    async migrateLoiDecret() {
        try {
            const loiItems = await this.readJsonFile('loisDecrets.json');

            if (!loiItems || loiItems.length === 0) {
                console.log('[Migration] No lois/decrets to migrate');
                return;
            }

            // Check if data already exists
            const count = await this.models.LoiDecret.count();
            if (count > 0) {
                console.log(`[Migration] ✅ LoiDecret already migrated (${count} records)`);
                return;
            }

            // Migrate each record
            for (const item of loiItems) {
                await this.models.LoiDecret.findOrCreate({
                    where: { id: item.id },
                    defaults: {
                        id: item.id,
                        title: item.title,
                        description: item.description,
                        content: item.content,
                        documentUrl: item.documentUrl,
                        documentDate: item.documentDate ? new Date(item.documentDate) : null,
                        publishDate: item.publishDate ? new Date(item.publishDate) : new Date(),
                        category: item.category,
                        active: item.active !== undefined ? item.active : true
                    }
                });
            }

            console.log(`[Migration] ✅ Migrated ${loiItems.length} lois/decrets`);
        } catch (error) {
            console.error('[Migration] Error migrating lois/decrets:', error.message);
        }
    }

    /**
     * Migrate Mediatheque from JSON to database
     */
    async migrateMediatheque() {
        try {
            const mediaItems = await this.readJsonFile('mediatheque.json');

            if (!mediaItems || mediaItems.length === 0) {
                console.log('[Migration] No mediatheque items to migrate');
                return;
            }

            // Check if data already exists
            const count = await this.models.Mediatheque.count();
            if (count > 0) {
                console.log(`[Migration] ✅ Mediatheque already migrated (${count} records)`);
                return;
            }

            // Migrate each record
            for (const item of mediaItems) {
                await this.models.Mediatheque.findOrCreate({
                    where: { id: item.id },
                    defaults: {
                        id: item.id,
                        title: item.title,
                        description: item.description,
                        mediaType: item.mediaType || 'document',
                        fileUrl: item.fileUrl,
                        fileName: item.fileName,
                        fileSize: item.fileSize,
                        category: item.category,
                        uploadDate: item.uploadDate ? new Date(item.uploadDate) : new Date(),
                        active: true
                    }
                });
            }

            console.log(`[Migration] ✅ Migrated ${mediaItems.length} mediatheque items`);
        } catch (error) {
            console.error('[Migration] Error migrating mediatheque:', error.message);
        }
    }

    /**
     * Migrate ResourceDocuments from JSON to database
     */
    async migrateResourceDocuments() {
        try {
            const docItems = await this.readJsonFile('resourceDocuments.json');

            if (!docItems || docItems.length === 0) {
                console.log('[Migration] No resource documents to migrate');
                return;
            }

            // Check if data already exists
            const count = await this.models.ResourceDocument.count();
            if (count > 0) {
                console.log(`[Migration] ✅ ResourceDocuments already migrated (${count} records)`);
                return;
            }

            // Migrate each record
            for (const item of docItems) {
                await this.models.ResourceDocument.findOrCreate({
                    where: { id: item.id },
                    defaults: {
                        id: item.id,
                        title: item.title,
                        description: item.description,
                        category: item.category,
                        fileUrl: item.fileUrl,
                        fileName: item.fileName,
                        fileSize: item.fileSize,
                        uploadDate: item.uploadDate ? new Date(item.uploadDate) : new Date(),
                        active: true
                    }
                });
            }

            console.log(`[Migration] ✅ Migrated ${docItems.length} resource documents`);
        } catch (error) {
            console.error('[Migration] Error migrating resource documents:', error.message);
        }
    }

    /**
     * Run all migrations
     */
    async runAll() {
        console.log('\n[Migration] 🔄 Starting automatic data migration...\n');

        await this.migrateHomeContents();
        await this.migrateSyntheseActualite();
        await this.migrateRecrutement();
        await this.migrateLoiDecret();
        await this.migrateMediatheque();
        await this.migrateResourceDocuments();

        console.log('[Migration] ✅ Data migration completed\n');
    }
}

module.exports = DataMigration;
