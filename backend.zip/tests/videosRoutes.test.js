const assert = require('assert');
const path = require('path');
const fs = require('fs');

const videosRoutes = require('../api/videosRoutes');

function createApp() {
  const express = require('express');
  const app = express();
  app.use(express.json());
  app.use('/api/videos', videosRoutes);
  return app;
}

(async () => {
  const app = createApp();
  const server = app.listen(0, async () => {
    const { port } = server.address();
    const http = require('http');

    const req = http.request({
      hostname: '127.0.0.1',
      port,
      path: '/api/videos',
      method: 'GET'
    }, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        try {
          const body = JSON.parse(data);
          assert.strictEqual(res.statusCode, 200);
          assert.ok(body.success === true);
          assert.ok(Array.isArray(body.data));
          console.log('videos route regression test passed');
        } catch (error) {
          console.error(error);
          process.exitCode = 1;
        } finally {
          server.close();
        }
      });
    });

    req.on('error', (error) => {
      console.error(error);
      process.exitCode = 1;
      server.close();
    });

    req.end();
  });
})();
