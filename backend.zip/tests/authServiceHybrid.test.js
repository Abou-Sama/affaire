const test = require('node:test');
const assert = require('node:assert/strict');

const authServiceHybrid = require('../services/authServiceHybrid');

test('generateTokens works without an explicit session id', () => {
  const user = {
    id: 'user-1',
    email: 'admin@example.com',
    role: 'admin'
  };

  const { accessToken, refreshToken } = authServiceHybrid.generateTokens(user);

  assert.ok(accessToken, 'access token should be generated');
  assert.ok(refreshToken, 'refresh token should be generated');
});
