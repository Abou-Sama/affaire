const test = require('node:test');
const assert = require('node:assert/strict');
const { sanitizeText, sanitizeHtmlContent } = require('../utils/sanitizeContent');

test('sanitizeText strips script tags and HTML', () => {
  const input = '<script>alert(1)</script> Hello <b>world</b>!';
  const result = sanitizeText(input);
  assert.equal(result, 'Hello world!');
});

test('sanitizeHtmlContent preserves safe formatting and removes dangerous attributes', () => {
  const input = '<p onclick="alert(1)">Hello <strong>world</strong></p><a href="javascript:alert(1)" target="_blank">link</a><script>alert(1)</script>';
  const result = sanitizeHtmlContent(input);
  assert.equal(result, '<p>Hello <strong>world</strong></p><a>link</a>');
});
