const { User } = require('../models-sequelize');
const logger = require('../config/logger');

/**
 * User Controller
 * Handles user management operations (admin only)
 */

/**
 * Get all users
 * GET /api/users
 */
exports.getAllUsers = async (req, res, next) => {
    try {
        const { page = 1, limit = 10, role, status, search } = req.query;

        // Build query
        const query = {};

        if (role) query.role = role;
        if (status) query.status = status;
        if (search) {
            query.$or = [
                { name: { $regex: search, $options: 'i' } },
                { email: { $regex: search, $options: 'i' } }
            ];
        }

        // Execute query with pagination
        const users = await User.find(query)
            .select('-password -refreshTokens')
            .limit(limit * 1)
            .skip((page - 1) * limit)
            .sort({ createdAt: -1 });

        // Get total count
        const count = await User.countDocuments(query);

        res.json({
            success: true,
            data: {
                users,
                totalPages: Math.ceil(count / limit),
                currentPage: page,
                total: count
            }
        });
    } catch (error) {
        next(error);
    }
};

/**
 * Get user by ID
 * GET /api/users/:id
 */
exports.getUserById = async (req, res, next) => {
    try {
        const user = await User.findById(req.params.id).select('-password -refreshTokens');

        if (!user) {
            return res.status(404).json({
                success: false,
                error: 'User not found'
            });
        }

        res.json({
            success: true,
            data: { user }
        });
    } catch (error) {
        next(error);
    }
};

/**
 * Create new user (admin only)
 * POST /api/users
 */
exports.createUser = async (req, res, next) => {
    try {
        const { email, name, password, role, permissions } = req.body;

        // Check if user already exists
        const existingUser = await User.findOne({ email });
        if (existingUser) {
            return res.status(400).json({
                success: false,
                error: 'Email already registered'
            });
        }

        // Validate password strength
        const passwordValidation = User.validatePasswordStrength(password);
        if (!passwordValidation.valid) {
            return res.status(400).json({
                success: false,
                error: 'Password does not meet requirements',
                details: passwordValidation.errors
            });
        }

        // Create user
        const user = await User.create({
            email,
            name,
            password,
            role: role || 'user',
            permissions: permissions || {},
            status: 'active'
        });

        logger.info(`New user created by admin: ${email}`, { by: req.user.email });

        res.status(201).json({
            success: true,
            message: 'User created successfully',
            data: { user: user.toJSON() }
        });
    } catch (error) {
        next(error);
    }
};

/**
 * Update user
 * PUT /api/users/:id
 */
exports.updateUser = async (req, res, next) => {
    try {
        const { name, email, role, status, permissions } = req.body;

        const user = await User.findById(req.params.id);
        if (!user) {
            return res.status(404).json({
                success: false,
                error: 'User not found'
            });
        }

        // Prevent admin from changing their own role
        if (req.user.id === user.id.toString() && role && role !== user.role) {
            return res.status(400).json({
                success: false,
                error: 'Cannot change your own role'
            });
        }

        // Check if new email is already taken
        if (email && email !== user.email) {
            const emailExists = await User.findOne({ email });
            if (emailExists) {
                return res.status(400).json({
                    success: false,
                    error: 'Email already in use'
                });
            }
            user.email = email;
        }

        // Update fields
        if (name) user.name = name;
        if (role) user.role = role;
        if (status) user.status = status;
        if (permissions) user.permissions = new Map(Object.entries(permissions));

        await user.save();

        logger.info(`User updated by admin: ${user.email}`, { by: req.user.email });

        res.json({
            success: true,
            message: 'User updated successfully',
            data: { user: user.toJSON() }
        });
    } catch (error) {
        next(error);
    }
};

/**
 * Delete user
 * DELETE /api/users/:id
 */
exports.deleteUser = async (req, res, next) => {
    try {
        const user = await User.findById(req.params.id);

        if (!user) {
            return res.status(404).json({
                success: false,
                error: 'User not found'
            });
        }

        // Prevent admin from deleting themselves
        if (req.user.id === user.id.toString()) {
            return res.status(400).json({
                success: false,
                error: 'Cannot delete your own account'
            });
        }

        await User.findByIdAndDelete(req.params.id);

        logger.warn(`User deleted by admin: ${user.email}`, { by: req.user.email });

        res.json({
            success: true,
            message: 'User deleted successfully'
        });
    } catch (error) {
        next(error);
    }
};

/**
 * Get user statistics
 * GET /api/users/stats
 */
exports.getUserStats = async (req, res, next) => {
    try {
        const totalUsers = await User.countDocuments();
        const activeUsers = await User.countDocuments({ status: 'active' });
        const pendingUsers = await User.countDocuments({ status: 'pending' });
        const suspendedUsers = await User.countDocuments({ status: 'suspended' });

        const usersByRole = await User.aggregate([
            { $group: { _id: '$role', count: { $sum: 1 } } }
        ]);

        res.json({
            success: true,
            data: {
                total: totalUsers,
                active: activeUsers,
                pending: pendingUsers,
                suspended: suspendedUsers,
                byRole: usersByRole
            }
        });
    } catch (error) {
        next(error);
    }
};
