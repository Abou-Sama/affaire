const { User } = require('../models-sequelize');
const AuthService = require('../services/authService');
const logger = require('../config/logger');
const fs = require('fs');
const path = require('path');
const bcrypt = require('bcrypt');

/**
 * Authentication Controller
 * Handles user authentication operations
 */

// Helper functions for JSON fallback
const readUsers = () => {
    try {
        const dataDir = path.join(__dirname, '../data');
        const usersFile = path.join(dataDir, 'users.json');
        const data = fs.readFileSync(usersFile, 'utf8');
        return JSON.parse(data);
    } catch (error) {
        logger.error('Error reading users file:', error);
        return [];
    }
};

/**
 * Register/Signup new user
 * POST /api/auth/signup
 * DISABLED - Users are created by admin only
 */
exports.signup = async (req, res, next) => {
    try {
        return res.status(403).json({
            success: false,
            error: 'User registration is disabled. Only administrators can create users.'
        });
    } catch (error) {
        next(error);
    }
};

/**
 * Login user
 * POST /api/auth/login
 * Accepts: { username, password }
 */
exports.login = async (req, res, next) => {
    try {
        const { username, password } = req.body;

        if (!username || !password) {
            return res.status(400).json({
                success: false,
                error: 'Username and password are required'
            });
        }

        let user = null;
        let fromDatabase = true;

        // Try to find user in database first
        try {
            user = await User.findOne({ where: { username: username.toLowerCase() } });
        } catch (dbError) {
            logger.warn('Database query failed, checking JSON fallback:', dbError.message);
        }

        // If not found in database, try JSON fallback
        if (!user) {
            fromDatabase = false;
            const users = readUsers();
            console.log('[DEBUG] Searching JSON. Input email/username:', username, 'Lowercase:', username.toLowerCase());
            console.log('[DEBUG] Available users:', users.map(u => ({ username: u.username, email: u.email })));
            // Search by username OR email (handle both formats)
            const jsonUser = users.find(u =>
                (u.username && u.username === username.toLowerCase()) ||
                (u.email && u.email === username.toLowerCase())
            );
            console.log('[DEBUG] Found jsonUser:', jsonUser ? { id: jsonUser.id, username: jsonUser.username, email: jsonUser.email } : 'NOT FOUND');

            if (!jsonUser) {
                logger.warn(`Login attempt for non-existent username: ${username}`);
                return res.status(401).json({
                    success: false,
                    error: 'Invalid username or password'
                });
            }

            // Verify password against hashed password in JSON
            try {
                const passwordMatch = await bcrypt.compare(password, jsonUser.password);
                console.log('[DEBUG] Password match result:', passwordMatch);
                if (!passwordMatch) {
                    logger.warn(`Failed login attempt for user: ${username}`);
                    return res.status(401).json({
                        success: false,
                        error: 'Invalid username or password'
                    });
                }
            } catch (compareError) {
                logger.error(`Password comparison error for user ${username}:`, compareError);
                return res.status(500).json({
                    success: false,
                    error: 'Authentication service error'
                });
            }

            // Convert JSON user to format compatible with token generation
            user = {
                id: jsonUser.id,
                username: jsonUser.username,
                email: jsonUser.email || `${jsonUser.username}@internal.ministere.td`,
                name: jsonUser.name || jsonUser.username,
                role: jsonUser.role || 'user',
                status: jsonUser.status || 'active',
                toJSON: function () {
                    return {
                        id: this.id,
                        username: this.username,
                        email: this.email,
                        name: this.name,
                        role: this.role,
                        status: this.status
                    };
                }
            };
        } else {
            // User from database
            // Check if account is locked
            if (user.isAccountLocked && user.isAccountLocked()) {
                logger.warn(`Login attempt for locked account: ${username}`);
                return res.status(403).json({
                    success: false,
                    error: 'Account is locked due to too many failed login attempts. Please try again later.'
                });
            }

            // Verify password
            let isPasswordCorrect;
            try {
                isPasswordCorrect = await user.comparePassword(password);
            } catch (compareError) {
                logger.error(`Password comparison error for user ${username}:`, compareError);
                return res.status(500).json({
                    success: false,
                    error: 'Authentication service error'
                });
            }

            if (!isPasswordCorrect) {
                // Increment failed attempts
                await user.incrementFailedAttempts();
                logger.warn(`Failed login attempt for user: ${username}`);

                return res.status(401).json({
                    success: false,
                    error: 'Invalid username or password'
                });
            }

            // Reset failed attempts on successful login
            await user.resetFailedAttempts();

            // Update last login
            user.lastLogin = new Date();
            await user.save();
        }

        // Generate tokens
        const { accessToken, refreshToken } = await AuthService.generateTokens(user);

        // Set refresh token in HTTP-only cookie
        res.cookie('refreshToken', refreshToken, {
            httpOnly: true,
            secure: process.env.NODE_ENV === 'production',
            sameSite: 'strict',
            maxAge: 7 * 24 * 60 * 60 * 1000
        });

        logger.info(`User logged in: ${username}`);

        res.json({
            success: true,
            message: 'Login successful',
            data: {
                user: user.toJSON(),
                accessToken,
                refreshToken
            }
        });
    } catch (error) {
        logger.error('Login error:', error);
        next(error);
    }
};

/**
 * Refresh access token
 * POST /api/auth/refresh
 */
exports.refreshToken = async (req, res, next) => {
    try {
        // Get refresh token from cookie or body
        const refreshToken = req.cookies.refreshToken || req.body.refreshToken;

        if (!refreshToken) {
            return res.status(401).json({
                success: false,
                error: 'Refresh token required'
            });
        }

        // Refresh tokens
        const tokens = await AuthService.refreshAccessToken(refreshToken);

        // Set new refresh token in cookie
        res.cookie('refreshToken', tokens.refreshToken, {
            httpOnly: true,
            secure: process.env.NODE_ENV === 'production',
            sameSite: 'strict',
            maxAge: 7 * 24 * 60 * 60 * 1000
        });

        res.json({
            success: true,
            message: 'Token refreshed successfully',
            data: {
                accessToken: tokens.accessToken,
                refreshToken: tokens.refreshToken
            }
        });
    } catch (error) {
        // Clear invalid refresh token cookie
        res.clearCookie('refreshToken');

        next(error);
    }
};

/**
 * Logout user
 * POST /api/auth/logout
 */
exports.logout = async (req, res, next) => {
    try {
        const refreshToken = req.cookies.refreshToken || req.body.refreshToken;

        if (refreshToken && req.user) {
            // Revoke refresh token
            await AuthService.revokeRefreshToken(req.user.id, refreshToken);
        }

        // Clear refresh token cookie
        res.clearCookie('refreshToken');

        logger.info(`User logged out: ${req.user?.email || 'unknown'}`);

        res.json({
            success: true,
            message: 'Logout successful'
        });
    } catch (error) {
        next(error);
    }
};

/**
 * Change password (user changes their own password)
 * POST /api/auth/change-password
 */
exports.changePassword = async (req, res, next) => {
    try {
        const { currentPassword, newPassword } = req.body;

        if (!currentPassword || !newPassword) {
            return res.status(400).json({
                success: false,
                error: 'Current password and new password are required'
            });
        }

        // Get user
        const user = await User.findByPk(req.user.id);
        if (!user) {
            return res.status(404).json({
                success: false,
                error: 'User not found'
            });
        }

        // Verify current password
        const isCurrentPasswordCorrect = await user.comparePassword(currentPassword);
        if (!isCurrentPasswordCorrect) {
            return res.status(401).json({
                success: false,
                error: 'Current password is incorrect'
            });
        }

        // Validate new password
        if (newPassword.length < 8) {
            return res.status(400).json({
                success: false,
                error: 'New password must be at least 8 characters'
            });
        }

        // Update password (will be hashed by beforeUpdate hook)
        user.password = newPassword;
        await user.save();

        logger.info(`Password changed for user: ${user.username}`);

        res.json({
            success: true,
            message: 'Password changed successfully'
        });
    } catch (error) {
        logger.error(`Password change error for user ${req.user?.id}:`, error);
        next(error);
    }
};

/**
 * Reset password (without old password) - DISABLED for regular users
 * POST /api/auth/reset-password
 * Only admins can reset passwords via /api/users/:id/reset-password
 */
exports.resetPassword = async (req, res, next) => {
    try {
        return res.status(403).json({
            success: false,
            error: 'Password reset is not available. Please contact an administrator to reset your password.'
        });
    } catch (error) {
        next(error);
    }
};

/**
 * Get current user profile
 * GET /api/auth/profile
 */
exports.getProfile = async (req, res, next) => {
    try {
        const user = await User.findById(req.user.id);

        if (!user) {
            return res.status(404).json({
                success: false,
                error: 'User not found'
            });
        }

        res.json({
            success: true,
            data: { user: user.toJSON() }
        });
    } catch (error) {
        next(error);
    }
};

/**
 * Update user profile
 * PUT /api/auth/profile
 */
exports.updateProfile = async (req, res, next) => {
    try {
        const { name, email } = req.body;

        const user = await User.findById(req.user.id);
        if (!user) {
            return res.status(404).json({
                success: false,
                error: 'User not found'
            });
        }

        // Check if email is already taken
        if (email && email !== user.email) {
            const emailExists = await User.findOne({ email });
            if (emailExists) {
                return res.status(400).json({
                    success: false,
                    error: 'Email already in use'
                });
            }
            user.email = email;
        }

        if (name) user.name = name;

        await user.save();

        logger.info(`Profile updated for user: ${user.email}`);

        res.json({
            success: true,
            message: 'Profile updated successfully',
            data: { user: user.toJSON() }
        });
    } catch (error) {
        next(error);
    }
};
