const Video = require('../models/Video');
const { fetchLatestVideos, fetchLatestVideosByHandle } = require('../services/youtubeService');

/**
 * Video Controller
 * Handles video-related API requests
 */

/**
 * Get latest videos from database
 * GET /api/videos/latest
 */
async function getLatestVideos(req, res) {
    try {
        const limit = parseInt(req.query.limit) || 10;
        
        // Fetch from database, sorted by publishedAt (newest first)
        const videos = await Video.find()
            .sort({ publishedAt: -1 })
            .limit(limit)
            .select('-__v');  // Exclude version key
        
        res.json({
            success: true,
            count: videos.length,
            data: videos
        });
        
    } catch (error) {
        console.error('❌ Error fetching videos from DB:', error);
        res.status(500).json({
            success: false,
            error: 'Failed to fetch videos',
            message: error.message
        });
    }
}

/**
 * Sync videos from YouTube to database
 * This is called by cron job and can also be triggered manually
 */
async function syncVideos() {
    try {
        const channelHandle = process.env.YOUTUBE_CHANNEL_HANDLE || '@tchaddiplomatie';
        const channelId = process.env.YOUTUBE_CHANNEL_ID;
        
        console.log('\n🔄 Starting video synchronization...');
        
        let videos;
        
        // Fetch from YouTube API
        if (channelId) {
            console.log(`📺 Fetching videos from channel ID: ${channelId}`);
            videos = await fetchLatestVideos(channelId, 10);
        } else {
            console.log(`📺 Fetching videos from channel handle: ${channelHandle}`);
            videos = await fetchLatestVideosByHandle(channelHandle, 10);
        }
        
        if (!videos || videos.length === 0) {
            console.warn('⚠️  No videos fetched from YouTube');
            return { success: true, synced: 0, message: 'No videos found' };
        }
        
        // Upsert videos (update if exists, insert if new)
        let syncedCount = 0;
        let newCount = 0;
        let updatedCount = 0;
        
        for (const videoData of videos) {
            const result = await Video.findOneAndUpdate(
                { youtubeId: videoData.youtubeId },  // Find by YouTube ID
                videoData,  // Update with new data
                { 
                    upsert: true,  // Create if doesn't exist
                    new: true,  // Return updated document
                    setDefaultsOnInsert: true
                }
            );
            
            syncedCount++;
            if (result.createdAt.getTime() === result.updatedAt.getTime()) {
                newCount++;
            } else {
                updatedCount++;
            }
        }
        
        // Keep only the 10 most recent videos
        // Get all videos sorted by date
        const allVideos = await Video.find().sort({ publishedAt: -1 });
        
        // If we have more than 10, delete the oldest ones
        if (allVideos.length > 10) {
            const videosToDelete = allVideos.slice(10);  // Get videos after the first 10
            const idsToDelete = videosToDelete.map(v => v._id);
            
            const deleteResult = await Video.deleteMany({ _id: { $in: idsToDelete } });
            console.log(`🗑️  Removed ${deleteResult.deletedCount} old videos to keep only the latest 10`);
        }
        
        console.log(`✅ Video sync completed: ${syncedCount} total (${newCount} new, ${updatedCount} updated)`);
        
        return {
            success: true,
            synced: syncedCount,
            new: newCount,
            updated: updatedCount,
            message: 'Videos synchronized successfully'
        };
        
    } catch (error) {
        console.error('❌ Error syncing videos:', error.message);
        
        // Don't throw error - just log it
        // This allows the server to continue even if YouTube API fails
        return {
            success: false,
            error: error.message,
            message: 'Failed to sync videos'
        };
    }
}

/**
 * Manual sync endpoint (for admin use)
 * POST /api/videos/sync
 */
async function manualSync(req, res) {
    try {
        const result = await syncVideos();
        res.json(result);
    } catch (error) {
        console.error('❌ Manual sync error:', error);
        res.status(500).json({
            success: false,
            error: 'Failed to sync videos',
            message: error.message
        });
    }
}

module.exports = {
    getLatestVideos,
    syncVideos,
    manualSync
};
