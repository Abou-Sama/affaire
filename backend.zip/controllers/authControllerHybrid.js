/**
 * Hybrid Authentication Controller
 * Works with both SQL Database and JSON files
 * Perfect for Hostinger and production environments
 */

const authService = require('../services/authServiceHybrid');
const logger = require('../config/logger');

/**
 * Login user
 * POST /api/auth/login
 * Works with database or falls back to JSON
 */
exports.login = async (req, res, next) => {
    try {
        const { username, email, password } = req.body;

        if (!password) {
            return res.status(400).json({
                success: false,
                error: 'Password is required'
            });
        }

        if (!username && !email) {
            return res.status(400).json({
                success: false,
                error: 'Username or email is required'
            });
        }

        // Search by email or username (email is also stored as username for compatibility)
        const searchCriteria = username ? { username } : email ? { email } : null;

        if (!searchCriteria) {
            return res.status(400).json({
                success: false,
                error: 'Invalid search criteria'
            });
        }

        // Find user (works with database or JSON)
        const user = await authService.findUser(searchCriteria);

        if (!user) {
            const field = username ? 'username' : 'email';
            logger.warn(`Login attempt for non-existent ${field}: ${username || email}`);
            return res.status(401).json({
                success: false,
                error: 'Invalid username/email or password'
            });
        }

        // Verify password
        let isPasswordCorrect;
        try {
            isPasswordCorrect = await authService.comparePassword(password, user.password);
        } catch (compareError) {
            logger.error(`Password comparison error for user ${username || email}:`, compareError);
            return res.status(500).json({
                success: false,
                error: 'Authentication service error'
            });
        }

        if (!isPasswordCorrect) {
            logger.warn(`Failed login attempt for user: ${username || email}`);
            return res.status(401).json({
                success: false,
                error: 'Invalid username/email or password'
            });
        }

        // Generate tokens
        const { accessToken, refreshToken } = authService.generateTokens(user);

        // Set refresh token in HTTP-only cookie
        res.cookie('refreshToken', refreshToken, {
            httpOnly: true,
            secure: process.env.NODE_ENV === 'production',
            sameSite: 'strict',
            maxAge: 7 * 24 * 60 * 60 * 1000
        });

        logger.info(`✅ User logged in: ${username || email}`);

        res.json({
            success: true,
            message: 'Login successful',
            data: {
                user: authService.userToJSON(user),
                accessToken,
                refreshToken
            }
        });
    } catch (error) {
        logger.error('❌ Login error:', error);
        res.status(500).json({
            success: false,
            error: error.message || 'Login failed'
        });
    }
};

/**
 * Signup user
 * POST /api/auth/signup
 */
exports.signup = async (req, res, next) => {
    try {
        const { email, name, password } = req.body;

        if (!email || !name || !password) {
            return res.status(400).json({
                success: false,
                error: 'Email, name, and password are required'
            });
        }

        // Check if user already exists
        const existingUser = await authService.findUser({ email });
        if (existingUser) {
            return res.status(400).json({
                success: false,
                error: 'Email already registered'
            });
        }

        // Validate password strength (minimum 8 characters)
        if (password.length < 8) {
            return res.status(400).json({
                success: false,
                error: 'Password must be at least 8 characters'
            });
        }

        // Create new user
        const newUser = await authService.createUser({
            email,
            name,
            password,
            role: 'user',
            status: 'active'
        });

        // Generate tokens
        const { accessToken, refreshToken } = authService.generateTokens(newUser);

        // Set refresh token in HTTP-only cookie
        res.cookie('refreshToken', refreshToken, {
            httpOnly: true,
            secure: process.env.NODE_ENV === 'production',
            sameSite: 'strict',
            maxAge: 7 * 24 * 60 * 60 * 1000
        });

        logger.info(`✅ New user registered: ${email}`);

        res.status(201).json({
            success: true,
            message: 'User registered successfully',
            data: {
                user: authService.userToJSON(newUser),
                accessToken,
                refreshToken
            }
        });
    } catch (error) {
        logger.error('❌ Signup error:', error);
        res.status(500).json({
            success: false,
            error: error.message || 'Signup failed'
        });
    }
};

/**
 * Get user profile
 * GET /api/auth/profile
 */
exports.getProfile = async (req, res, next) => {
    try {
        if (!req.user) {
            return res.status(401).json({
                success: false,
                error: 'Not authenticated'
            });
        }

        const user = await authService.findUser({ email: req.user.email });

        if (!user) {
            return res.status(404).json({
                success: false,
                error: 'User not found'
            });
        }

        res.json({
            success: true,
            data: authService.userToJSON(user)
        });
    } catch (error) {
        logger.error('Profile fetch error:', error);
        res.status(500).json({
            success: false,
            error: error.message || 'Failed to fetch profile'
        });
    }
};

/**
 * Update user profile
 * PUT /api/auth/profile
 */
exports.updateProfile = async (req, res, next) => {
    try {
        if (!req.user) {
            return res.status(401).json({
                success: false,
                error: 'Not authenticated'
            });
        }

        const { name, email } = req.body;

        // For now, just return success without updating
        // In production, you'd update the user in database/JSON
        const user = await authService.findUser({ email: req.user.email });

        res.json({
            success: true,
            data: authService.userToJSON(user)
        });
    } catch (error) {
        logger.error('Profile update error:', error);
        res.status(500).json({
            success: false,
            error: error.message || 'Failed to update profile'
        });
    }
};

/**
 * Change password
 * POST /api/auth/change-password
 */
exports.changePassword = async (req, res, next) => {
    try {
        if (!req.user) {
            return res.status(401).json({
                success: false,
                error: 'Not authenticated'
            });
        }

        const { currentPassword, newPassword } = req.body;

        if (!currentPassword || !newPassword) {
            return res.status(400).json({
                success: false,
                error: 'Current and new passwords are required'
            });
        }

        if (newPassword.length < 8) {
            return res.status(400).json({
                success: false,
                error: 'New password must be at least 8 characters'
            });
        }

        const user = await authService.findUser({ email: req.user.email });

        if (!user) {
            return res.status(404).json({
                success: false,
                error: 'User not found'
            });
        }

        // Verify current password
        const isPasswordCorrect = await authService.comparePassword(currentPassword, user.password);

        if (!isPasswordCorrect) {
            return res.status(401).json({
                success: false,
                error: 'Current password is incorrect'
            });
        }

        // In production, update the password in database/JSON
        logger.info(`✅ Password changed for user: ${user.email}`);

        res.json({
            success: true,
            message: 'Password changed successfully'
        });
    } catch (error) {
        logger.error('Password change error:', error);
        res.status(500).json({
            success: false,
            error: error.message || 'Failed to change password'
        });
    }
};

/**
 * Logout
 * POST /api/auth/logout
 */
exports.logout = async (req, res, next) => {
    try {
        // Clear refresh token cookie
        res.clearCookie('refreshToken');

        res.json({
            success: true,
            message: 'Logged out successfully'
        });
    } catch (error) {
        logger.error('Logout error:', error);
        res.status(500).json({
            success: false,
            error: error.message || 'Logout failed'
        });
    }
};

/**
 * Refresh token
 * POST /api/auth/refresh
 */
exports.refreshToken = async (req, res, next) => {
    try {
        const refreshToken = req.cookies.refreshToken || req.body.refreshToken;

        if (!refreshToken) {
            return res.status(401).json({
                success: false,
                error: 'Refresh token required'
            });
        }

        try {
            const decoded = authService.verifyToken(refreshToken);
            const user = await authService.findUser({ email: decoded.email });

            if (!user) {
                return res.status(401).json({
                    success: false,
                    error: 'User not found'
                });
            }

            const { accessToken: newAccessToken, refreshToken: newRefreshToken } = authService.generateTokens(user);

            res.cookie('refreshToken', newRefreshToken, {
                httpOnly: true,
                secure: process.env.NODE_ENV === 'production',
                sameSite: 'strict',
                maxAge: 7 * 24 * 60 * 60 * 1000
            });

            res.json({
                success: true,
                data: {
                    accessToken: newAccessToken,
                    refreshToken: newRefreshToken
                }
            });
        } catch (tokenError) {
            return res.status(401).json({
                success: false,
                error: 'Invalid refresh token'
            });
        }
    } catch (error) {
        logger.error('Token refresh error:', error);
        res.status(500).json({
            success: false,
            error: error.message || 'Token refresh failed'
        });
    }
};

/**
 * Reset password (admin endpoint)
 */
exports.resetPassword = async (req, res, next) => {
    try {
        const { email } = req.body;

        if (!email) {
            return res.status(400).json({
                success: false,
                error: 'Email is required'
            });
        }

        const user = await authService.findUser({ email });

        if (!user) {
            // Don't reveal if user exists
            return res.json({
                success: true,
                message: 'If the email exists, a password reset link has been sent'
            });
        }

        // In production, send password reset email
        logger.info(`Password reset requested for user: ${email}`);

        res.json({
            success: true,
            message: 'Password reset link sent to your email'
        });
    } catch (error) {
        logger.error('Password reset error:', error);
        res.status(500).json({
            success: false,
            error: error.message || 'Password reset failed'
        });
    }
};
